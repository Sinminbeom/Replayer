import time

from MultiProcess.abProcess import abProcess
from MultiProcess.cMultiProcessRunner import cMultiProcessRunner





class TMinio:
    def __init__(self):
        pass
    pass

class TMinioStorage:

    def __init__(self):
        self.mp = cMultiProcessRunner(2)
        pass
    # def Connect(self):
    #     self._minio=TMinio()
    #     pass
    def Start(self):
        self.mp.Start()
        pass

    def file_upload(file_path):
        print("file_upload")

    def fileDownload(file_path):
        print("file_download")

class TDownloadProcess(abProcess):
    def __init__(self , _name , _call_back ):
        super().__init__(_name)
        self.call_back=_call_back

    def Running(self, process):

        ## download 가

        for i in range(0,10):
            time.sleep(1)

        self.call_back

    # def Running(self,process):
    #
    #     loopcnt=0
    #
    #     while True:
    #         print("pub" , str(loopcnt))
    #         self._shardQueuePutWithLock("sub1" ,loopcnt )
    #         self._shardQueuePutWithLock("sub2" ,loopcnt )
    #
    #         loopcnt=loopcnt+1
    #         time.sleep(1)


def main():
    mp = cMultiProcessRunner(3)

    mp.Start()

    mp.Append(  )


    while True:

        print("1 sec")
        time.sleep(1)

        pass









    pass

if __name__ == '__main__':
    main()





