from MultiProcess.abProcess import abProcess


class cShardJobQueueProcess(abProcess):

    def __init__(self, _name , _name_replace=False , _queue_ex_name=None ):
        super().__init__( _name , _name_replace , _queue_ex_name )


        self.shared_job_queue=None
        self.job_queue_lock=None

        self.shared_job_queue_mpm = None
        self.job_queue_mpm_lock = None

    def _setSharedJobQueue(self , _shared_job_queue , _shared_job_queue_lock ):
        self.shared_job_queue=_shared_job_queue
        self.job_queue_lock=_shared_job_queue_lock

    def _setSharedJobQueueMpM(self, _shared_job_queue_mpm, _shared_job_queue_mpm_lock):
        self.shared_job_queue_mpm = _shared_job_queue_mpm
        self.job_queue_mpm_lock = _shared_job_queue_mpm_lock



    def _pushSharedJobQueue(self,_job):
        with self.job_queue_lock:
            self.shared_job_queue.put(_job)

    def _pushSharedJobQueueMpM(self,_job):
        with self.job_queue_mpm_lock:
            self.shared_job_queue_mpm.put(_job)

    def _popSharedJobQueue(self ):
        with self.job_queue_lock:
            size=self.shared_job_queue.qsize()
            if size > 0 :
                return self.shared_job_queue.get()
            return None

