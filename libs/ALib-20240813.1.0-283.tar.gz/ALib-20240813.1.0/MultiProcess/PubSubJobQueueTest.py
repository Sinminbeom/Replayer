import time

from MultiProcess.abProcess import abProcess
from MultiProcess.cShardJobQueueProcess import cShardJobQueueProcess


# from MultiProcess.cMultiProcesser import cMultiProcesser


class publishJobProcess(cShardJobQueueProcess):
    def __init__(self , _name):
        super().__init__(_name)

    def Running(self,process):

        loopcnt=0


        while True:
            print("pub" , str(loopcnt))
            self._shardQueuePutWithLock("sub1" ,loopcnt )
            self._shardQueuePutWithLock("sub2" ,loopcnt )
            self._shardQueuePutWithLock("sub3" ,loopcnt )
            self._shardQueuePutWithLock("sub4" ,loopcnt )
            self._shardQueuePutWithLock("sub5" ,loopcnt )
            # self._shardQueuePutWithLock("sub6" ,loopcnt )

            # self._shardQueuePutWithLock("shardmem", loopcnt)

            loopcnt=loopcnt+1
            time.sleep(1)


class subscribeJobProcess(cShardJobQueueProcess):
    def __init__(self , _name):
        super().__init__(_name)

    def Running(self,process):
        while True:
            v = self._shardQueuePopWithLock( self.GetName() )
            print(f"[recv] NM : {self.GetName() } str:{str(v)}")
            #
            # v = self._shardQueuePopWithLock("shardmem")
            # print(f"[recv] shardmem NM : {self.GetName()} str:{str(v)}")

            ret = self._popSharedJobQueue()
            print(f"""=============={ret} ======= """)

            time.sleep(2)


class subscribeProcess2(abProcess):
    def __init__(self , _name):
        super().__init__(_name)

    def Running(self,process):
        while True:

            with self.lock:
                while self._sharedQueueGetSize( self.GetName() ) > 0:
                    v = self._shardQueuePop(self.GetName())
                    print("==" + str(v))




            ret = self._popSharedJobQueue()
            print(f"""=============={ret} ======= """)

            # v = self._shardQueuePopWithLock( self.GetName() )
            # print("==============> " + str(v))
            # time.sleep(5)



def  maAct(_mp , _loop_cnt ):




    _mp.PutShardJobQueueWithLock( _loop_cnt )

    ss=_mp.SizeShardJobQueue()

    print( f"""size : {ss}""" )



    pass


def main():

    from MultiProcess.cMultiProcesser import cMultiProcesser
    # mp = cMultiProcesser.instance().Init(3)
    mp = cMultiProcesser(8)


    mp.AppendWithShardJobQueue(publishJobProcess("pub1"))
    mp.AppendWithShardJobQueue(subscribeJobProcess("sub1"))
    mp.AppendWithShardJobQueue(subscribeJobProcess("sub2"))
    mp.AppendWithShardJobQueue(subscribeJobProcess("sub3"))
    mp.AppendWithShardJobQueue(subscribeJobProcess("sub4"))
    mp.AppendWithShardJobQueue(subscribeJobProcess("sub5"))





    # mp.Append(subscribeProcess2("sub1"))
    # mp.Append(subscribeProcess2("sub2"))
    # mp.Append(subscribeProcess2("sub3"))
    # mp.Append(subscribeProcess2("sub4"))
    # mp.Append(subscribeProcess2("sub5"))
    # mp.Append(subscribeProcess2("sub6"))
    # mp.Append(subscribeProcess2("sub7"))

    # mp.Append(subscribeProcess2("sub1"))
    # mp.Append(subscribeProcess2("sub2"))
    # mp.Append(subscribeProcess2("sub3"))
    # mp.Append(subscribeProcess2("sub4"))
    # mp.Append(subscribeProcess2("sub5"))
    # mp.Append(subscribeProcess2("sub6"))
    # mp.Append(subscribeProcess2("sub7"))

    # mp.Append(subscribeProcess2("sub1"))
    # mp.Append(subscribeProcess2("sub2"))

    print(mp.IsRunning())
    # mp.Run()
    mp.RunAsync()
    print(mp.IsRunning())

    loopCnt=0
    while True:
        # print( mp.GetThreadStatus())
        if mp.IsRunning() == False:
            print("Stoped!!")
            break
        # print("a")
        loopCnt+=1

        maAct(mp, loopCnt)
        time.sleep(1)


        # loopCnt+=1
        # if loopCnt == 3:
        #     mp.Stop()
        # print("1 SEC")
        # print(mp.IsRunning())
        pass


if __name__ == '__main__':
    main()



