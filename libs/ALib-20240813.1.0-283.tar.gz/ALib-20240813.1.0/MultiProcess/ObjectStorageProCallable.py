
from Log.cLogger import cLogger
from MultiProcess.abProcessCallAble import abProcessCallAble


class minioProcess(abProcessCallAble):

    def __init__(self, _name, _name_replace, _objectStorage, _transferFileInfoList, _callback):
        super().__init__(_name, _name_replace, _callback)
        self.objectStorage = _objectStorage
        self.transferFileInfoList = _transferFileInfoList

    def Running(self, process):
        self.objectStorage.Connect()
        self.RunAct(process)
        self.objectStorage.Disconnect()

    def RunAct(self, process):
        pass

    @staticmethod
    def CallBack(process):
        # print("minioProcess -default Call back")
        cLogger.instance().Print(process.GetName())


class minioUploader(minioProcess):
    def __init__(self, _name, _name_replace, _objectStorage, _transferFileInfoList, _callback):
        super().__init__(_name, _name_replace, _objectStorage, _transferFileInfoList, _callback)

    def RunAct(self, process):
        for transferFileInfo in self.transferFileInfoList:
            self.objectStorage.UploadFile( *transferFileInfo.GetUploadInfo() )




class minioDownloader(minioProcess):
    def __init__(self, _name, _name_replace, _objectStorage, _transferFileInfoList, _callback):
        super().__init__(_name, _name_replace, _objectStorage, _transferFileInfoList, _callback)

    def RunAct(self, process):
        for transferFileInfo in self.transferFileInfoList:
            self.objectStorage.DownloadFile(*transferFileInfo.GetDownloadInfo())


class minioRemover(minioProcess):
    def __init__(self, _name, _name_replace, _objectStorage, _transferFileInfoList, _callback):
        super().__init__(_name, _name_replace, _objectStorage, _transferFileInfoList, _callback)

    def RunAct(self, process):
        for transferFileInfo in self.transferFileInfoList:
            self.objectStorage.RemoveFile(transferFileInfo.GetRemoveInfo())

# from ObjectStrage.Minio.cMinioStorage import cMinioStorage

# def main():
#     CONFIG_FILE = "../config/config.conf"
#     dto = []
#     dto.append(cTransferDto("d1/uploadTest12", "C:\D\project\swm\infra-glue-python-template\config", "config.conf", False))
#     uploader = minioUploader("Uploader", objectStorageProcess.ActionType.UPLOAD.value, cMinioStorage(CONFIG_FILE), dto)
#     uploader.Running(process=None)
#
#
# if __name__ == '__main__':
#     main()
#
#
