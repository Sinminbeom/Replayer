from enum import Enum

from MultiProcess.abProcess import abProcess


class objectStorageProcess(abProcess):
    class ActionType(Enum):
        UPLOAD = 0
        DOWNLOAD = 1
        REMOVE = 2

    def __init__(self, _name, _actionType, _objectStorage):
        super().__init__(_name, True)
        self.actionType = _actionType
        self.objectStorage = _objectStorage
        pass

    def Running(self, process):
        pass


class minioProcess(objectStorageProcess):

    def __init__(self, _name, _actionType, _objectStorage, _transferFileInfoList):
        super().__init__(_name, _actionType, _objectStorage)
        self.transferFileInfoList = _transferFileInfoList
        pass

    def Running(self, process):
        self.objectStorage.Connect()
        self.RunAct(process)
        self.objectStorage.Disconnect()

    def RunAct(self, process):
        pass


class minioUploader(minioProcess):
    def __init__(self, _name, _actionType, _objectStorage, _transferFileInfoList):
        super().__init__(_name, _actionType, _objectStorage, _transferFileInfoList)

    def RunAct(self, process):
        for transferFileInfo in self.transferFileInfoList:
            self.objectStorage.UploadFile( *transferFileInfo.GetUploadInfo() )



class minioDownloader(minioProcess):
    def __init__(self, _name, _actionType, _objectStorage, _transferFileInfoList):
        super().__init__(_name, _actionType, _objectStorage, _transferFileInfoList)

    def RunAct(self, process):
        for transferFileInfo in self.transferFileInfoList:
            self.objectStorage.DownloadFile( *transferFileInfo.GetDownloadInfo() )



class minioRemover(minioProcess):
    def __init__(self, _name, _actionType, _objectStorage, _transferFileInfoList):
        super().__init__(_name, _actionType, _objectStorage, _transferFileInfoList)

    def RunAct(self, process):
        for transferFileInfo in self.transferFileInfoList:
            self.objectStorage.RemoveFile( transferFileInfo.GetRemoveInfo() )

# from ObjectStrage.Minio.cMinioStorage import cMinioStorage

# def main():
#     CONFIG_FILE = "../config/config.conf"
#     dto = []
#     dto.append(cTransferDto("d1/uploadTest12", "C:\D\project\swm\infra-glue-python-template\config", "config.conf", False))
#     uploader = minioUploader("Uploader", objectStorageProcess.ActionType.UPLOAD.value, cMinioStorage(CONFIG_FILE), dto)
#     uploader.Running(process=None)
#
#
# if __name__ == '__main__':
#     main()
#
#
