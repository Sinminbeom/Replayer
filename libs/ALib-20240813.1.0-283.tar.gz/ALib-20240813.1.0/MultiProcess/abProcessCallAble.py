import time

from MultiProcess.abProcess import abProcess
from MultiProcess.cMultiProcessRunner import cMultiProcessRunner


#
# T1 = TypeVar('T1')
# R = TypeVar('R')
# class abProcessCallAble(abProcess,Func1[T1, R], Generic[T1, R]):
#
#     def __init__(self, _name, _name_replace=False):
#         super().__init__(_name,_name_replace)
#     def Action(self, process):
#         try:
#             self._setStart()
#             self.Running(process)
#             ## call_back
#
#             self._setStop()
#
#
#
#         except Exception as e:
#             self._setStop()
#             raise
#
#     @abstractmethod
#     def invork(self, t1: T1) -> R:
#         pass
#

class abProcessCallAble(abProcess):
    def __init__(self , _name, _name_replace=False , _callback = None):
        super().__init__(_name ,_name_replace )
        self.call_back=_callback
    def Action(self, process):
        try:
            self._setStart()
            self.Running(process)
            # self.call_back(process)

            self.call_back(process)

            ## call_back
            self._setStop()

        except Exception as e:
            self._setStop()
            raise

    @staticmethod
    def CB( _process  ):
        print(f"CB CB")



class TProCallTest(abProcessCallAble):
    
    def __init__(self, _name, _name_replace=False,_callback = None):
        super().__init__(_name,_name_replace,_callback)

    def Running(self, process):
        for i in range(2):
            print("abProcess " + self.name + " " + str(i))
            time.sleep(1)

    @staticmethod
    def CB(_process):
        print(f"CB : {_process.GetName()}")

def main():

    mp = cMultiProcessRunner(2)
    mp.Start()

    # tp1 = TProCallTest("nm", _name_replace=False, _callback=lambda process: print(f" call_back : {process.GetName()}"))
    # tp2 = TProCallTest("nm", _name_replace=False, _callback=lambda process: print(f" call_back : {process.GetName()}"))

    tp1 = TProCallTest("nm", True, TProCallTest.CB)
    tp2 = TProCallTest("nm", True, TProCallTest.CB)
    tp3 = TProCallTest("nm", True, TProCallTest.CB)
    tp4 = TProCallTest("nm", True, TProCallTest.CB)
    tp5 = TProCallTest("nm", True, TProCallTest.CB)
    tp6 = TProCallTest("nm", True, TProCallTest.CB)

    # tp1 = TProCallTest("nm1", False , _callback=lambda : print(f" call_back ") )
    # tp2 = TProCallTest("nm2", False, _callback=lambda : print(f" call_back "))
    mp.Append(tp1)
    mp.Append(tp2)
    mp.Append(tp6)

    loop_count=0
    while True:

        loop_count = loop_count+1

        if loop_count == 3:
            mp.Append(tp3)
        elif loop_count == 4:
            mp.Append(tp4)
        elif loop_count == 5:
            mp.Append(tp5)

        print("1 sec")
        time.sleep(1)

        pass

    # TP = TProCallTest("nm" ,_name_replace=False ,_callback= lambda process : print(f" call_back : { process.GetName() }") )


if __name__ == '__main__':
    main()





