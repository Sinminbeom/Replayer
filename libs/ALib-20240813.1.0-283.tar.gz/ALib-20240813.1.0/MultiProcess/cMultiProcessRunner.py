import multiprocessing
import string
import time
from multiprocessing import Manager

from MultiProcess.PubSubTest import subscribeProcess2, publishProcess
from MultiProcess.abProcess import   abProcess
from MultiProcess.cMultiProcesser import cMultiProcesser, cProcessingDTO
from MultiProcess.cSequenceNumber import cSequenceNumberMultiProcessor
from ThreadUtils.abThread import abThread
from queue import Queue


### pool 개수 default 정히가...
class cMultiProcessRunner(cMultiProcesser):

    def Start(self):
        abThread.Start(self)


    def Run(self):
        while True:

            if self.IsStop() :
                print("thread Stoped!! force Stop!!")
                return

            with self.lock:

                if self.processReadyQueue.empty() and len(self.processingList) == 0:
                    # print(" process empty ")
                    # time.sleep(1)
                    continue

            # allocation process
            with self.lock:

                processingStartQueue=[]
                while not self.processReadyQueue.empty() and len(self.processingList) < self.process_size:
                    process = self.processReadyQueue.get()

                    self._allocateShardQueue(process)

                    processing = multiprocessing.Process(target=process.Action, args=(process,))

                    # processing.start()
                    processingStartQueue.append(processing)
                    self.processingList.append( cProcessingDTO( processing , process ) )
                    print("new release---------- " + process.GetName())
                    # print("a")
                while processingStartQueue:
                    prc=processingStartQueue.pop()
                    prc.start()
                    # print("new start---------- " + prc.GetName())

            # deallocation process
            with self.lock:
                for i in range(len(self.processingList)):
                    running_process = self.processingList[i].GetProcessingProcess()
                    # if running_process.getRunning() == False:
                    running_process.join(timeout=0.3)
                    if not running_process.is_alive():
                        self._deleteShardQueue( self.processingList[i].GetProcess() )
                        self.processingList.pop(i)
                    break




def main():

    mp=cMultiProcessRunner(3)
    mp.Start()
    # cMultiProcessRunner.instance().Start()

    mp.Append(publishProcess("pub1"))
    mp.Append(subscribeProcess2("sub1"))
    mp.Append(subscribeProcess2("sub2"))


    # cMultiProcessRunner.instance().Append(publishProcess("pub1"))
    # cMultiProcessRunner.instance().Append(subscribeProcess2("sub1"))
    # cMultiProcessRunner.instance().Append(subscribeProcess2("sub2"))

    print(mp.IsRunning())
    # cMultiProcesser.instance().RunAsync()
    # print(cMultiProcesser.instance().IsRunning())
    while True:
        if mp.IsRunning() == False:
            print("Stoped!!")
            break
        time.sleep(1)

    pass

if __name__ == '__main__':
    main()