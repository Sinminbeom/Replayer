from abc import abstractmethod
from enum import Enum
from multiprocessing import Manager
import time
from typing import List

from MultiProcess.cSequenceNumber import cSequenceNumberMultiProcessor


# from MultiProcess.cMultiProcesser import cMultiProcesser


class IMultiProcess:

    def GetName(self):
        pass

    def GetRunning(self):
        pass
    def Running(self,process):
        pass
    def Action(self,process):
        pass

class abProcess(IMultiProcess):

    seqGenerator = cSequenceNumberMultiProcessor()
    def __init__(self,_name , _name_replace=False , _queue_ex_name=None ):
        # self.name=_name
        if _name_replace:
            self.name = abProcess.seqGenerator.GetName(_name)
        else:
            self.name=_name

        self.IsRunning=False
        self.shared_queue=None
        self.lock=None

        self.shared_queue_ex=None
        self.ex_lock=None
        self._queue_ex_name=_queue_ex_name

        self.shared_config_queue = None


        self.sharedDataChannel=None
        self.sharedDataChannelLock=None



    def IsAbleSharedQueue(self):
        if self.shared_queue==None:
            return False

        return True

    def _setSharedConfigQueue(self , _shared_config_queue ):
        self.shared_config_queue=_shared_config_queue

    def _setSharedQueue(self , _shared_queue , _lock ):
        self.shared_queue=_shared_queue
        self.lock=_lock

    def _assineSharedQueueEx(self , _shared_queue_ex , _ex_lock ):
        self.shared_queue_ex=_shared_queue_ex
        self.ex_lock=_ex_lock

    def _assineSharedJobQueue(self , _shared_job_queue , _job_queue_lock ):
        self.shared_job_queue=_shared_job_queue
        self.job_queue_lock=_job_queue_lock
    #
    def _setSharedJobQueue(self, _shared_job_queue, _shared_job_queue_lock):
        pass

    def _setSharedJobQueueMpM(self, _shared_job_queue_mpm, _shared_job_queue_mpm_lock):
        pass
    #
    # def _popSharedJobQueue(self):
    #     pass

    def _shardQueueExPutWithLock(self, name, value):
        if value == None:
            print(f"abProcess Shared Queue Insert None {self.GetName()}")
            return

        with self.ex_lock :
            # self.shared_queue[name].append(value)
            #
            if name not in self.shared_queue_ex:
                self.shared_queue_ex[name]=[]

            tmp_list = self.shared_queue_ex[name]
            tmp_list.append(value)
            self.shared_queue_ex[name]=tmp_list

    def _shardQueuePutWithLock(self,name, value):

        if value == None:
            print(f"abProcess Shared Queue Insert None {self.GetName()}")
            return

        with self.lock :
            # self.shared_queue[name].append(value)
            #
            tmp_list = self.shared_queue[name]
            tmp_list.append(value)
            self.shared_queue[name]=tmp_list

    def _shardQueueExPutWithLockWithList(self,name, value:List):

        if value == None:
            print(f"abProcess Shared Queue Insert None {self.GetName()}")
            return

        with self.ex_lock :

            if name not in self.shared_queue_ex:
                self.shared_queue_ex[name]=[]

            tmp_list = self.shared_queue_ex[name]
            tmp_list.extend(value)
            self.shared_queue_ex[name]=tmp_list

    def _shardQueuePutWithLockWithList(self,name, value:List):

        if value == None:
            print(f"abProcess Shared Queue Insert None {self.GetName()}")
            return

        with self.lock :
            tmp_list = self.shared_queue[name]
            tmp_list.extend(value)
            self.shared_queue[name]=tmp_list

    def shardQueueExPutWithLock(self,name, value):

        if value == None:
            print(f"abProcess Shared Queue Insert None {self.GetName()}")
            return

        with self.ex_lock :

            if name not in self.shared_queue_ex:
                self.shared_queue_ex[name]=[]

            tmp_list = self.shared_queue_ex[name]
            tmp_list.append(value)
            self.shared_queue_ex[name]=tmp_list

    def shardQueuePutWithLock(self,name, value):

        if value == None:
            print(f"abProcess Shared Queue Insert None {self.GetName()}")
            return
        with self.lock :
            tmp_list = self.shared_queue[name]
            tmp_list.append(value)
            self.shared_queue[name]=tmp_list
    ###########################################################################################

    def _setSharedDataChannel(self,_shared_data_channel , _shared_data_channel_lock ):
        self.sharedDataChannel = _shared_data_channel
        self.sharedDataChannelLock = _shared_data_channel_lock
        pass

    def _sharedChannelGetSize(self,_channel_name):

        with self.sharedDataChannelLock:
            if _channel_name not in self.sharedDataChannel:
                return 0

        tmp_list = self.sharedDataChannel[_channel_name]
        return len(tmp_list)

    def _sharedChannelPutWithLock(self, _channel_name, _data_class ):

        with self.sharedDataChannelLock:
            if _channel_name not in self.sharedDataChannel:
                self.sharedDataChannel[_channel_name] = []

            tmp_list = self.sharedDataChannel[_channel_name]
            tmp_list.append(_data_class)
            self.sharedDataChannel[_channel_name] = tmp_list

    def _sharedChannelPopWithLock(self,_channel_name):
        # value = None
        value = []
        with self.sharedDataChannelLock:
            if _channel_name not in self.sharedDataChannel:
                self.sharedDataChannel[_channel_name] = []

            tmp_list = self.sharedDataChannel[_channel_name]
            # value = None

            if len(tmp_list) > 0:
                value.extend(tmp_list)
                tmp_list.clear()

            self.sharedDataChannel[_channel_name] = tmp_list
            return value

    ###########################################################################################
    def _sharedQueueExGetSize(self,name):

        with self.ex_lock:
            if name not in self.shared_queue_ex:
                self.shared_queue_ex[name] = []

        tmp_list = self.shared_queue_ex[name]
        return len(tmp_list)

    def _sharedQueueGetSize(self,name):
        tmp_list = self.shared_queue[name]
        return len(tmp_list)

    def _shardQueueExPut(self, name, value):

        with self.ex_lock:
            if name not in self.shared_queue_ex:
                self.shared_queue_ex[name] = []

            tmp_list = self.shared_queue_ex[name]
            tmp_list.append(value)
            self.shared_queue_ex[name] = tmp_list


    def _shardQueueConfigGetCommunicationMes(self):
        from MultiProcess.cMultiProcesser import E_MP_CONFIG_KEY
        return self._shardQueueConfigGetMes(  E_MP_CONFIG_KEY.COMMUNICATION )

    def _shardQueueConfigGetMes(self ,_config_key):

        if _config_key not in self.shared_config_queue:
            return None
        return self.shared_config_queue[_config_key]

    def _shardQueuePut(self, name, value):
        tmp_list = self.shared_queue[name]
        tmp_list.append(value)
        self.shared_queue[name] = tmp_list


    def _shardQueueExPopWithLock(self,name):
        # value = None
        value = []
        with self.ex_lock:
            if name not in self.shared_queue_ex:
                self.shared_queue_ex[name] = []

            tmp_list = self.shared_queue_ex[name]
            # value = None

            if len(tmp_list) > 0:
                value.extend(tmp_list)
                tmp_list.clear()

            self.shared_queue_ex[name] = tmp_list
            return value


    def _shardQueuePopWithLock(self,name):
        # value = None
        value = []
        with self.lock:
            tmp_list = self.shared_queue[name]
            # value = None

            if len(tmp_list) > 0:
                value.extend(tmp_list)
                tmp_list.clear()

            self.shared_queue[name] = tmp_list
            return value

    # def _shardQueuePop(self,name):
    #     tmp_list = self.shared_queue[name]
    #     value=tmp_list.pop(0)
    #     self.shared_queue[name] = tmp_list
    #     return value

    def _shardQueueExPop(self,name):

        value = []

        with self.ex_lock:
            if name not in self.shared_queue_ex:
                self.shared_queue_ex[name] = []

        tmp_list = self.shared_queue_ex[name]

        if len(tmp_list) > 0:
            value.extend(tmp_list)
            tmp_list.clear()

        self.shared_queue_ex[name] = tmp_list
        return value

    def _shardQueuePop(self,name):
        tmp_list = self.shared_queue[name]
        value=[]
        if len(tmp_list) > 0:
            value.extend(tmp_list)
            tmp_list.clear()

        self.shared_queue[name] = tmp_list
        return value

    def GetName(self):
        return self.name

    def _setStart(self):
        self.IsRunning=True

    def _setStop(self):
        self.IsRunning = False

    def GetRunning(self):
        return self.IsRunning

    # @abstractmethod
    def Running(self, process):
        for i in range(2):
            print("abProcess " + self.name + " " + str(i))
            time.sleep(1)


    def Action(self, process):
        try:
            self._setStart()
            self.Running(process)
            self._setStop()
        except Exception as e:
            self._setStop()
            raise


class exProcess(abProcess):
    def __init__(self, _name):
        super().__init__(_name)
        self.aa = abProcess(_name)
        pass

    def Running(self, process):
        for i in range(4):
            print("exProcess " + self.name + " " + str(i))
            time.sleep(1)

        # print( process.aa.getName() )

        pass

    # def Action(self):
    #     try:
    #         self.setStart()
    #
    #         self.Running()
    #
    #         self.setStop()
    #     except Exception as e:
    #         self.setStop()
    #         raise

    # @staticmethod
    # def Action(self):
    #     print("act " + process.getName())
    #     pass
