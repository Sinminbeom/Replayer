import asyncio
from multiprocessing import Manager


#
# async def task1():
#     print("task 1")
#     # while True:
#     #     print("task 11111")
#     #
#     #     pass
#
# async def task2():
#     print("task 2")
#
# async def main():
#     task1()
#     task2()
#
#     # await task1()
#     # await task2()
#
# loop = asyncio.get_event_loop()
# loop.run_until_complete(main())

def main():
    # Manager의 딕셔너리 생성
    manager = Manager()
    shared_dict = manager.dict()

    # 데이터 추가
    shared_dict['key1'] = [1,2,3]
    shared_dict['key2'] = [4,5,6]

    print(shared_dict)  # 출력: {'key1': 'value1', 'key2': 'value2'}

    # 데이터 삭제
    del shared_dict['key1']

    print(shared_dict)  # 출력: {'key2': 'value2'}


    pass


if __name__ == '__main__':
    main()