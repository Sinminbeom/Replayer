import threading
import time

from MultiProcess.abProcess import abProcess
from MultiProcess.cMultiProcesser import cMultiProcesser


class publishProcess(abProcess):
    def __init__(self , _name):
        super().__init__(_name)

        self.th1=None
        self.th2=None

        # self.th1 = threading.Thread(target=kk)
        # self.th2 = threading.Thread(target=self.proc2)

    def proc1(self):
        print("proc1")
        pass

    def proc2(self):
        print("proc2")
        pass

    def Running(self,process):

        self.th1 = threading.Thread(target=self.proc1)
        self.th2 = threading.Thread(target=self.proc2)
        # self.th2.start()

        self.th1.start()
        self.th2.start()



        loopcnt=0
        while True:
            print("pub" , str(loopcnt))
            # self._shardQueuePutWithLock("sub1" ,loopcnt )
            # self._shardQueuePutWithLock("sub2" ,loopcnt )

            loopcnt=loopcnt+1
            time.sleep(1)

def main():

    mp = cMultiProcesser.instance().Init(3)
    mp.Append(publishProcess("pub1"))

    print(mp.IsRunning())
    # mp.Run()
    mp.RunAsync()
    print(mp.IsRunning())

    # loopCnt=0
    while True:
        # print( mp.GetThreadStatus())
        if mp.IsRunning() == False:
            print("Stoped!!")
            break
        # print("a")
        time.sleep(1)



    pass

if __name__ == '__main__':
    main()