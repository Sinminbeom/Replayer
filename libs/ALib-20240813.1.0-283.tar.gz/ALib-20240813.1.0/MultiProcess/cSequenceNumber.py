import multiprocessing


class cSequenceNumber:

    def __init__(self):
        self.seq=0
        pass

    def Inc(self):
        self.seq=self.seq+1
        return self.seq

    def peek(self):
        return self.seq



    pass


class cSequenceNumberMultiProcessor( cSequenceNumber ):

    def __init__(self):
        super().__init__()
        self.lock = multiprocessing.Lock()

    def Inc(self):
        with self.lock:
            return super().Inc()

    def GetName(self,name):
        return name + "_" + str(self.Inc())
    def peek(self):
        with self.lock:
            return super().peek()



