from enum import Enum

class ExceptionType(Enum):
    INVALID_ARGS = "[ERROR] Invalid Args Error"
    DIRECTORY_EMPTY = "[ERROR] Your Directory Is Empty"
    FILE_LIST_EMPTY = "[ERROR] File List is Empty : Please Check Your Dir"
    LIST_OUT_OF_RANGE = "[ERROR] List Out Of Range Error"
    MULTI_PROCESSING_POOL_CREATE= "[ERROR] MP Pool Creation Error"