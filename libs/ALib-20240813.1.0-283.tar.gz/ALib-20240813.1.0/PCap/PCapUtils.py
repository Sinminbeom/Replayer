import warnings
from datetime import datetime

from scapy.utils import rdpcap, PcapReader
# warnings.filterwarnings("ignore")
# warnings.filterwarnings("ignore")

class PCapUtils:

    @staticmethod
    def GetBeginTimeStamp(pcap_file):
        # warnings.filterwarnings("ignore")
        with PcapReader(pcap_file) as pcap_reader:
            first_packet = next(pcap_reader)
            return first_packet.time
            # start_time = datetime.fromtimestamp(first_packet.time)
            #
            # return start_time

            # start_time_str = start_time.strftime('%Y%m%d%H%M%S')
            # return start_time_str

    @staticmethod
    def GetLastTimeStamp(pcap_file):

        last_time_packet = None
        with PcapReader(pcap_file) as pcap_reader:
            for packet in pcap_reader:
                last_time_packet = packet.time

            return last_time_packet


    @staticmethod
    def GetBeginTimeStr(pcap_file):
        # warnings.filterwarnings("ignore")
        with PcapReader(pcap_file) as pcap_reader:
            first_packet = next(pcap_reader)
            start_time = datetime.fromtimestamp(int(first_packet.time))
            start_time_str= start_time.strftime('%Y%m%d%H%M%S')
            return  start_time_str

    @staticmethod
    def GetLastTimeStr(pcap_file):

        last_time_packet = None
        with PcapReader(pcap_file) as pcap_reader:
            for packet in pcap_reader:
                last_time_packet = packet.time

            last_time = datetime.fromtimestamp(int(last_time_packet))
            time_str= last_time.strftime('%Y%m%d%H%M%S')
            return time_str

def main3():
    pcap_file = "D:\\dt\\at128_roof_front.pcap"
    f= PCapUtils.GetBeginTimeStr(pcap_file)
    l= PCapUtils.GetLastTimeStr(pcap_file)
    # PCapUtils.GetBeginTime(f)
    # print(f , l)

    print(f)
    print(l)

    a= PCapUtils.GetBeginTimeStamp(pcap_file)
    b= PCapUtils.GetLastTimeStamp(pcap_file)

    print(a)
    print(b)

    pass

def main2():
    pcap_file = "D:\\dt\\at128_roof_front.pcap"
    with PcapReader(pcap_file) as pcap_reader:
        first_packet = next(pcap_reader)
    capture_start_time = first_packet.time  # Get First Timestamp
    start_time = datetime.fromtimestamp(capture_start_time)
    print(start_time)
    pass

def main():
    pcap_file = "D:\\dt\\at128_roof_front.pcap"
    pcap_reader = rdpcap(pcap_file)

    loopCount=0
    for pkt in pcap_reader:
        print(pkt.time)

        timestamp = datetime.fromtimestamp(pkt.time)
        print(timestamp)
        pkt.show()

        loopCount=loopCount+1

        if loopCount > 4:
            return
    pass

if __name__ == '__main__':
    main3()





