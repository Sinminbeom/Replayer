from multipledispatch import dispatch

from PCap.cSplitedPcaps import cSplitedPcaps
from PCap.ePacketPosition import ePacketPosition


class cSplitedPcapContainer:

    def __init__(self):
        self.splitedPcaps = dict()

    def Append(self, _epochTime, _packetTimeSec, _savePath, _position: ePacketPosition):
        self.splitedPcaps[_packetTimeSec] = cSplitedPcaps(_epochTime, _packetTimeSec, _savePath, _position)

    def GetSplitedPcaps(self):
        return self.splitedPcaps


    def GetProcessedPcaps(self):
        processedPcaps = []
        for splitedPcap in self.splitedPcaps.values():
            if splitedPcap.GetPosition() == ePacketPosition.MID:
                processedPcaps.append(splitedPcap)

        return processedPcaps


    def GetUnProcessedPacps(self):
        unProcessedPcaps = []
        for splitedPcap in self.splitedPcaps.values():
            if splitedPcap.GetPosition() != ePacketPosition.MID:
                unProcessedPcaps.append(splitedPcap)

        return unProcessedPcaps




