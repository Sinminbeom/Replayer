import os
from datetime import datetime

from scapy.all import rdpcap, wrpcap


class cSplitsPcaps:

    @staticmethod
    def writePcap(_full_file_path, _packet_lists):

        from App.Utils.cUtils import cUtils
        fileInfo = cUtils.GetFileInfo(_full_file_path)
        cUtils.MkDir(fileInfo.GetFolderName())

        wrpcap(_full_file_path, _packet_lists)

    @staticmethod
    def SplitsList(_source_file_name_lists, _out_file_template):

        currnetSec = -1
        current_packets = []

        for _source_file_name in _source_file_name_lists:
            print(_source_file_name, _source_file_name_lists)
            packets = rdpcap(_source_file_name)

            print(_source_file_name, _source_file_name_lists)

            if not packets:
                return

            for packet in packets:
                pkSecTime = int(packet.time)

                if currnetSec == -1:
                    currnetSec = pkSecTime

                if currnetSec == pkSecTime:
                    current_packets.append(packet)
                else:
                    out_file_nm = _out_file_template.format(
                        datetime.fromtimestamp(int(currnetSec)).strftime('%Y%m%d%H%M%S'))

                    print(f" parts pcap write >> : {out_file_nm} ")

                    cSplitsPcaps.writePcap(out_file_nm, current_packets)
                    current_packets = []
                    current_packets.append(packet)
                    currnetSec = pkSecTime

            if len(current_packets) > 0:
                out_file_nm = _out_file_template.format(
                    datetime.fromtimestamp(int(currnetSec)).strftime('%Y%m%d%H%M%S'))

                print(f" parts pcap write >> : {out_file_nm} ")

                cSplitsPcaps.writePcap(out_file_nm, current_packets)
                current_packets = []
                current_packets.append(packet)
                # currnetSec = pkSecTime

                pass

    @staticmethod
    def SplitsOnce(_source_file_name, _out_file_template):
        packets = rdpcap(_source_file_name)

        if not packets:
            return

        currnetSec = -1
        current_packets = []

        for packet in packets:
            pkSecTime = int(packet.time)

            if currnetSec == -1:
                currnetSec = pkSecTime

            # human_time = datetime.fromtimestamp(packet.time).strftime('%Y-%m-%d %H:%M:%S')
            # print(f"packet.time:{packet.time} h:{human_time} int:{pkSecTime} current:{currnetSec}")

            if currnetSec == pkSecTime:
                current_packets.append(packet)
            else:
                out_file_nm = _out_file_template.format(
                    datetime.fromtimestamp(int(currnetSec)).strftime('%Y%m%d%H%M%S'))

                print(f" parts pcap write >> : {out_file_nm} ")

                cSplitsPcaps.writePcap(out_file_nm, current_packets)
                current_packets = []
                current_packets.append(packet)
                currnetSec = pkSecTime
                pass
            # human_time = datetime.fromtimestamp(packet.time).strftime('%Y-%m-%d %H:%M:%S')

        if len(current_packets) > 0:
            out_file_nm = _out_file_template.format(
                datetime.fromtimestamp(int(currnetSec)).strftime('%Y%m%d%H%M%S'))

            print(f" parts pcap write >> : {out_file_nm} ")

            cSplitsPcaps.writePcap(out_file_nm, current_packets)
            current_packets = []
            current_packets.append(packet)
            # currnetSec = pkSecTime

            pass

        pass

    @staticmethod
    def SplitsOnce2(_source_file_name, _out_file_path, _out_file):
        packets = rdpcap(_source_file_name)

        if not packets:
            return

        currnetSec = -1
        current_packets = []

        for packet in packets:
            pkSecTime = int(packet.time)

            if currnetSec == -1:
                currnetSec = pkSecTime

            # human_time = datetime.fromtimestamp(packet.time).strftime('%Y-%m-%d %H:%M:%S')
            # print(f"packet.time:{packet.time} h:{human_time} int:{pkSecTime} current:{currnetSec}")

            if currnetSec == pkSecTime:
                current_packets.append(packet)
            else:
                outputFileTime = datetime.fromtimestamp(int(currnetSec)).strftime('%Y%m%d%H%M%S')
                out_file_nm = _out_file.format(outputFileTime)
                datePath = _out_file_path + outputFileTime[:8] + "\\" + outputFileTime[8:10] + "\\" + outputFileTime[
                                                                                                      10:12] + "\\" + out_file_nm

                print(
                    f" parts pcap write >> : {datePath}, {datetime.fromtimestamp(int(currnetSec)).strftime('%Y%m%d%H%M%S')} ")

                cSplitsPcaps.writePcap(datePath, current_packets)
                current_packets = []
                current_packets.append(packet)
                currnetSec = pkSecTime
                pass
            # human_time = datetime.fromtimestamp(packet.time).strftime('%Y-%m-%d %H:%M:%S')

        if len(current_packets) > 0:
            outputFileTime = datetime.fromtimestamp(int(currnetSec)).strftime('%Y%m%d%H%M%S')
            out_file_nm = _out_file.format(outputFileTime)
            datePath = _out_file_path + outputFileTime[:8] + "\\" + outputFileTime[8:10] + "\\" + outputFileTime[
                                                                                                  10:12] + "\\" + out_file_nm

            print(f" parts pcap write >> : {datePath} ")

            cSplitsPcaps.writePcap(datePath, current_packets)
            current_packets = []
            current_packets.append(packet)
            # currnetSec = pkSecTime

            pass

        pass


def main2():
    directory_path = """C:\\D\\dummyData\\real"""
    file_list = []
    for root, dirs, files in os.walk(directory_path):
        for file in files:
            file_list.append(os.path.join(root, file))
    return file_list


def splitPcaps(files):
    sensors = ["at128_roof_front", "at128_roof_right", "at128_roof_rear", "at128_roof_left"]
    for sen in sensors:
        directory_path = """C:\\D\\dummyData\\e-100\\lidar\\""" + sen + """\\"""
        output = sen + """_{}.pcap"""
        for _file in files:
            # pcapDate = _file.split("\\")[-1].split(".")[0][-14:-2]
            # tmpPath = directory_path + pcapDate[:8] + "\\" + pcapDate[8:10] + "\\" + pcapDate[10:12] + "\\"
            # print(tmpPath + output)
            cSplitsPcaps.SplitsOnce2(_file, directory_path, output)


def main():
    filename = """D:\\dt\\pcapTest\\pcaps5\\udp_dump_2023-09-11_16_50_46.pcap"""
    filename2 = """D:\\dt\\pcapTest\\pcaps5\\udp_dump_2023-09-11_16_51_46.pcap"""
    filename2 = """D:\\dt\\pcapTest\\pcaps5\\at128_roof_front.pcap"""

    out_file_templeate = """output_test_{}.pcap"""

    # cSplitsPcaps.SplitsOnce(filename,out_file_templeate)
    # cSplitsPcaps.SplitsList([filename , filename2],out_file_templeate)
    cSplitsPcaps.SplitsOnce(filename2, out_file_templeate)

    # cSplitsPcaps.SplitsTmp(filename , out_file_templeate)

    pass


def main3():
    all_files = []
    for root, dirs, files in os.walk("C:\\Users\\swmai\\Desktop\\realData"):
        for file in files:
            all_files.append(os.path.join(root, file))


    out_file_path = "C:\\Users\\swmai\\Desktop\\one_sec_data\\"

    # data = ["at128_roof_front"]
    # data = ["at128_roof_right"]
    # data = ["at128_roof_rear"]
    # data = ["at128_roof_left"]
    # data = ["rsbp_bump_front"]
    # data = ["rsbp_bump_right]
    # data = ["rsbp_bump_rear"]
    # data = ["rsbp_bump_left"]
    # data = ["gnss",
    #         "am20_front_center_right_down",
    #         "am20_front_right_rear",
    #         "am20_rear_center_right",
    #         "am20_front_left_rear",
    #         "am20_rear_right_edge",
    #         "am20_left_rear_edge",
    #         "am20_front_center_left_up",
    #         "am20_front_center_right_up",
    #         "am20_front_right_front",
    #         "am20_front_left_front"]

    for d in data:
        splitlist = []
        out_file_template = out_file_path
        for f in all_files:
            if f.split("\\")[-1].startswith(d):
                splitlist.append(f)

        out_file_name_template = d + """_{}.pcap"""

        if splitlist:
            out_file_template += d + "\\"
            os.makedirs(out_file_template, exist_ok=True)
            os.chmod(out_file_template, 0o777)
            cSplitsPcaps.SplitsList(splitlist, out_file_template + out_file_name_template)


    #
    # for d in data:
    #     out_file_template = out_file_path + d
    #     os.makedirs(out_file_template, exist_ok=True)




if __name__ == '__main__':
    main3()
    # pcapFiles = main2()
    # splitPcaps(pcapFiles)
