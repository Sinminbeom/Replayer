import os.path
from datetime import datetime


class cSplitedPcaps:

    def __init__(self, _epochTime, _packetTimeSec, _savePath, _position):
        self.epochTime = _epochTime
        self.packetTimeSec = _packetTimeSec
        self.savePath = _savePath
        self.position = _position

    def GetModuleName(self):
        basename = os.path.basename(self.savePath)

        return basename.replace("_" + basename.split("_")[-1], "")

    def GetDate(self):
        return self.packetTimeSec[:8]

    def GetHours(self):
        return self.packetTimeSec[8:10]

    def GetMinutes(self):
        return self.packetTimeSec[10:12]

    def GetSecond(self):
        return self.packetTimeSec[12:14]

    def GetEpochTime(self):
        return self.epochTime

    def GetPacketTimeSec(self):
        return self.packetTimeSec

    def GetSavePath(self):
        return self.savePath

    def GetPosition(self):
        return self.position

    def ToString(self):
        return "packetTimeSec : " + str(self.packetTimeSec) + " |^| " + \
            "ModuleName : " + self.GetModuleName() + " |^| " +\
            "savePath : " + self.savePath + " |^| " + \
            "position : " + self.position.value
