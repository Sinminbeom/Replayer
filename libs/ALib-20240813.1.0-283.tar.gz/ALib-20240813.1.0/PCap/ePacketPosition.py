from enum import Enum


class ePacketPosition(Enum):
    HEAD = "head"
    MID = "mid"
    TAIL = "tail"