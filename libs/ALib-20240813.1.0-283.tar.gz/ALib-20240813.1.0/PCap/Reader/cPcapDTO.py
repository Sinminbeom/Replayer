from PCap.Reader.IPCapDTO import IPCapDTO


class cPcapDTO(IPCapDTO):


    def __init__(self , _no ,
                 _time_stamp ,
                 _time_stamp_str ,
                 _offsetTime ,
                 _accumulateOffsetTime ):
        self.no = _no
        self.time_stamp = _time_stamp
        self.time_stamp_str = _time_stamp_str
        self.offsetTime = _offsetTime
        self.accumulateOffsetTime = _accumulateOffsetTime
        pass


    def getTimeStamp(self):
        return self.time_stamp

    def getTimeStr(self):
        return self.time_stamp_str

    def getOffSetTimeStamp(self):
        return self.offsetTime

    def getAccumulateOffSetTimeStamp(self):
        return self.accumulateOffsetTime

    def getNo(self):
        return self.no

    def getDataPayLoad(self):
        pass


    pass





