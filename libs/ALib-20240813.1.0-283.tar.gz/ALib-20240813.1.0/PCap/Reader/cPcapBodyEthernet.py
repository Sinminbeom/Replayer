from PCap.Reader.IPCap import IPCap
from PCap.Reader.PcapBody import abUdpPcapBody, abTcpPcapBody


class cUdpEthernet(abUdpPcapBody):

    def __init__(self):
        super().__init__(IPCap.E_LINK_TYPE.ETHERNET)


    def ParserPcap(self, data):

        self.data = data

        binary =self._getData()[23:24]
        self.protocol = int.from_bytes(binary, 'big')

        binary = self._getData()[26:26+4]
        self.source_address = '.'.join(map(str, binary))

        binary = self._getData()[30:30 + 4]
        self.destination_address = '.'.join(map(str, binary))

        binary = self._getData()[30 + 4:30 + 4 + 2]
        self.source_port = int.from_bytes(binary, 'big')

        binary = self._getData()[30 + 4 + 2:30 + 4 + 2 + 2]
        self.destination_port = int.from_bytes(binary, 'big')

        binary = self._getData()[39:39 + 2]
        self.length = int.from_bytes(binary, 'big')

        binary = self._getData()[40:40 + 2]
        self.checksum = int.from_bytes(binary, 'big')

        return self


class cTcpEthernet(abTcpPcapBody):

    def __init__(self):
        super().__init__(IPCap.E_LINK_TYPE.ETHERNET)

    def getDataLoad(self):
        return self.data[66:len(self.data)]


    def ParserPcap(self, data):

        self.data = data

        binary =self._getData()[23:24]
        self.protocol = int.from_bytes(binary, 'big')

        binary = self._getData()[26:26+4]
        self.source_address = '.'.join(map(str, binary))

        binary = self._getData()[30:30 + 4]
        self.destination_address = '.'.join(map(str, binary))

        binary = self._getData()[30 + 4:30 + 4 + 2]
        self.source_port = int.from_bytes(binary, 'big')

        binary = self._getData()[30 + 4 + 2:30 + 4 + 2 + 2]
        self.destination_port = int.from_bytes(binary, 'big')

        binary = self._getData()[57:57 + 1]
        self.length = int.from_bytes(binary, 'big')

        binary = self._getData()[50:50 + 2]
        self.checksum = int.from_bytes(binary, 'big')

        binary = self._getData()[46:46 + 2]
        ackAndPsh = int.from_bytes(binary[1:], "little") & IPCap.E_TCP_FLAG.ACK_AND_PSH

        self.ack = (ackAndPsh >> 3) & 1
        self.psh = (ackAndPsh >> 4) & 1

        return self