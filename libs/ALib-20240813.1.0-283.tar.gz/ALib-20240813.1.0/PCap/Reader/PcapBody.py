from abc import abstractmethod, ABC

from PCap.Reader.IPCap import IPCap


class abPcapBody(IPCap):

    def __init__(self, _link_type, _protocol):
        self.data = ''
        self.protocol = _protocol

        self.link_type = _link_type

        self.source_address = ""
        self.destination_address = ""
        self.source_port = ""
        self.destination_port = ""
        self.length = 0
        self.checksum = 0
        pass

    def _getData(self):
        return self.data

    def getDataLoad(self):
        return self.data[42:len(self.data)]

    def getOriginal(self):
        return self.data

    def getProtocol(self):
        return self.protocol
    def getSourceIpaddr(self):
        return self.source_address

    def getDestinationIpaddr(self):
        return self.destination_address

    @abstractmethod
    def ParserPcap(self , data):
        return None

    @staticmethod
    def Factory(_link_type , _pak_len ,  _file_point):

        from PCap.Reader.cPcapBodyEthernet import cUdpEthernet, cTcpEthernet
        from PCap.Reader.cPcapBodyinuxSll import cUdpLinuxSll, cTcpLinuxSll
        from PCap.Reader.cPcapBodyinuxSllV2 import cUdpLinuxSllV2, cTcpLinuxSllV2
        if _pak_len <= 0 :
            return None

        pcapBody = None

        data = _file_point.read(_pak_len)

        if _link_type == IPCap.E_LINK_TYPE.ETHERNET:
            protocol = int.from_bytes(data[23:24], "little")
            if protocol == IPCap.E_PROTOCOL.UDP:
                pcapBody = cUdpEthernet()
            else:
                pcapBody = cTcpEthernet()
        elif _link_type == IPCap.E_LINK_TYPE.LINUX_SLL:
            protocol = int.from_bytes(data[25:26], "little")
            if protocol == IPCap.E_PROTOCOL.UDP:
                pcapBody = cUdpLinuxSll()
            else:
                pcapBody = cTcpLinuxSll()
        elif _link_type == IPCap.E_LINK_TYPE.LINUX_SLL_V2:
            protocol = int.from_bytes(data[29:30], "little")
            if protocol == IPCap.E_PROTOCOL.UDP:
                pcapBody = cUdpLinuxSllV2()
            else:
                pcapBody = cTcpLinuxSllV2()

        # pcapBody.ParserPcap(  _pak_len , _file_point  )
        pcapBody.ParserPcap(data)

        return pcapBody


class abTcpPcapBody(abPcapBody, ABC):

    def __init__(self, _link_type):
        super().__init__(_link_type, IPCap.E_PROTOCOL.TCP)
        self.ack = 0
        self.psh = 0
        self.seqNum = 0

    def GetAck(self):
        return self.ack

    def GetPsh(self):
        return self.psh

    def GetSeqNum(self):
        return self.seqNum



class abUdpPcapBody(abPcapBody, ABC):

    def __init__(self, _link_type):
        super().__init__(_link_type, IPCap.E_PROTOCOL.UDP)
