from abc import ABC, abstractmethod

from PCap.Reader.IPCap import IPCap




class IPCapDTO(IPCap):

    @abstractmethod
    def getTimeStamp(self):
        pass

    @abstractmethod
    def getTimeStr(self):
        pass

    @abstractmethod
    def getOffSetTimeStamp(self):
        pass

    @abstractmethod
    def getAccumulateOffSetTimeStamp(self):
        pass

    @abstractmethod
    def getNo(self):
        pass

    @abstractmethod
    def getDataPayLoad(self):
        pass
