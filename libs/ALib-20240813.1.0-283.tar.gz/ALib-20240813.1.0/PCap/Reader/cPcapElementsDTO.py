from PCap.Reader.IPCapDTO import IPCapDTO
from PCap.Reader.cPcapDTO import cPcapDTO


class cPcapElementsDTO(IPCapDTO):

    def __init__(self , _no ,
                 _pcap_packet_header ,
                 _packet_body ,
                 _packet_dtoed_first=None ,
                 _packet_dtoed=None ,
                 _world_pcap_first_dto=None):

        self.no = _no
        if _pcap_packet_header == None or _packet_body == None:
            return

        self.time_stamp = _pcap_packet_header.getTimeStamp()
        # self.time_stamp_ns = self.time_stamp * 1000000000
        self.data_payload=_packet_body.getDataLoad()

        self.packet_header=_pcap_packet_header
        self.packet_body=_packet_body

        self.offsetTime=0
        # self.offsetTime_ns = 0
        self.__setOffsetTimestamp(_packet_dtoed)

        self.accumulateOffsetTime = 0
        # self.accumulateOffsetTime_ns = 0
        self.__setAccumulateOffsetTimestamp(_packet_dtoed_first)

        self.worldAccumulateOffsetTime = 0
        # self.worldAccumulateOffsetTime_ns = 0
        self.__setWorldAccumulateOffsetTimestamp(_world_pcap_first_dto)

    def getTimeStamp(self):
        return self.time_stamp

    def getTimeStampNS(self):
        return self.time_stamp * 1000000000

    def getTimeStr(self):
        return self.packet_header.getTimeStr()

    def getOffSetTimeStamp(self):
        return self.offsetTime

    def getOffSetTimeStampNS(self):
        return self.offsetTime * 1000000000

    def getAccumulateOffSetTimeStamp(self):
        return self.accumulateOffsetTime

    def getAccumulateOffSetTimeStampNS(self):
        return self.accumulateOffsetTime * 1000000000

    def getWorldAccumulateOffSetTimeStamp(self):
        return self.worldAccumulateOffsetTime

    def getWorldAccumulateOffSetTimeStampNS(self):
        return self.worldAccumulateOffsetTime * 1000000000

    def getNo(self):
        return self.no

    def getDataPayLoad(self):
        return self.data_payload

    def getPcapDto(self):
        return cPcapDTO(self.no ,
                        self.getTimeStamp() ,
                        self.getTimeStr() ,
                        self.getOffSetTimeStamp() ,
                        self.getAccumulateOffSetTimeStamp()
                        )


    def __setWorldAccumulateOffsetTimestamp(self , _world_pcap_first_dto=None):

        if _world_pcap_first_dto == None:
            self.worldAccumulateOffsetTime = self.accumulateOffsetTime
        else:
            self.worldAccumulateOffsetTime = self.getTimeStamp() - _world_pcap_first_dto.getTimeStamp()

    def __setAccumulateOffsetTimestamp(self , _packet_dtoed_first=None):
        if _packet_dtoed_first == None:
            self.accumulateOffsetTime = 0
            return

        self.accumulateOffsetTime = self.getTimeStamp() -  _packet_dtoed_first.getTimeStamp()

    def __setOffsetTimestamp(self , _packet_dtoed=None):
        if _packet_dtoed == None:
            self.offsetTime = 0
            return

        self.offsetTime = self.getTimeStamp() -  _packet_dtoed.getTimeStamp()


    def toString(self):

        mes=f""" no : {self.no} 
        time_stamp : {self.time_stamp} 
        offsetTime: {self.offsetTime}
        accumulateOffsetTime: {self.accumulateOffsetTime} 
        worldAccumulateOffsetTime: {self.worldAccumulateOffsetTime} 
"""
        return mes

