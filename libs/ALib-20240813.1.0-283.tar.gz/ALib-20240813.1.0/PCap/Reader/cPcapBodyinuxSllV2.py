from PCap.Reader.IPCap import IPCap
from PCap.Reader.PcapBody import abUdpPcapBody, abTcpPcapBody


class cUdpLinuxSllV2(abUdpPcapBody):

    def __init__(self):
        super().__init__(IPCap.E_LINK_TYPE.LINUX_SLL)



    def getDataLoad(self):
        return self.data[48:len(self.data)]

    def ParserPcap(self , data):
        self.data = data

        binary = self._getData()[29:29 + 1]
        self.protocol = int.from_bytes(binary, 'big')

        binary = self._getData()[32:32 + 4]
        self.source_address = '.'.join(map(str, binary))

        binary = self._getData()[36:36 + 4]
        self.destination_address = '.'.join(map(str, binary))

        binary = self._getData()[36 + 4:36 + 4 + 2]
        self.source_port = int.from_bytes(binary, 'big')

        binary = self._getData()[36 + 4 + 2:36 + 4 + 2 + 2]
        self.destination_port = int.from_bytes(binary, 'big')

        binary = self._getData()[44:44 + 2]
        self.length = int.from_bytes(binary, 'big')

        binary = self._getData()[46:46 + 2]
        self.checksum = int.from_bytes(binary, 'big')

        return self


class cTcpLinuxSllV2(abTcpPcapBody):

    def __init__(self):
        super().__init__(IPCap.E_LINK_TYPE.LINUX_SLL)

    def getDataLoad(self):
        return self.data[72:len(self.data)]

    def ParserPcap(self , data):

        self.data = data

        binary = self._getData()[29:30]
        self.protocol = int.from_bytes(binary, 'big')

        binary = self._getData()[32:32 + 4]
        self.source_address = '.'.join(map(str, binary))

        binary = self._getData()[36:36 + 4]
        self.destination_address = '.'.join(map(str, binary))

        binary = self._getData()[40:40 + 2]
        self.source_port = int.from_bytes(binary, 'big')

        binary = self._getData()[42:42 + 2]
        self.destination_port = int.from_bytes(binary, 'big')

        binary = self._getData()[44:44 + 4]
        self.seqNum = int.from_bytes(binary, 'big')

        binary = self._getData()[64:64 + 1]
        self.length = int.from_bytes(binary, 'big')

        binary = self._getData()[57:57 + 2]
        self.checksum = int.from_bytes(binary, 'big')

        binary = self._getData()[53:53 + 2]
        ackAndPsh = int.from_bytes(binary[1:], "little") & IPCap.E_TCP_FLAG.ACK_AND_PSH

        self.ack = (ackAndPsh >> 3) & 1
        self.psh = (ackAndPsh >> 4) & 1

        return self