from PCap.Reader.IPCap import IPcapReader
from PCap.Reader.PcapReader import cPcapReader
from PCap.Reader.cPcapDTO import cPcapDTO

class cPcapMultiReader(IPcapReader):



    def __init__(self):
        super().__init__()
        self.firstPcapDto=None
        pass

    def ReSet(self):
        self.firstPcapDto = None
        pass

    def __upsertFirstDTO(self ,_pcap_reader ):

        if self.firstPcapDto == None:
            pcapElementsDto = _pcap_reader.GetPcapHeadDTO().getElementsDTO()

            self.firstPcapDto = cPcapDTO(
                pcapElementsDto.getNo() ,
                pcapElementsDto.getTimeStamp() ,
                pcapElementsDto.getTimeStr(),
                pcapElementsDto.getOffSetTimeStamp(),
                pcapElementsDto.getAccumulateOffSetTimeStamp()
            )

    def PCapRead(self, _pcap_file_path, _filter_lamda=None ):
        reader = cPcapReader(_filter_lamda)
        reader.ReadPcap(_pcap_file_path, self.firstPcapDto)

        self.__upsertFirstDTO( reader )

        return reader

    def Close(self):

        pass


def FilterLamdaAct( _pcap_packet_header , _pcap_body ):

    if _pcap_body.getDestinationIpaddr() != "192.168.20.100":
        return True

    return False

#
# def main():
#
#     # pcap_file = """D:\\dt\\t1010\\at128_roof.pcap"""
#
#
#     pcap_file = """D:\\dt\\data_test\\at128_roof_rear_20231006165305.pcap"""
#     pcap_file2 = """D:\\dt\\data_test\\at128_roof_rear_20231006165306.pcap"""
#     pcap_file3 = """D:\\dt\\data_test\\at128_roof_rear_20231006165307.pcap"""
#     pcap_file4 = """D:\\dt\\data_test\\at128_roof_rear_20231006165308.pcap"""
#
#     import gc
#     while True:
#
#         pcapreader = cPcapMultiReader( )
#
#         pcapreader.PCapRead(pcap_file ,lambda _pcap_packet_header , _pcap_body : FilterLamdaAct( _pcap_packet_header , _pcap_body ) )
#         pcapreader.PCapRead(pcap_file2 ,lambda _pcap_packet_header , _pcap_body : FilterLamdaAct( _pcap_packet_header , _pcap_body ) )
#         pcapreader.PCapRead(pcap_file3 ,lambda _pcap_packet_header , _pcap_body : FilterLamdaAct( _pcap_packet_header , _pcap_body ) )
#         pcapreader.PCapRead(pcap_file4 ,lambda _pcap_packet_header , _pcap_body : FilterLamdaAct( _pcap_packet_header , _pcap_body ) )
#
#         pcapreader.ReSet()
#         #
#         # print("===============================================================================")
#         pcapreader.PCapRead(pcap_file,
#                             lambda _pcap_packet_header, _pcap_body: FilterLamdaAct(_pcap_packet_header, _pcap_body))
#         pcapreader.PCapRead(pcap_file2,
#                             lambda _pcap_packet_header, _pcap_body: FilterLamdaAct(_pcap_packet_header, _pcap_body))
#
#
#         gc.collect()
#
#
#         # time.sleep(0.1)
#
#
#
#
#     pass
#
#
# if __name__ == '__main__':
#     main()