from PCap.Reader.cPcapElementsDTO import cPcapElementsDTO


class cPcapElementsDTOFlagRapper:

    def __init__(self , _pcap_elements_dto ):
        self.pcapElementsDto = _pcap_elements_dto
        self.__setActive( True )


    def __setActive(self,_active):
        self.active=_active
        pass

    def getElementsDTO(self):
        return self.pcapElementsDto

    def SetActive(self , _active ):
        self.__setActive(_active)

    def IsActive(self):
        return self.active


    def toString(self):

        mes=f"""Active: {self.IsActive()} {self.pcapElementsDto.toString()} """
        return mes




class cPcapElementsPools:

    def __init__(self):
        ## cPcapElementsDTOFlagRapper( cPcapElementsDTO )
        self.pool=[]

        pass

    def Append(self , _dto ):
        self.pool.append(cPcapElementsDTOFlagRapper( _dto ) )

    def Get(self , _index ):
        return self.pool[_index]

    def GetPool(self):
        return self.pool

    def GetSize(self):
        return len(self.pool)

    def Clear(self):
        self.pool.clear()


    def __getActiveBufferIndex(self):
        left, right = 0, len(self.pool) - 1

        while left <= right:
            mid = (left + right) // 2

            if self.pool[mid].IsActive() and (mid == 0 or self.pool[mid - 1].IsActive() == False):
                return mid

            if self.pool[mid].IsActive():
                right = mid - 1
            else:
                # index = mid + 1
                left = mid + 1
        return -1

    def __getActiveBuffer(self):
        ind=self.__getActiveBufferIndex()
        print(f"ind:{ind}")

    def PopWithTimeStamp(self, _accumulate_offset_time ):
        self.__getActiveBuffer()
        pass

    def Println(self):


        for dto in self.pool:
            print(
                f" N : {dto.getElementsDTO().getNo():>5} "
                f" ts : {dto.getElementsDTO().getTimeStr()}  "
                f" t:{dto.getElementsDTO().getTimeStamp():<20} "
                f" of : {dto.getElementsDTO().getOffSetTimeStamp():<22} "
                f" auof : {dto.getElementsDTO().getAccumulateOffSetTimeStamp()} "
                f" w_auof : {dto.getElementsDTO().getWorldAccumulateOffSetTimeStamp()} "
                f" dpayload_size:{len(dto.getElementsDTO().getDataPayLoad())}")
            pass


        pass

#
# class gg(cPcapElementsDTO):
#     def __init__(self,_no):
#         cPcapElementsDTO.__init__(_no)


#
#
# def main():
#     cc=cPcapElementsPools()
#
#     cc.Append( cPcapElementsDTO( 1 , None , None ) )
#     cc.Append( cPcapElementsDTO( 2 , None , None ) )
#     cc.Append( cPcapElementsDTO( 3 , None , None ) )
#     cc.Append( cPcapElementsDTO( 4 , None , None ) )
#     cc.Append( cPcapElementsDTO( 5 , None , None ) )
#     cc.Append( cPcapElementsDTO( 6 , None , None ) )
#     cc.Append( cPcapElementsDTO( 7 , None , None ) )
#     cc.Append( cPcapElementsDTO( 8 , None , None ) )
#
#
#     cc.PopWithTimeStamp(0.1)
#
#     cc.Get(0).SetActive( False )
#
#     cc.Get(1).SetActive(False)
#     cc.Get(2).SetActive(False)
#     cc.Get(3).SetActive(False)
#
#     cc.PopWithTimeStamp(0.1)
#
#
#     pass
#
#
# if __name__ == '__main__':
#     main()
