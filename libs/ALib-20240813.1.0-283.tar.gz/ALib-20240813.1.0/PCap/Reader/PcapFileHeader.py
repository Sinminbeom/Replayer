from PCap.Reader.IPCap import IPCap


class cPcapFileHeader(IPCap):

    def __init__(self):
        # uint
        self.magic=0  ## 0xA1B2C3D4
        # ushort
        self.major=0
        # ushort
        self.minor=0
        # uint
        self.gmt_to_local=0
        # uint
        self.timestamp=0
        # uint
        self.max_caplen=0
        # uint
        self.linktype=0

    def getLinkType(self):
        return self.linktype

    def convertMaxCapLen(self):
        self.max_caplen = int.from_bytes(0x0000ffff.to_bytes(4, 'little'), 'little')


    def getOriginal(self):
        original = b""
        original += self.magic
        original += self.major.to_bytes(2, 'little')
        original += self.minor.to_bytes(2, 'little')
        original += self.gmt_to_local.to_bytes(4, 'little')
        original += self.timestamp.to_bytes(4, 'little')
        original += self.max_caplen.to_bytes(4, 'little')
        original += self.linktype.to_bytes(4, 'little')

        return original

    @staticmethod
    def Factory(_file_point):
        header = cPcapFileHeader()

        binary = _file_point.read(4)
        header.magic = binary
        # header.magic = int.from_bytes( bytedata , 'big' )

        binary = _file_point.read(2)
        header.major = int.from_bytes(binary , 'little')

        binary = _file_point.read(2)
        header.minor = int.from_bytes(binary, 'little')

        binary = _file_point.read(4)
        header.gmt_to_local = int.from_bytes(binary, 'little')

        binary = _file_point.read(4)
        header.timestamp = int.from_bytes(binary, 'little')

        binary = _file_point.read(4)
        header.max_caplen = int.from_bytes(binary, 'little')

        binary = _file_point.read(4)
        header.linktype = int.from_bytes(binary, 'little')

        return header
