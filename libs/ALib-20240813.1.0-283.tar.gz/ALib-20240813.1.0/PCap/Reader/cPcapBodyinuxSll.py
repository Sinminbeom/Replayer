from PCap.Reader.IPCap import IPCap
from PCap.Reader.PcapBody import abUdpPcapBody, abTcpPcapBody


class cUdpLinuxSll(abUdpPcapBody):

    def __init__(self):
        super().__init__(IPCap.E_LINK_TYPE.LINUX_SLL)



    def getDataLoad(self):
        return self.data[44:len(self.data)]

    def ParserPcap(self , data):

        self.data = data

        # binary =pcapBody.__getData()[23:24]
        binary = self._getData()[25:26]

        self.protocol = int.from_bytes(binary, 'big')

        # binary = pcapBody.__getData()[26:26+4]
        binary = self._getData()[28:28 + 4]
        self.source_address = '.'.join(map(str, binary))

        # binary = pcapBody.__getData()[30:30 + 4]
        binary = self._getData()[32:32 + 4]
        self.destination_address = '.'.join(map(str, binary))

        binary = self._getData()[36:36 + 2]
        self.source_port = int.from_bytes(binary, 'big')

        binary = self._getData()[38:38 + 2]
        self.destination_port = int.from_bytes(binary, 'big')

        # binary = pcapBody.__getData()[39:39 + 2]
        binary = self._getData()[40:40 + 2]
        self.length = int.from_bytes(binary, 'big')

        # binary = pcapBody.__getData()[40:40 + 2]
        binary = self._getData()[42:42 + 2]
        self.checksum = int.from_bytes(binary, 'big')


        return self


class cTcpLinuxSll(abTcpPcapBody):

    def __init__(self):
        super().__init__(IPCap.E_LINK_TYPE.LINUX_SLL)

    def getDataLoad(self):
        return self.data[68:len(self.data)]

    def ParserPcap(self , data):

        self.data = data

        # binary =pcapBody.__getData()[23:24]
        binary = self._getData()[25:26]

        self.protocol = int.from_bytes(binary, 'big')


        # binary = pcapBody.__getData()[26:26+4]
        binary = self._getData()[28:28 + 4]
        self.source_address = '.'.join(map(str, binary))

        # binary = pcapBody.__getData()[30:30 + 4]
        binary = self._getData()[32:32 + 4]
        self.destination_address = '.'.join(map(str, binary))

        binary = self._getData()[36:36 + 2]
        self.source_port = int.from_bytes(binary, 'big')

        binary = self._getData()[38:38 + 2]
        self.destination_port = int.from_bytes(binary, 'big')

        # binary = pcapBody.__getData()[39:39 + 2]
        binary = self._getData()[59:59 + 1]
        self.length = int.from_bytes(binary, 'big')

        # binary = pcapBody.__getData()[40:40 + 2]
        binary = self._getData()[52:52 + 2]
        self.checksum = int.from_bytes(binary, 'big')

        binary = self._getData()[48:48 + 2]
        ackAndPsh = int.from_bytes(binary[1:], "little") & IPCap.E_TCP_FLAG.ACK_AND_PSH

        self.ack = (ackAndPsh >> 3) & 1
        self.psh = (ackAndPsh >> 4) & 1

        return self