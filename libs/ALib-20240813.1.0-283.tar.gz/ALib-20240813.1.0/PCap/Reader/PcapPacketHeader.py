import datetime

from PCap.Reader.IPCap import IPCap


class cPcapPacketHeader(IPCap):
    def __init__(self):
        # uint
        self.captime = 0  ## // second
        # uint
        self.caputime = 0  ## // u second
        # uint
        self.caplen = 0
        # uint
        self.packlen = 0

    @staticmethod
    def Factory(_file_point):
        binary = _file_point.read(4)

        if len(binary) == 0 or binary == None:
            return None

        pcapPacketHeader = cPcapPacketHeader()
        # print(binary, end='')
        pcapPacketHeader.captime = int.from_bytes(binary, 'little')
        # print(pcapPacketHeader.captime.to_bytes(4, "little"))
        # print(binary, end='')
        binary = _file_point.read(4)
        pcapPacketHeader.caputime = int.from_bytes(binary, 'little')
        # print(binary, end='')
        binary = _file_point.read(4)
        pcapPacketHeader.caplen = int.from_bytes(binary, 'little')
        # print(binary)
        binary = _file_point.read(4)
        pcapPacketHeader.packlen = int.from_bytes(binary, 'little')

        return pcapPacketHeader

    def getTimeStamp(self):
        return self.captime + self.caputime / 1e6

    def getTimeStr(self):
        timestamp = self.captime + self.caputime / 1e6
        dt_object = datetime.datetime.fromtimestamp(timestamp)
        human_readable_time = dt_object.strftime('%Y-%m-%d %H:%M:%S.%f')

        return human_readable_time

    def getPacketLen(self):
        return self.packlen

    def getOriginal(self):
        original = b""
        original += self.captime.to_bytes(4, 'little')
        original += self.caputime.to_bytes(4, 'little')
        original += self.caplen.to_bytes(4, 'little')
        original += self.packlen.to_bytes(4, 'little')
        # print(original)
        return original

    def setCaptime(self, _captime):
        self.captime = _captime
        pass

    def setCaputime(self, _caputime):
        self.caputime = _caputime
        pass


