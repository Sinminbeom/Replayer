from abc import abstractmethod

from PCap.Reader.IENUM import IENUM


class IPCap:
    class E_TCP_FLAG(IENUM):
        ACK_AND_PSH = 24

    class E_PROTOCOL(IENUM):
        UDP = 17
        TCP = 6

    class E_LINK_TYPE(IENUM):
        ETHERNET = 1
        LINUX_SLL = 113
        LINUX_SLL_V2 = 276


    @abstractmethod
    def getOriginal(self):
        pass

    #
    #
    # def Shutdown(self):
    #     pass

    # def __del__(self):
    #     self.Shutdown()



class IPcapReader(IPCap):

    def __init__(self):
        super().__init__()

    def ReadPcap(self, _pcap_file_path, _world_pcap_first_dto=None):
        pass

    def Close(self):
        pass
