from PCap.Reader.IPCap import IPcapReader
from PCap.Reader.PcapBody import abPcapBody
from PCap.Reader.PcapElemensPool import cPcapElementsPools
from PCap.Reader.PcapFileHeader import cPcapFileHeader
from PCap.Reader.PcapPacketHeader import cPcapPacketHeader
from PCap.Reader.cPcapElementsDTO import cPcapElementsDTO

class cPcapReader(IPcapReader):

    def __init__(self, _filter_lamda=None):
        super().__init__()
        self.pcapFileHeader = None
        self.elementsPool = cPcapElementsPools()

        self._setFilter(_filter_lamda)

        pass

    def _setFilter(self, _filter_lamda):
        self.filter_lamda = _filter_lamda
        pass

    def _isFiltering(self, _pcap_packet_header, _pcap_body):

        # if self.filter_lamda == None:
        if self.filter_lamda is None:
            return False

        return self.filter_lamda(_pcap_packet_header, _pcap_body)

    def GetElementsPools(self):
        return self.elementsPool

    def GetPcapHeadDTO(self):
        return self.elementsPool.Get(0)

    def GetPoolSize(self):
        return self.elementsPool.GetSize()

    def ReadPcap(self, _pcap_file_path, _world_pcap_first_dto=None):

        packetIndex = 1
        pcapDtoedFirst = None
        pcapDtoed = None

        self.elementsPool.Clear()

        with open(_pcap_file_path, 'rb') as f:
            self.pcapFileHeader = cPcapFileHeader.Factory(f)

            while True:
                pcapPacketHeader = cPcapPacketHeader.Factory(f)

                if pcapPacketHeader is None:
                    break

                pcapBody = abPcapBody.Factory(self.pcapFileHeader.getLinkType(), pcapPacketHeader.getPacketLen(), f)

                pcapDto = cPcapElementsDTO(packetIndex, pcapPacketHeader, pcapBody, pcapDtoedFirst, pcapDtoed,
                                           _world_pcap_first_dto)

                if not self._isFiltering(pcapPacketHeader, pcapBody):
                    self.elementsPool.Append(pcapDto)
                    packetIndex += 1

                pcapDtoed = pcapDto
                if pcapDtoedFirst is None:
                    pcapDtoedFirst = pcapDto

        return self

    def Close(self):
        self.elementsPool.Clear()
        self.elementsPool = None
        self.pcapFileHeader = None


        pass


    def Println(self):
        self.elementsPool.Println()


## set logic to packet process filter~~
def FilterLamdaAct(_pcap_packet_header, _pcap_body):
    #
    if _pcap_body.getDestinationIpaddr() != "192.168.20.100":
        return True

    return False

