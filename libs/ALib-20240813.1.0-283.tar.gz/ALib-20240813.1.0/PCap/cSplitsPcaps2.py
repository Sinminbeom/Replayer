import os.path
import time
from datetime import datetime

from multipledispatch import dispatch

from PCap.Reader.PcapFileHeader import cPcapFileHeader
from PCap.Reader.PcapPacketHeader import cPcapPacketHeader
from PCap.cPacket import cPacket
from PCap.cSplitedPcapContainer import cSplitedPcapContainer
from PCap.ePacketPosition import ePacketPosition


class cSplitsPcaps:

    @staticmethod
    def SplitsOnce(_source_file_name, _out_file_template, _lock=None):
        if not os.path.exists(_source_file_name):
            raise FileNotFoundError("Check Path : " + _source_file_name)

        splitedPcapContainer = cSplitedPcapContainer()

        with open(_source_file_name, 'rb') as pcapFile:
            pcapFileHeader = cPcapFileHeader.Factory(pcapFile)
            pcapFileHeader.convertMaxCapLen()

            pcapFileIndex = 0
            currentSec = -1
            commonPacketHeader = None
            toBeSavedPackets = []

            while True:
                packetHeader = cPcapPacketHeader.Factory(pcapFile)

                if packetHeader is None:
                    if not toBeSavedPackets:
                        break

                    savedPacketTime = \
                        datetime.fromtimestamp(currentSec).strftime('%Y%m%d%H%M%S')

                    position = ePacketPosition.TAIL
                    saveFilePath = _out_file_template.format(savedPacketTime)

                    saveFilePath = cSplitsPcaps.WritePcap(saveFilePath, pcapFileHeader.getOriginal(), toBeSavedPackets, _lock)

                    splitedPcapContainer.Append(currentSec,
                                                savedPacketTime,
                                                saveFilePath,
                                                position)
                    break

                commonPacketHeader = packetHeader
                position = ePacketPosition.MID

                if currentSec == -1:
                    currentSec = int(commonPacketHeader.getTimeStamp())

                currentPacketTimeSec = int(commonPacketHeader.getTimeStamp())
                packetData = commonPacketHeader.getOriginal() + \
                             pcapFile.read(commonPacketHeader.getPacketLen())

                if currentSec == currentPacketTimeSec:
                    toBeSavedPackets.append(packetData)
                else:
                    savedPacketTime = datetime.fromtimestamp(currentSec).strftime('%Y%m%d%H%M%S')
                    saveFilePath = _out_file_template.format(savedPacketTime)

                    if pcapFileIndex == 0:
                        position = ePacketPosition.HEAD
                        pcapFileIndex = -1

                    saveFilePath = cSplitsPcaps.WritePcap(saveFilePath, pcapFileHeader.getOriginal(), toBeSavedPackets, _lock)

                    splitedPcapContainer.Append(currentSec,
                                                savedPacketTime,
                                                saveFilePath,
                                                position)

                    ## 시간 업데이트
                    currentSec = currentPacketTimeSec

                    ## 리스트 비우기
                    toBeSavedPackets.clear()
                    toBeSavedPackets.append(packetData)

        return splitedPcapContainer

    @staticmethod
    def WritePcap(out_file_path, pcapFileHeader, pcapPacket, _lock=None):

        file_name = os.path.basename(out_file_path)
        file_path = out_file_path.replace(file_name, "")


        if _lock is not None:
            with _lock:
                if not os.path.exists(file_path):
                    os.makedirs(file_path, exist_ok=True)
            with _lock:
                out_file_path = cSplitsPcaps._checkDuplicateWrite(out_file_path)
                with open(out_file_path, 'wb') as outFile:
                    outFile.write(pcapFileHeader)

                    for data in pcapPacket:
                        outFile.write(data)

        else:
            if not os.path.exists(file_path):
                os.makedirs(file_path, exist_ok=True)

            out_file_path = cSplitsPcaps._checkDuplicateWrite(out_file_path)
            with open(out_file_path, 'wb') as outFile:
                outFile.write(pcapFileHeader)

                for data in pcapPacket:
                    outFile.write(data)

        return out_file_path


    @staticmethod
    def _checkDuplicateWrite(out_file_path, originalPath=None, duplicateCount=0):
        if not os.path.exists(out_file_path):
            if duplicateCount != 0:
                file_name = os.path.basename(originalPath)
                file_path = originalPath.replace(file_name, "")
                splitedFileName = file_name.split(".")

                return file_path + splitedFileName[0] + "(" + str(duplicateCount) + ")" + "." + splitedFileName[1]

            return out_file_path

        if originalPath is None:
            originalPath = out_file_path

        file_name = os.path.basename(out_file_path)
        file_path = out_file_path.replace(file_name, "")

        duplicateCount += 1
        splitedFileName = file_name.split(".")

        if len(splitedFileName) != 2:
            raise ValueError("Not Valid FileName")

        originalFile_name = os.path.basename(originalPath)
        nextFileName = originalFile_name.split(".")[0] + "(" + str(duplicateCount) + ")" + "." + splitedFileName[-1]


        return cSplitsPcaps._checkDuplicateWrite(file_path + nextFileName, originalPath, duplicateCount)


    @staticmethod
    def MergePcapFiles(pcapFiles: list, _out_file_path):
        cSplitsPcaps._checkFileExist(pcapFiles)
        cSplitsPcaps._checkMergeAble(pcapFiles)

        import heapq
        sortedPcapPackets = []

        # pcapFileHeaders = dict()
        pcapFileHeaders = None
        for _file in pcapFiles:
            with open(_file, "rb") as pcapFile:
                pcapFileHeader = cPcapFileHeader.Factory(pcapFile)
                pcapFileHeader.convertMaxCapLen()

                # pcapFileHeaders[_file] = pcapFileHeader.getOriginal()
                pcapFileHeaders = pcapFileHeader.getOriginal()

                while True:
                    packetHeader = cPcapPacketHeader.Factory(pcapFile)
                    if packetHeader is None:
                        break

                    packetData = packetHeader.getOriginal() + \
                                 pcapFile.read(packetHeader.getPacketLen())

                    packet = cPacket(_file, packetHeader.captime, packetHeader.caputime, packetData)

                    heapq.heappush(sortedPcapPackets, packet)

        file_name = os.path.basename(_out_file_path)
        file_path = _out_file_path.replace(file_name, "")

        if not os.path.exists(file_path):
            os.makedirs(file_path)

        with open(_out_file_path, 'wb') as outFile:
            outFile.write(pcapFileHeaders)

            while sortedPcapPackets:
                packetDto = heapq.heappop(sortedPcapPackets)
                outFile.write(packetDto.GetPacketData())

        pass

    @staticmethod
    def _checkFileExist(pcapFiles: list):
        # Check File Exist
        for pcapFile in pcapFiles:
            if not os.path.exists(pcapFile):
                raise FileNotFoundError("[ERROR] File Not Found: " + pcapFile)

    @staticmethod
    def _checkMergeAble(pcapFiles: list):

        linkTypes = set()
        for pcapFile in pcapFiles:
            with open(pcapFile, "rb") as pcapFile:
                pcapFileHeader = cPcapFileHeader.Factory(pcapFile)
                linkTypes.add(pcapFileHeader.getLinkType())

            if len(linkTypes) != 1:
                raise ValueError("[ERROR] Merge between different LinkType is not possible.")





if __name__ == '__main__':
    start = time.time()
    # once = cSplitsPcaps.SplitsOnce('C:\\Users\\swmai\\Desktop\\a20231018\\ttt\\test.pcap',
    #                                """C:\\Users\\swmai\\Desktop\\a20231018\\test123\\out_{}.pcap""")

    # original = "C:\\Users\\swmai\\Desktop\\swm\\gnss\\one_sec\\test2\\split\\"
    # fileList = os.listdir(original)
    # p = []
    # for f in fileList:
    #     p.append(original + f)
    #
    # for i in range(2, len(p) + 1):
    #     name = "C:\\Users\\swmai\\Desktop\\swm\\gnss\\one_sec\\test2\\split\\merged\\gnss_20240130142100_" + str(i) + ".pcap"
    #     cSplitsPcaps.MergePcapFiles(p[:i], name)

    cSplitsPcaps.MergePcapFiles(
        [
            "C:\\Users\\swmai\\Desktop\\swm\\gnss\\one_sec\\test\\gnss_20240130142116.pcap",
            "C:\\Users\\swmai\\Desktop\\swm\\gnss\\one_sec\\test\\gnss_20240130142117.pcap"
        ]
                                , "C:\\Users\\swmai\\Desktop\\swm\\gnss\\one_sec\\test\\gnss_20240130142100_1617.pcap")



    #
    # print(fileList)
    # p = []
    # for f in fileList:
    #     p.append(original + f)
    #
    #
    # cSplitsPcaps.MergePcapFiles(p, "C:\\Users\\swmai\\Desktop\\swm\\gnss\\one_sec\\mergeFile39.pcap")


    print("During Time", time.time() - start)

    # for k, v in once.GetSplitedPcaps().items():
    #     print(k, v.ToString())

    # start = time.time()
    # import threading
    # lock = threading.Lock()
    #
    # threads = []
    # for i in range(5):  # 5개의 스레드 생성
    #     thread = threading.Thread(target=cSplitsPcaps.SplitsOnce, args=('C:\\Users\\swmai\\Desktop\\a20231018\\ttt\\test.pcap',
    #                                """C:\\Users\\swmai\\Desktop\\a20231018\\test1234\\out_{}.pcap""",lock,))
    #     threads.append(thread)
    #     thread.start()
    #
    # # 모든 스레드가 종료될 때까지 기다림
    # for thread in threads:
    #     thread.join()
    #
    # print("During Time", time.time() - start)

    # print()
    # print("======================================")
    # print()
    # for i in once.GetProcessedPcaps():
    #     print(i.ToString())
    #
    # print()
    # print("======================================")
    # print()
    # for i in once.GetUnProcessedPacps():
    #     print(i.ToString())

    # cSplitsPcaps.SplitsOnce('C:\\Users\\swmai\\Desktop\\a20231018\\ttt\\at128_roof_rear_20231006165315.pcap', "None")
