from Utils.cTimeStringFit import cTimeStringInterVal





class PCapNormalization:
    @staticmethod
    def Normalization(pcap_file, target_dir, time_string_interval:cTimeStringInterVal ):



        pass

    # def Normalization(pcap_file , target_dir , time_string_interval   cTimeStringInterVal( E_CALENDAR_TYPE.SEC , 4 ) ):
    #
    #     pass
    pass
