class cPacket:
    def __init__(self, _baseFileName, _capturedTimeSec, _capturedTimeNano, _packetData):
        self.baseFileName = _baseFileName
        self.capturedTimeSec = _capturedTimeSec
        self.capturedTimeNano = _capturedTimeNano
        self.packetData = _packetData

    def __lt__(self, other):
        if self.capturedTimeSec == other.capturedTimeSec:
            if self.capturedTimeNano == other.capturedTimeNano:
                return self.baseFileName < other.baseFileName
            return self.capturedTimeNano < other.capturedTimeNano
        return self.capturedTimeSec < other.capturedTimeSec

    def GetBaseFileName(self):
        return self.baseFileName

    def GetCapturedTimeSec(self):
        return self.capturedTimeSec

    def GetCapturedTimeNano(self):
        return self.capturedTimeNano

    def GetPacketData(self):
        return self.packetData
