import hashlib

from LibUtils.FileLists import FileLists
from LibUtils.HashUtils import HashUtils


class cFileObjectKeyDto:
    def __init__(self, _index, _path, _mode):
        self.index = _index
        self.filename = FileLists.extractFileName(_path, seperator="/")
        self.filepath = _path.replace(self.filename, "")
        self.hash = HashUtils.encode(_path, _mode)

    def GetIndex(self):
        return self.index

    def GetFilepath(self):
        return self.filepath

    def GetFilename(self):
        return self.filename

    def GetHash(self):
        return self.hash

    def ToString(self):
        return "index : " + str(self.index) + \
            "  |  filepath : " + self.filepath + \
            "  |  filename : " + self.filename + \
            "  |  hash : " + self.hash




#
#
#
#
# if __name__ == '__main__':
#     dto= cFileObjectKeyDto(1, "/b/c/d/e.txt")
#     dto2= cFileObjectKeyDto(1, "/b/c/d/e.txt")
#
#     print(HashUtils.make(str(1), "/b/c/d/e.txt"))
#     print(HashUtils.isEqual(dto.GetHash(), str(1), "/b/c/d/e.txt"))

    # print(dto.GetHash())
    # print(dto.GetFilepath())
    # print(dto.GetFilename())
    # print(dto2.GetHash())
    # print(dto2.GetFilepath())
    # print(dto2.GetFilename())