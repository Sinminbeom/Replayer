import os
from abc import ABC, abstractmethod

from ObjectStorage2.Dtos.IStorageResultDTO import cLocalResultDTO, cMinioResultDTO, cHadoopResultDTO


class cObjectStorageEndPointRep(ABC):


    def __init__(self  ,
                 storageEndpoint : object = None ):

        self._stoageEndpoint = storageEndpoint
        pass

    def setStorageEndpoint(self , storageEndpoint : object):
        self._stoageEndpoint = storageEndpoint


    def getStorageEndPoint(self):
        return self._stoageEndpoint

    @abstractmethod
    def List(self , _path , _depth , _status = None ):
        pass

    @abstractmethod
    def list_objects(self , _bucket , _prefix , _recursive = None ):
        pass

    @abstractmethod
    def Walk(self , _path , _depth ): pass


    def Stat(self , _path ):
        return None




    def IsDir(self):
        return None








class cHadoopObjectStorageEndPointRep (cObjectStorageEndPointRep ) :

    def __init__(self,
                 storageEndpoint : object = None):
        super().__init__(storageEndpoint)

    def List(self, _path, _depth , _status = None ):
        return cHadoopResultDTO(
                native_file_lists = self.getStorageEndPoint().walk(
                        hdfs_path = _path ,
                        depth = _depth ,
                        status = _status
                    )
        )

    def list_objects(self , _bucket , _prefix , _recursive = None ):
        pass

    def Walk(self , _path , _depth ):
        pass

    pass


class cMinioObjectStorageEndPointRep(cObjectStorageEndPointRep):

    def __init__(self,
                 storageEndpoint: object = None):
        super().__init__(storageEndpoint)

    def List(self , _path , _depth , _status = None ):
        pass

    def list_objects(self , _bucket , _prefix , _recursive = None ):
        return cMinioResultDTO(
                native_file_lists = self.getStorageEndPoint().list_objects(
                    _bucket ,
                    prefix = _prefix ,
                    recursive = _recursive
                )
        )

    def Walk(self, _path, _depth):
        pass
    pass

class cLocalObjectStorageEndPointRep(cObjectStorageEndPointRep):

    def __init__(self):
        super().__init__()

    ## LIST ##

    def List(self , _path , _depth , _status = None ):

        resultDTOLists = []
        for root, dirs, files in os.walk(_path):
            if _path == root:
                resultDTOLists.append(
                    cLocalResultDTO(
                        current_dir=root,
                        dirs=dirs,
                        files=files
                    )
                )

                return resultDTOLists
        pass

    def list_objects(self , _bucket , _prefix , _recursive = None ):
        pass


    def Stat(self , _path ):

        from ObjectStorage2.Local.cLocalFileUtil import cLocalFileUtil
        localFileStatDto = cLocalFileUtil.Stat( _path )

        from ObjectStorage2.Local.cLocalFileNativeObject import cLocalFileNativeObject
        from ObjectStorage2.Local.cLocalObjectProperty import cLocalObjectProperty

        return cLocalObjectProperty(
            cLocalFileNativeObject(
                current_dir=localFileStatDto.getPath(),
                object_name=localFileStatDto.getFileName(),
                is_dir=localFileStatDto.IsDir(),
                file_stat=localFileStatDto.getFileStat()
            )
        )


    def Delete(self , _path):

        localObjectProperty = self.Stat(_path)

        if localObjectProperty.IsDir() :
            import shutil
            shutil.rmtree(_path)
        else:
            os.remove(_path)



    def IsDir(self , path ):
        return os.path.isfile(path)


    def Walk(self, _path, _depth):

        resultDTOLists = []
        for root, dirs, files in os.walk(_path):
            # if _path == root:
            resultDTOLists.append(
                    cLocalResultDTO (
                    current_dir = root ,
                    dirs = dirs ,
                    files = files
                )
            )

        return resultDTOLists

    pass


