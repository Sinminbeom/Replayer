from abc import abstractmethod

from ObjectStorage2.Dtos.IStorageResultDTO import abStorageResultDTO
from ObjectStorage2.IContainer import IContainer


class abStorageObjectContainer(IContainer):

    def __init__(self, _storageType, _storage_reslut_dto : abStorageResultDTO):

        self.storageObjectProperties = []

        # self.storageObjectProperties = self._parse(_storageType, _nativeFiles)

        self._parse(_storageType, _storage_reslut_dto)

    @abstractmethod
    def _parse(self, _storageType, _files):
        pass

    def getFolders(self):
        folders = []
        for _file in self.storageObjectProperties:
            if not _file.IsDir():
                continue
            folders.append(_file)

        return folders

    def getFiles(self):
        files = []
        for _file in self.storageObjectProperties:
            if _file.IsDir():
                continue
            files.append(_file)

        return files

    def GetStorageObjectProperties(self):
        return self.storageObjectProperties
