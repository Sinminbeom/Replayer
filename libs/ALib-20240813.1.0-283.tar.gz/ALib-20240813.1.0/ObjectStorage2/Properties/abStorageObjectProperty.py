from abc import abstractmethod

from ObjectStorage2.Properties.IStorageObjectProperty import IStorageObjectProperty


class abStorageObjectProperty(IStorageObjectProperty):

    def __init__(self, _storageType, _fileObject):
        self.storageType = _storageType
        self.fileObject = _fileObject

    def GetStorageType(self):
        return self.storageType

    def GetFile(self):
        return self.fileObject

    def ToString(self):
        return "GetFilePath : " + self.GetFilePath()  + "  " \
            "GetFileName : " + self.GetFileName()  + "  " \
            "GetSize : " + str(self.GetSize())  + "  " \
            "GetOwner : " + self.GetOwner()  + "  " \
            "GetLastModified : " + str(self.GetLastModified())  + "  "  \
            "IsDir : " + str(self.IsDir())

    @abstractmethod
    def GetFileName(self):
        pass

    @abstractmethod
    def GetObjectName(self):
        pass

    @abstractmethod
    def GetObjectPath(self):
        pass

    @abstractmethod
    def GetFilePath(self):
        pass

    @abstractmethod
    def GetSize(self):
        pass

    @abstractmethod
    def GetLastModified(self):
        pass

    @abstractmethod
    def GetOwner(self):
        pass

    @abstractmethod
    def IsDir(self):
        pass