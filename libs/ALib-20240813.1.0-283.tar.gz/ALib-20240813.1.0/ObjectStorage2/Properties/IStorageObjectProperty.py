from abc import abstractmethod


class IStorageObjectProperty:

    @abstractmethod
    def GetFileName(self):
        pass

    @abstractmethod
    def GetObjectName(self):
        pass

    @abstractmethod
    def GetObjectPath(self):
        pass

    @abstractmethod
    def GetFilePath(self):
        pass

    @abstractmethod
    def GetSize(self):
        pass

    @abstractmethod
    def GetLastModified(self):
        pass

    @abstractmethod
    def GetOwner(self):
        pass

    @abstractmethod
    def IsDir(self):
        pass

