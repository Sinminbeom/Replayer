import os.path
import time
from typing import Callable

from hdfs import HdfsError
from minio import S3Error
from multipledispatch import dispatch

from Log.cLogger import cLogger, E_LOG
from ObjectStorage2.IObjectStorage import IObjectStorage, E_FILE_MODE
from ObjectStorage2.IObjectStorageConnectInfoDto import IObjectStorageConnectInfoDto
from ObjectStorage2.abFileObjectContainer import abFileObjectContainer
from ObjectStorage2.cFileObjectKeyDto import cFileObjectKeyDto


class abObjectStorage(IObjectStorage):

    def __init__(self, _storageType, _connectInfoDto: IObjectStorageConnectInfoDto,
                 _fileObjectContainer: abFileObjectContainer):
        # os.environ['ARROW_LIBHDFS_DIR'] = 'C:\\Users\\swmai\\Desktop\\swm\\hadoop\\hadoop-3.3.4\\lib\\native\\'

        self.storageType = _storageType
        self.connectInfoDto = _connectInfoDto
        self.fileObjectContainer = _fileObjectContainer
        self.storageEndPointRep = None

    @staticmethod
    def ofHadoop(_address, _port, _access_key, _retryCount: int = 1, _interval: float = 0.1) -> IObjectStorage:
        from ObjectStorage2.Hadoop.cHadoopStorageConnectInfoDto import cHadoopStorageConnectInfoDto
        from ObjectStorage2.Hadoop.cHadoopStorage import cHadoopStorage

        return cHadoopStorage(cHadoopStorageConnectInfoDto(_address, _port, _access_key, _retryCount, _interval))


    @staticmethod
    def ofMinio(_address, _port, _access_key, _access_passwd, _bucket, _retryCount: int = 1, _interval: float = 0.1) -> IObjectStorage:
        from ObjectStorage2.Minio.cMinioStorageConnectInfoDto import cMinioStorageConnectInfoDto
        from ObjectStorage2.Minio.cMinioStorage import cMinioStorage

        return cMinioStorage(cMinioStorageConnectInfoDto(_address, _port, _access_key, _access_passwd, _bucket, _retryCount, _interval))

    def Run(self, func: Callable):

        retryCount = self.connectInfoDto.GetRetryCount()
        exception = None
        while retryCount > 0:
            try:
                try:
                    return func()
                except HdfsError or S3Error or FileNotFoundError as raiseError:
                    exception = raiseError
                    break
            except Exception as e:
                exception = e
                retryCount -= 1
                time.sleep(self.connectInfoDto.GetInterval())

        raise Exception(exception)

    def Connect(self):
        self.storageEndPointRep = self.connectInfoDto.Connect()

    def Disconnect(self):
        # self.storage.close()
        self.storageEndPointRep = self.connectInfoDto.Disconnect()


    def Open(self, _filePath, _mode: E_FILE_MODE):
        if _mode == E_FILE_MODE.WRITE:
            return self.fileObjectContainer.Append(self, _filePath, 0, _mode)

        if self.IsDir(_filePath):
            cLogger.instance().Print(E_LOG.ERROR, "The path you entered is not a file.")
            raise TypeError()

        if _mode == E_FILE_MODE.READ:
            self.Stat(_filePath)
            return self.fileObjectContainer.Append(self, _filePath, self.Stat(_filePath).GetSize(), _mode)

        raise FileNotFoundError()


    @dispatch(str)
    def Close(self, _hash):
        self.fileObjectContainer.Delete(_hash)

    @dispatch(cFileObjectKeyDto)
    def Close(self, _dto: cFileObjectKeyDto):
        self.Close(_dto.GetHash())

    @dispatch(str)
    def GetFileObject(self, _hash):
        return self.fileObjectContainer.Get(_hash)

    @dispatch(cFileObjectKeyDto)
    def GetFileObject(self, _dto: cFileObjectKeyDto):
        return self.GetFileObject(_dto.GetHash())

    def GetStorageEndPoint(self):
        return self.storageEndPointRep


    def _makeFitObjectStoragePath(self, _path):
        liPath = list(_path)
        if liPath[0] != "/":
            _path = "/" + _path

        if liPath[-1] != "/":
            return _path + "/"
        return _path

    def _convertObjectStoragePath(self, _path):
        tmp1 = _path.replace("\\", "/")
        tmp2 = tmp1.replace("\\\\", "/")

        if tmp2[0] == "/":
            return tmp2[1:]
        return tmp2

    def _getUpperPath(self, _path):
        tmpPath = self._makeFitObjectStoragePath(_path)
        if tmpPath == "/":
            return tmpPath

        split = tmpPath.split("/")[:-2]
        if split == ['']:
            return "/"
        return "/".join(split)

    def _makeUploadPath(self, _path):
        if self._checkContainsFilename(_path):
            filename = os.path.basename(_path)
            return _path.replace(filename, "")
        if _path[-1] != "/":
            return _path + "/"
        return _path


    def _checkContainsFilename(self, _path):
        tmp = os.path.basename(_path)
        if len(tmp.split(".")) == 2:
            return True
        return False





