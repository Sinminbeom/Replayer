from enum import Enum


class eStorageType(Enum):
    LOCAL = "local"
    MINIO = "minio"
    HADOOP = "hadoop"
