from abc import abstractmethod


class IObjectStorageConnectInfoDto:

    @abstractmethod
    def Connect(self):
        pass

    @abstractmethod
    def Disconnect(self):
        pass

    @abstractmethod
    def GetRoot(self):
        """
            Hadoop has no bucket concept, so if you call that method, you return "/"
            Minio returns a bucket because of the bucket concept.

            return: Hadoop -> "/" |^| Minio -> "bucketName"
        """
        pass

    @abstractmethod
    def GetAddress(self):
        pass

    @abstractmethod
    def GetPort(self):
        pass

    @abstractmethod
    def GetAccess_id(self):
        pass

    @abstractmethod
    def GetRetryCount(self):
        pass

    @abstractmethod
    def GetInterval(self):
        pass
