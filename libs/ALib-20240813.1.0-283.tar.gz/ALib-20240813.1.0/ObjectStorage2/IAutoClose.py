from abc import abstractmethod


class IAutoClose:
    @abstractmethod
    def close(self):
        pass