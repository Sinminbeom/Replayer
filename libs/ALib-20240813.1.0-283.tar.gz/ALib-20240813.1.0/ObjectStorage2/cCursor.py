

class cCursor:
    def __init__(self, _index = 0):
        self.index = _index

    def Reset(self):
        self.index = 0

    def Seek(self, _position):
        self.index += _position

    def GetIndex(self):
        return self.index
