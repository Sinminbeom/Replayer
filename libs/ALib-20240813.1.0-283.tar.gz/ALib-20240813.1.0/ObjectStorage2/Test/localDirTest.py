import os


def main():
    folder_path = "D:\\doc"
    txt_files = []

    for root, dirs, files in os.walk(folder_path):

        # if folder_path == root :

        print("현재 디렉토리(root):", root)
        print("하위 디렉토리 목록(dirs):", dirs)
        print("파일 목록(files):", files)
        print("-" * 50)  # 구분선
    #
    # for root, _, files in os.walk(folder_path):
    #     for file in files:
    #         print(file)
    #
    #         # if file.endswith(".txt"):
    #         #     txt_files.append(os.path.join(root, file))

    print("모든 TXT 파일:", txt_files)
    pass


if __name__ == '__main__':
    main()