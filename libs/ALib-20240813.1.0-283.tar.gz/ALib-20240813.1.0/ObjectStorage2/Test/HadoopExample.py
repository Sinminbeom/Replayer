import time

from ObjectStorage2.Hadoop.cHadoopStorage import cHadoopStorage
from ObjectStorage2.Hadoop.cHadoopStorageConnectInfoDto import cHadoopStorageConnectInfoDto
from ObjectStorage2.IObjectStorage import E_FILE_MODE


def hdfs():
    connect_info_dto = cHadoopStorageConnectInfoDto("192.168.1.79", "50070", "swmai", _retryCount=10)

    return cHadoopStorage(connect_info_dto)


def StatEx():
    storage = hdfs()
    storage.Connect()
    # stat = storage.Stat("/data/test/t4")
    stat = storage.Stat("/data-warehouse")
    print(stat.ToString())


def ListEx():
    storage = hdfs()
    storage.Connect()
    fileList = storage.List("/data-warehouse-test")
    # fileList = storage.List("/data-warehouse-test/20231212")
    # fileList = storage.List("/data-warehouse-test/20231212/T-Car01")
    for _file in fileList:
        print(_file.ToString())


def WalkEx():
    storage = hdfs()
    storage.Connect()
    start = time.time()
    storage.Walk("/normalized-data-storage-test/E100-2")
    print(time.time() - start)
    # fileList = storage.Walk("/normalized-data-storage-test/E100-2")
    # print(len(fileList))
    # for _file in fileList:
    #     print(_file.ToString())


def UploadEx():
    # Upload
    storage = hdfs()
    storage.Connect()
    # storage.Upload("C:\\Users\\swmai\\Desktop\\a20231018", "/test")
    # storage.Upload("C:\\Users\\swmai\\Desktop\\a20231018\\at128_roof_front.pcap", "/test/test1/at128_roof_front.pcap")
    # storage.Upload("C:\\Users\\swmai\\Desktop\\p20230727\\video_1.pcap", "/data2")

    # storage.UploadFolder("C:\\Users\\swmai\\Desktop\\a20231018", "/test/sangwon")
    storage.UploadFile("C:\\Users\\swmai\\Desktop\\a20231018\\at128_roof_front.pcap", "/test/sangwon/at128_roof_front.pcap") ## 정상
    storage.UploadFile("C:\\Users\\swmai\\Desktop\\a20231018\\at128_roof_front.pcap", "/test/sangwon/test123") ## 비정상
    pass


def DownloadEx():
    # Download
    storage = hdfs()
    storage.Connect()
    # storage.Download("/")

    storage.Download("/normalized-data-storage-test/E100-3/gnss/gnss/20240130/14/39", "C:\\Users\\swmai\\Desktop\\swm\\gnss\\one_sec\\")
    # storage.Download("/data2/video_1.pcap", "C:\\Users\\swmai\\Desktop\\asdfasdf")
    pass



def DownloadExTmp():
    import os
    import shutil
    # # Download
    # storage = hdfs()
    # storage.Connect()
    #
    # for i in range(60):
    #     minute = str(i).zfill(2)
    #
    #     downloadPath = "/normalized-data-storage-test/E100-2/gnss/gnss/20240201/14/" + minute
    #     savePath = "C:\\Users\\swmai\\Desktop\\swm\\gnss\\one_sec\\"
    #     storage.Download(downloadPath, savePath)
    #
    #     fileList = os.listdir(savePath + minute)
    #     upperDir = os.path.dirname(savePath + minute)
    #
    #     for f in fileList:
    #         tmpFilePath = os.path.join(savePath + minute, f)
    #         if not os.path.isfile(tmpFilePath):
    #             continue
    #
    #         shutil.move(tmpFilePath, upperDir)


    pass


    pass

def DeleteEx():
    # Delete
    storage = hdfs()
    storage.Connect()
    storage.Delete("/data2/video_1.pcap2")
    storage.Delete("/data2/video_1.pcap1")
    # print(storage.IsDir("/data2"))
    # print(storage.IsDir("/data2/video_1.pcap1"))
    pass


def OpenEx():
    storage = hdfs()
    storage.Connect()
    # Open
    keyDto = storage.Open("/data2/video_1.pcap1", E_FILE_MODE.READ)
    print(keyDto.ToString())
    print(keyDto.GetHash())
    print(storage.GetFileObject(keyDto.GetHash()))
    print(storage.GetFileObject(keyDto))

    p1 = storage.Open("/data2/video_1.pcap2", E_FILE_MODE.READ)
    p2 = storage.Open("/data2/video_1.pcap3", E_FILE_MODE.READ)
    p4 = storage.Open("/data2/video_1.pcap4", E_FILE_MODE.READ)
    p5 = storage.Open("/data2/video_1.pcap5", E_FILE_MODE.READ)
    p6 = storage.Open("/data2/video_1.pcap6", E_FILE_MODE.READ)
    p7 = storage.Open("/data2/video_1.pcap7", E_FILE_MODE.READ)

    p1_object = storage.GetFileObject(p1)
    p1_object.Close()
    # storage.Close(p1)
    storage.GetFileObject(p2)

def ReadEx():
    storage = hdfs()
    storage.Connect()
    from ObjectStorage2.IObjectStorage import E_FILE_MODE
    # openFileKeyDto = storage.Open("/normalized-data-storage-test/E100-2/gnss/gnss/20240125/10/56/gnss_20240125105624.pcap", E_FILE_MODE.READ)
    # file_object = storage.GetFileObject(openFileKeyDto)

    # print(file_object.ReadAll())
    # print(len(file_object.ReadAll()))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.size)
    # print(file_object.Read(file_object.size))
    # file_object.Seek(-file_object.size)
    # print(file_object.Read())

def WriteEx():
    storage = hdfs()
    storage.Connect()
    from ObjectStorage2.IObjectStorage import E_FILE_MODE
    ## READ ALL
    write_openFileKeyDto = storage.Open("/data/test123/asdflkjsadf.txt", E_FILE_MODE.WRITE)
    read_openFileKeyDto = storage.Open("/data/test123/asdflkjsadf.txt", E_FILE_MODE.READ)

    file_object = storage.GetFileObject(write_openFileKeyDto)

    file_object.Write("hello my name is sangwon")
    print(file_object.size)

    time.sleep(1)

    file_object2 = storage.GetFileObject(read_openFileKeyDto)
    print(file_object2.ReadAll())

    try:
        file_object2.Write("asdfasdfasdf")
    except Exception as e:
        print("Access Check True")

    storage.Disconnect()


if __name__ == '__main__':
    # print("StatEx()")
    # StatEx()
    # print("ListEx()")
    # ListEx()
    # print("WalkEx()")
    # WalkEx()
    # print("UploadEx()")
    # UploadEx()
    print("DownloadEx()")
    DownloadEx()
    # DownloadExTmp()
    # print("DeleteEx()")
    # DeleteEx()
    # print("OpenEx()")
    # OpenEx()
    # print("ReadEx()")
    # ReadEx()
    # print("WriteEx()")
    # WriteEx()
    pass

