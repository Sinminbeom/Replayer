import time

from ObjectStorage2.IObjectStorage import E_FILE_MODE
from ObjectStorage2.Minio.cMinioStorage import cMinioStorage
from ObjectStorage2.Minio.cMinioStorageConnectInfoDto import cMinioStorageConnectInfoDto


def hdfs():
    connect_info_dto = cMinioStorageConnectInfoDto("192.168.1.248",
                                                   "9000",
                                                   "oracle",
                                                   "oracleoracleoracle",
                                                   # "t1-raw-data")
                                                   "miniotest1",
                                                   _retryCount=5)
    storage = cMinioStorage(connect_info_dto)

    return storage


def StatEx():
    storage = hdfs()
    storage.Connect()
    stat = storage.Stat("/a1")
    # stat = storage.Stat("/a1/a2")
    print(stat.ToString())


def ListEx():
    storage = hdfs()
    storage.Connect()
    fileList = storage.List("/20231211")
    for _file in fileList:
        print(_file.ToString())


def WalkEx():
    storage = hdfs()
    storage.Connect()
    fileList = storage.Walk("/a1")
    print(len(fileList))
    for _file in fileList:
        print(_file.ToString())


def UploadEx():
    # Upload
    storage = hdfs()
    storage.Connect()
    # storage.Upload("C:\\Users\\swmai\\Desktop\\a20231018\\ttt2", "/test/test1")
    storage.Upload("C:\\Users\\swmai\\Desktop\\a20231018\\at128_roof_front.pcap", "/test/test1")
    storage.Upload("C:\\Users\\swmai\\Desktop\\a20231018\\at128_roof_front.pcap", "/test/test12/at128_roof_front.pcap")
    pass


def DownloadEx():
    # Download
    storage = hdfs()
    storage.Connect()
    storage.Download("/a1", "C:\\Users\\swmai\\Desktop\\asdfasdf2")
    storage.Download("/a1/a2/video_1.pcap", "C:\\Users\\swmai\\Desktop\\asdfasdf3")
    pass


def DeleteEx():
    # Delete
    storage = hdfs()
    storage.Connect()
    # storage.Delete("/a1/a2/video_1.pcap")
    storage.Delete("/a1/timefit")
    pass


def OpenEx():
    storage = hdfs()
    storage.Connect()
    # Open
    keyDto = storage.Open("/a1/video_1.pcap", E_FILE_MODE.READ)
    print(keyDto.ToString())
    print(keyDto.GetHash())
    print(storage.GetFileObject(keyDto.GetHash()))
    print(storage.GetFileObject(keyDto))

    p1 = storage.Open("/a1/video_1.pcap2", E_FILE_MODE.READ)
    p2 = storage.Open("/a1/video_1.pcap3", E_FILE_MODE.READ)
    p4 = storage.Open("/a1/video_1.pcap4", E_FILE_MODE.READ)
    p5 = storage.Open("/a1/video_1.pcap5", E_FILE_MODE.READ)
    p6 = storage.Open("/a1/video_1.pcap6", E_FILE_MODE.READ)
    p7 = storage.Open("/a1/video_1.pcap7", E_FILE_MODE.READ)

    p1_object = storage.GetFileObject(p1)
    p1_object.Close()
    # storage.Close(p1)
    storage.GetFileObject(p2)


def ReadEx():
    storage = hdfs()
    storage.Connect()
    from ObjectStorage2.IObjectStorage import E_FILE_MODE
    openFileKeyDto = storage.Open("/a1/video_1.pcap", E_FILE_MODE.READ)
    file_object = storage.GetFileObject(openFileKeyDto)

    # print(file_object.ReadAll())
    # print(len(file_object.ReadAll()))
    print(file_object.Read(4))
    print(file_object.Read(4))
    print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.size)
    # print(file_object.Read(file_object.size))
    # file_object.Seek(-file_object.size)
    # print(file_object.Read())


def WriteEx():
    storage = hdfs()
    storage.Connect()
    from ObjectStorage2.IObjectStorage import E_FILE_MODE
    ## READ ALL
    write_openFileKeyDto = storage.Open("/data/test123/asdflkjsadf.txt", E_FILE_MODE.WRITE)

    file_object = storage.GetFileObject(write_openFileKeyDto)

    file_object.Write("hello my name is sangwon")
    print(file_object.size)

    time.sleep(1)

    read_openFileKeyDto = storage.Open("/data/test123/asdflkjsadf.txt", E_FILE_MODE.READ)
    file_object2 = storage.GetFileObject(read_openFileKeyDto)
    print(file_object2.ReadAll())

    try:
        file_object2.Write("asdfasdfasdf")
    except Exception as e:
        print("Access Check True")

    storage.Disconnect()


if __name__ == '__main__':
    # print("StatEx()")
    # StatEx()
    # print("ListEx()")
    # ListEx()
    # print("WalkEx()")
    # WalkEx()
    print("UploadEx()")
    UploadEx()
    # print("DownloadEx()")
    # DownloadEx()
    # print("DeleteEx()")
    # DeleteEx()
    # print("OpenEx()")
    # OpenEx()
    # print("ReadEx()")
    # ReadEx()
    # print("WriteEx()")
    # WriteEx()
    pass
