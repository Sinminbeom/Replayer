




import time

from ObjectStorage2.Hadoop.cHadoopStorage import cHadoopStorage
from ObjectStorage2.Hadoop.cHadoopStorageConnectInfoDto import cHadoopStorageConnectInfoDto
from ObjectStorage2.Local.cLocalStorageConnectInfoDto import cLocalStorageConnectInfoDto
from ObjectStorage2.Minio.cMinioStorage import cMinioStorage
from ObjectStorage2.Minio.cMinioStorageConnectInfoDto import cMinioStorageConnectInfoDto


def HadoopTest():
    connect_info_dto = cHadoopStorageConnectInfoDto("192.168.1.79", "50070", "swmai")
    storage = cHadoopStorage(connect_info_dto)

    storage.Connect()

    # stat = storage.Stat("/data2/video_1.pcap1")
    stat = storage.Stat("/data/test/t4")
    print(stat.ToString())

    ## List Test
    # fileList = storage.List("/data/a20231018/")
    # print(len(fileList))
    # for _file in fileList:
    #     print(_file.ToString())

    # # Walk Test
    # fileList = storage.Walk("/data/a20231018")
    # print(len(fileList))
    # for _file in fileList:
    #     print(_file.ToString())

    ## Upload
    # storage.Upload("C:\\Users\\swmai\\Desktop\\p20230727", "/data2")
    # storage.Upload("C:\\Users\\swmai\\Desktop\\p20230727\\video_1.pcap", "/data2")

    ## Download
    # storage.Download("/data2", "C:\\Users\\swmai\\Desktop\\asdfasdf")
    # storage.Download("/data2/video_1.pcap", "C:\\Users\\swmai\\Desktop\\asdfasdf")

    ## Delete
    # storage.Delete("/data2/timefit")
    # storage.Delete("/data2/video_1.pcap")
    # print(storage.IsDir("/data2"))
    # print(storage.IsDir("/data2/video_1.pcap1"))

    ## Open
    # keyDto = storage.Open("/data2/video_1.pcap1")
    # print(keyDto.ToString())
    # print(keyDto.GetHash())
    # print(storage.GetFileObject(keyDto.GetHash()))
    # print(storage.GetFileObject(keyDto))

    p1 = storage.Open("/data2/video_1.pcap1")
    p2 = storage.Open("/data2/video_1.pcap2")
    p3 = storage.Open("/data2/video_1.pcap3")
    p4 = storage.Open("/data2/video_1.pcap4")
    p5 = storage.Open("/data2/video_1.pcap5")
    p6 = storage.Open("/data2/video_1.pcap6")
    p7 = storage.Open("/data2/video_1.pcap7")

    p1_object = storage.GetFileObject(p1)
    p1_object.Close()
    # storage.Close(p1)
    storage.GetFileObject(p2)


    storage.Disconnect()


def LocalTest():
    from ObjectStorage2.Local.cLocalStorage import cLocalStorage


    # connect_info_dto = cLocalStorageConnectInfoDto()
    storage = cLocalStorage()

    storage.Connect()
    #
    fileList = storage.List("D:\img")
    print(len(fileList))
    for _file in fileList:
        print(_file.ToString())



    # Walk Test
    fileList = storage.Walk("D:\img")
    print(len(fileList))
    for _file in fileList:
        # print(_file.object_name, _file.size)
        print(_file.ToString())
        # print(_file.ToString())

    # Upload
    # storage.Upload("D:\\res\\pcaps\\at128", "/data")
    #
    r = storage.IsDir("D:\\res\pcaps\\at128\\")
    print(r)

    r1 = storage.IsDir("D:\\res\pcaps\\test1.pcap")
    print(r1)

    src = "D:\\res\\pcaps\\at128_22"  # 원본 경로
    dest = "D:\\res\\pcaps\\p1"  # 복사 대상 경로

    # storage.Upload(src, dest)
    #
    # storage.Download(dest, src)

    st=storage.Stat( src)

    storage.Delete(src)

    h=0




    pass


def MinioTest():
    connect_info_dto = cMinioStorageConnectInfoDto("192.168.1.248",
                                                   "9000",
                                                   "oracle",
                                                   "oracleoracleoracle",
                                                   # "t1-raw-data")
                                                   "miniotest1")
    storage = cMinioStorage(connect_info_dto)

    storage.Connect()

    # List Test
    fileList = storage.List("/fileTest")
    print(len(fileList))
    for _file in fileList:
        print(_file.ToString())

    # Walk Test
    fileList = storage.Walk("/fileTest")
    print(len(fileList))
    for _file in fileList:
        # print(_file.object_name, _file.size)
        print(_file.ToString())
        # print(_file.ToString())

    # Upload
    storage.Upload("D:\\res\\pcaps\\at128", "/data")
    # storage.Upload("D:\\res\\pcaps", "/data")
    # storage.Upload("C:\\Users\\swmai\\Desktop\\p20230727\\video_1.pcap", "/data")


    # storage.Upload("C:\\Users\\swmai\\Desktop\\p20230727\\video_1.pcap", "/data/video_1.pcap")
    r=storage.IsDir("/data/at128")
    print(r)
    r1=storage.IsDir("/data/test1.pcap")
    print(r1)
    # print(storage.IsDir("/E100-02"))
    # print(storage.IsDir("/E100-02/am20_front_center_left_up/udp_dump_20230918153518.pcap"))
    # print(storage.IsDir("E100-02/am20_front_center_left_up/udp_dump_20230918153518.pcap"))
    # print(storage.IsDir("/data/gnss"))
    # print(storage.IsDir("data/gnss"))
    # print(storage.IsDir("/E100-02/am20_front_center_left_up/udaaap_dump_20230918153518.pcap"))

    ## Download
    # storage.Download("data2/gnss/", "C:\\Users\\swmai\\Desktop\\aaaaffff")
    # storage.Download("/data2", "C:\\Users\\swmai\\Desktop\\aaaaffff")
    # storage.Download("/20231211", "C:\\Users\\swmai\\Desktop\\20231211")
    # storage.Download("/data2/gnss", "C:\\Users\\swmai\\Desktop\\aaaaffff\\")
    storage.Download("/data", "D:\\res\\pcaps\\dw")
    # storage.Download("/", "C:\\Users\\swmai\\Desktop\\aaaaffff")
    # storage.Download("/data/video_1.pcap", "C:\\Users\\swmai\\Desktop\\aaaaffff")
    # storage.Download("/data/video_1.pcap", "C:\\Users\\swmai\\Desktop\\aaaaffff")
    # storage.Download("/data/video_1.pcap", "C:\\Users\\swmai\\Desktop\\aaaaffff", False)

    ## Delete
    # storage.Delete("/data2/")
    # storage.Delete("/data/video_1.pcap")

    storage.Disconnect()


def HadoopTestReadWrite():
    connect_info_dto = cHadoopStorageConnectInfoDto("192.168.1.79", "50070", "swmai")
    storage = cHadoopStorage(connect_info_dto)
    storage.Connect()

    ## READ ALL
    openFileKeyDto = storage.Open("/data/a20231018/am20_front_center_left_up_20231006165305.pcap")
    file_object = storage.GetFileObject(openFileKeyDto)
    # print(file_object.ReadAll())
    # print(len(file_object.ReadAll()))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.size)
    # print(file_object.Read(file_object.size))
    # file_object.Seek(-file_object.size)
    # print(file_object.Read())



    storage.Disconnect()

def MinioTestReadWrite():
    connect_info_dto = cMinioStorageConnectInfoDto("192.168.1.248",
                                                   "9000",
                                                   "oracle",
                                                   "oracleoracleoracle",
                                                   "t1-raw-data")
    storage = cMinioStorage(connect_info_dto)
    storage.Connect()

    ## READ ALL
    openFileKeyDto = storage.Open("/E100-02/am20_front_center_left_up/udp_dump_20230918153518.pcap")
    file_object = storage.GetFileObject(openFileKeyDto)
    # print(file_object.ReadAll())
    # print(len(file_object.ReadAll()))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(4))
    # print(file_object.Read(file_object.size))
    # print(file_object.Read())
    #
    # print(file_object.Read(4))
    # file_object.Seek(-4)
    # print(file_object.Read(4))
    # file_object.Seek(-4)
    # print(file_object.Read(4))
    # file_object.Seek(-4)
    # print(file_object.Read(4))
    # file_object.Seek(-4)
    # print(file_object.Read(4))
    # file_object.Seek(-4)



    # try:
    #     stat_object = storage.storage.stat_object("t1-raw-data",
    #                                               "/E100-02/am20_front_center_left_up/udp_dump_20230918153518.pcap")
    #     print(stat_object.size)
    #     # response = storage.storage.get_object("t1-raw-data", "/E100-02/am20_front_center_left_up/udp_dump_20230918153518.pcap")
    #     # response = storage.storage.get_object("t1-raw-data", "/E100-02/am20_front_center_left_up/udp_dump_20230918153518.pcap", offset=0, length=10)
    #     response = storage.storage.get_object("t1-raw-data", "/E100-02/am20_front_center_left_up/udp_dump_20230918153518.pcap", offset=32479220, length=132479224)
    #     print(response.read())
    # finally:
    #     response.close()
    #     response.release_conn()

    storage.Disconnect()

#
# if __name__ == '__main__':
#     # HadoopTest()
#     # MinioTest()
#     LocalTest()
#
#     # MinioTestReadWrite()
#     # HadoopTestReadWrite()
