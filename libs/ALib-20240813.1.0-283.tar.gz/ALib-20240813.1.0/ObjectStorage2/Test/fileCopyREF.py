import os
import shutil
from abc import ABC, abstractmethod

class CopyStrategy(ABC):
    @abstractmethod
    def copy(self, source, destination):
        pass



class FileToFileStrategy(CopyStrategy):
    def copy(self, source, destination):
        if not os.path.isfile(source):
            print(f"오류: {source}는 파일이 아닙니다.")
            return
        shutil.copy2(source, destination)
        print(f"복사됨: {source} → {destination}")


class FileToFolderStrategy(CopyStrategy):
    def copy(self, source, destination):
        if not os.path.isfile(source):
            print(f"오류: {source}는 파일이 아닙니다.")
            return
        if not os.path.isdir(destination):
            os.makedirs(destination)
        destination_file = os.path.join(destination, os.path.basename(source))
        shutil.copy2(source, destination_file)
        print(f"복사됨: {source} → {destination_file}")


class FolderToFolderStrategy(CopyStrategy):
    def copy(self, source, destination):
        if not os.path.isdir(source):
            print(f"오류: {source}는 폴더가 아닙니다.")
            return
        for root, dirs, files in os.walk(source):
            relative_path = os.path.relpath(root, source)
            destination_path = os.path.join(destination, relative_path)
            if not os.path.exists(destination_path):
                os.makedirs(destination_path)
            for file in files:
                source_file = os.path.join(root, file)
                destination_file = os.path.join(destination_path, file)
                shutil.copy2(source_file, destination_file)
                print(f"복사됨: {source_file} → {destination_file}")


class FolderToFileErrorStrategy(CopyStrategy):
    def copy(self, source, destination):
        print(f"오류: {source}는 폴더이고, {destination}은 파일입니다. 폴더를 파일로 복사할 수 없습니다.")

class CopyContext:
    def __init__(self, strategy: CopyStrategy):
        self.strategy = strategy

    def execute(self, source, destination):
        self.strategy.copy(source, destination)

def determine_strategy(source, destination):
    if os.path.isfile(source) and os.path.isfile(destination):
        return FileToFileStrategy()
    elif os.path.isfile(source) and os.path.isdir(destination):
        return FileToFolderStrategy()
    elif os.path.isdir(source) and os.path.isdir(destination):
        return FolderToFolderStrategy()
    elif os.path.isdir(source) and os.path.isfile(destination):
        return FolderToFileErrorStrategy()
    else:
        raise ValueError("지원하지 않는 복사 유형입니다.")




def main():
    source = "D:\\res\\pcaps\\at128"  # 원본 경로
    destination = "D:\\res\\pcaps\\p1"  # 복사 대상 경로

    try:
        strategy = determine_strategy(source, destination)
        context = CopyContext(strategy)
        context.execute(source, destination)
    except ValueError as e:
        print(f"오류: {e}")
    pass



if __name__ == '__main__':
    main()

