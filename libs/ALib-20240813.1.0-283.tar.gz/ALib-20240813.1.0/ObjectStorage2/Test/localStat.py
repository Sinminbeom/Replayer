
import os
# import grp
import stat
import time

def main():
    _path = "D:\\res\\pcaps\\dw\\data\\at128_roof_front_20240820134455.pcap"

    from pathlib import Path
    path = Path(_path)



    # 경로와 파일 이름 분리
    directory, file_name = os.path.split(_path)

    file_stat = os.stat(_path)

    print(f"is_dir: {path.is_dir()}")
    print(f"is_file: {path.is_file()}")
    print(f"path: {path}")
    print(f"디렉토리: {directory}")
    print(f"파일 이름: {file_name}")
    print(f"파일 모드: {file_stat.st_mode}")
    print(f"파일 크기: {file_stat.st_size} 바이트")
    print(f"소유자 사용자 ID: {file_stat.st_uid}")
    print(f"소유자 그룹 ID: {file_stat.st_gid}")
    print(f"마지막 수정 시간: {file_stat.st_mtime}")



if __name__ == '__main__':
    main()
