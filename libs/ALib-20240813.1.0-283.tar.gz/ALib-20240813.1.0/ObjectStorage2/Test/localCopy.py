import os
import shutil


def copy_source_to_destination(source, destination):
    # 폴더를 파일로 복사하려는 경우 방지
    if os.path.isdir(source) and os.path.exists(destination) and not os.path.isdir(destination):
        print(f"오류: {source}는 폴더이고, {destination}은 파일입니다. 폴더를 파일로 복사할 수 없습니다.")
        return

    if os.path.isfile(source):
        # 파일 복사
        if os.path.isdir(destination):
            # 대상이 폴더라면 파일 이름을 유지해서 복사
            destination_file = os.path.join(destination, os.path.basename(source))
        else:
            # 대상이 파일이라면 그대로 복사
            destination_file = destination

        # 파일이 없거나, 원본 파일이 더 최신인 경우에만 복사
        if not os.path.exists(destination_file) or \
                os.path.getmtime(source) > os.path.getmtime(destination_file):
            shutil.copy2(source, destination_file)
            print(f"복사됨: {source} → {destination_file}")
        else:
            print(f"스킵됨: {destination_file} (이미 최신 파일)")

    elif os.path.isdir(source):
        # 폴더 복사
        for root, dirs, files in os.walk(source):
            relative_path = os.path.relpath(root, source)
            destination_path = os.path.join(destination, relative_path)
            if not os.path.exists(destination_path):
                os.makedirs(destination_path)
            for file in files:
                source_file = os.path.join(root, file)
                destination_file = os.path.join(destination_path, file)
                if not os.path.exists(destination_file) or \
                        os.path.getmtime(source_file) > os.path.getmtime(destination_file):
                    shutil.copy2(source_file, destination_file)
                    print(f"복사됨: {source_file} → {destination_file}")
                else:
                    print(f"스킵됨: {destination_file} (이미 최신 파일)")
    else:
        print(f"오류: {source}는 파일도 폴더도 아닙니다.")


##TODO 이부분을 각 조건에 따라 복사하는 클래스를 만들어서 로직을 수행 하게 수정을 하자....
## case 1 -> file to file
## case 2 -> file to folder
## case 3 -> folder to folder
## case 4 -> folder to file   error!!!!!!!!!!!!!

def main():
    # source = "D:\\res\\pcaps\\at128\\at128_roof_front_20240820134456.pcap"  # 원본 경로 (파일 또는 폴더)
    source = "D:\\res\\pcaps\\at128"  # 원본 경로 (파일 또는 폴더)
    # destination = "D:\\res\\pcaps\\p1"  # 복사 대상 경로
    destination = "D:\\res\\pcaps\\test1.pcap"  # 복사 대상 경로

    copy_source_to_destination(source, destination)


if __name__ == '__main__':
    main()
