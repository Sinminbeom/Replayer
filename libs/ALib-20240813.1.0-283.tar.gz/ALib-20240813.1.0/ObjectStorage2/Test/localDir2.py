


import os
# import grp
import stat
import time

def main():
    folder_path = "D:\\doc"
    txt_files = []

    for root, dirs, files in os.walk(folder_path):
        if folder_path == root:
            print("현재 디렉토리(root):", root)
            print("하위 디렉토리 목록(dirs):", dirs)
            print("파일 목록(files):", files)
            print("-" * 50)  # 구분선

            for file in dirs:
                file_path = os.path.join(root, file)

                # 파일 정보 가져오기
                file_stat = os.stat(file_path)

                # 파일 크기
                file_size = file_stat.st_size

                # 마지막 수정 시간
                # last_modified = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(file_stat.st_mtime))
                last_modified = file_stat.st_mtime

                # 권한 정보
                permissions = stat.filemode(file_stat.st_mode)

                # 소유자와 그룹 이름 (Windows에서는 UID/GID가 사용되지 않을 수 있음)
                # try:
                #     owner = pwd.getpwuid(file_stat.st_uid).pw_name
                #     group = grp.getgrgid(file_stat.st_gid).gr_name
                # except AttributeError:  # Windows에서는 AttributeError 발생 가능
                owner = "N/A"
                group = "N/A"

                # 파일 출력
                print(f"파일: {file}")
                print(f"file_stat: {file_stat}")
                print(f"  - 크기: {file_size} bytes")
                print(f"  - 마지막 수정 시간: {last_modified}")
                print(f"  - 권한: {permissions}")
                print(f"  - 소유자: {owner}")
                print(f"  - 그룹: {group}")
                print("-" * 50)

    print("모든 TXT 파일:", txt_files)


if __name__ == '__main__':
    main()
