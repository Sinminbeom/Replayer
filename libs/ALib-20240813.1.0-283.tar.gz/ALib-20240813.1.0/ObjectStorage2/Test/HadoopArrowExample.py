import os

from pyarrow import fs


def main():
    hdfs = fs.HadoopFileSystem(host="oem", port=18020, user="swmai")


    print(hdfs.get_file_info("/data-warehouse"))
    print( os.environ.get('CLASSPATH', ''))
    print(os.environ)

if __name__ == '__main__':
    main()

