from abc import abstractmethod


class IContainer:
    pass

