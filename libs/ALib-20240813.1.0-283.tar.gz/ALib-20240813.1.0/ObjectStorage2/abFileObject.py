from LibUtils.HashUtils import HashUtils
from ObjectStorage2.IFileObject import IFileObject
from ObjectStorage2.cCursor import cCursor


class abFileObject(IFileObject):

    def __init__(self, _parent, _filePath, _size,_mode, _cursor=0):
        self.parent = _parent
        self.size = _size
        self.cursor = cCursor(_cursor)
        self.filePath = _filePath
        self.mode = _mode

    def GetCursor(self):
        return self.cursor

    def GetFilePath(self):
        return self.filePath

    def Close(self):
        self.parent.Close(HashUtils.encode(self.filePath, self.mode))

    def _checkOutBoundExcept(self, _cursor):
        if _cursor > self.size or _cursor < 0:
            raise IndexError("Cursor Size Out Bound Exception" +
                             "File Length : " + str(self.size) +
                             " File Name : " + self.filePath)

    def _checkAccessMode(self, _mode):
        if self.mode != _mode:
            raise PermissionError("[ERROR] ACCESS ERROR : Please Check Open Mode")