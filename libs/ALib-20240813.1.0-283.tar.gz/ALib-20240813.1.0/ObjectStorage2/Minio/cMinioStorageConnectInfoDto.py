from minio import Minio

from ObjectStorage2.abObjectStorageConnectInfoDto import abObjectStorageConnectInfoDto


class cMinioStorageConnectInfoDto(abObjectStorageConnectInfoDto):

    def __init__(self, _address, _port, _access_key, _access_passwd, _bucket, _retryCount: int = 1, _interval: float = 0.1):
        super().__init__(_address, _port, _access_key, _retryCount, _interval)
        self.access_passwd = _access_passwd
        self.bucket = _bucket

    def Connect(self):

        from ObjectStorage2.cObjectStorageEndPointRep import cMinioObjectStorageEndPointRep
        return cMinioObjectStorageEndPointRep(
            Minio(str(self.address) + ':' + str(self.port),
                  access_key=self.access_key,
                  secret_key=self.access_passwd,
                  secure=False)
        )
        #
        # return Minio(str(self.address) + ':' + str(self.port),
        #              access_key=self.access_key,
        #              secret_key=self.access_passwd,
        #              secure=False)

    # Getter
    def GetAccess_passwd(self):
        return self.access_passwd

    def GetRoot(self):
        return self.bucket
