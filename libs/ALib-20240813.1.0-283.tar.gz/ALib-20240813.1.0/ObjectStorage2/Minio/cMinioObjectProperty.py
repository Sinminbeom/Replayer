from ObjectStorage2.Properties.abStorageObjectProperty import abStorageObjectProperty


class cMinioObjectProperty(abStorageObjectProperty):

    def __init__(self, _fileObject):
        from ObjectStorage2.eStorageType import eStorageType
        super().__init__(eStorageType.MINIO, _fileObject)

    def GetFileName(self):
        if self.IsDir():
            return ""
        return self.fileObject.object_name.split("/")[-1]

    def GetFilePath(self):
        obj_path = "/".join(self.fileObject.object_name.split("/")[:-1])
        if self.IsDir():
            obj_path += "/"

        if not obj_path.startswith("/"):
            obj_path = "/" + obj_path

        return obj_path

    def GetObjectName(self):
        return self.fileObject.object_name.split("/")[-1]

    def GetObjectPath(self):
        return self.GetFilePath()


    def GetSize(self):
        if self.fileObject.size is None:
            return 0
        return self.fileObject.size

    def GetLastModified(self):
        return self.fileObject.last_modified

    def GetOwner(self):
        if self.fileObject.owner_name is None:
            return "None"
        return self.fileObject.owner_name

    def IsDir(self):
        return self.fileObject.is_dir

    def GetBucket(self):
        return self.fileObject.bucket_name
