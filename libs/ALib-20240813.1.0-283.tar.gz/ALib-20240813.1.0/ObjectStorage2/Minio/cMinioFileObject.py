import io

from ObjectStorage2.IObjectStorage import E_FILE_MODE
from ObjectStorage2.abFileObject import abFileObject


class cMinioFileObject(abFileObject):
    def __init__(self, _parent, _filePath, _size, _mode, _cursor=0):
        super().__init__(_parent, _filePath, _size, _mode, _cursor)

    def Read(self, _length=1):
        self._checkAccessMode(E_FILE_MODE.READ)
        self._checkOutBoundExcept(self.cursor.GetIndex() + _length)

        minioStorage = self.parent.GetStorageEndPoint()
        minioResponse = minioStorage.get_object(self.parent.bucket,
                                                self.filePath,
                                                offset=self.cursor.GetIndex(),
                                                length=_length)
        self.cursor.Seek(_length)
        return minioResponse.read()

    def ReadAll(self):
        self._checkAccessMode(E_FILE_MODE.READ)
        minioStorage = self.parent.GetStorageEndPoint()
        minioResponse = minioStorage.get_object(self.parent.bucket, self.filePath)
        return minioResponse.read()

    def Seek(self, _offset):
        self._checkAccessMode(E_FILE_MODE.READ)
        self._checkOutBoundExcept(self.cursor.GetIndex() + _offset)
        self.cursor.Seek(_offset)

    def Write(self, _data, _overwrite=True):
        self._checkAccessMode(E_FILE_MODE.WRITE)
        if not _overwrite:
            return
        minioStorage = self.parent.GetStorageEndPoint()

        if not isinstance(_data, bytes):
            _data = bytes(_data, 'utf-8')

        minioStorage.put_object(self.parent.bucket,
                                self.filePath,
                                io.BytesIO(_data),
                                length=len(_data))

        self.size += len(_data)

