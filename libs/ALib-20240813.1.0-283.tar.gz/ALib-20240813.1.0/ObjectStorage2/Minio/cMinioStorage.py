import os.path

from minio import S3Error

from LibUtils.FileLists import FileLists
from Log.cLogger import cLogger, E_LOG
from ObjectStorage2.IObjectStorageConnectInfoDto import IObjectStorageConnectInfoDto
from ObjectStorage2.Minio.cMinioFileObjectContainer import cMinioFileObjectContainer
from ObjectStorage2.Minio.cMinioObjectContainer import cMinioObjectContainer
from ObjectStorage2.Minio.cMinioObjectProperty import cMinioObjectProperty
from ObjectStorage2.abObjectStorage import abObjectStorage
from ObjectStorage2.cObjectStorageException import COMMON, FILE_REMOVE_ERROR
from ObjectStorage2.eStorageType import eStorageType


class cMinioStorage(abObjectStorage):

    def __init__(self, _connectInfoDto: IObjectStorageConnectInfoDto):
        super().__init__(eStorageType.MINIO, _connectInfoDto, cMinioFileObjectContainer())
        self.bucket = _connectInfoDto.GetRoot()

    def Stat(self, _path):
        return self.Run(lambda: self.stat(_path))

    # def Stat(self, _path):
    def stat(self, _path):
        try:
            return cMinioObjectProperty(self.storageEndPointRep.stat_object(self.bucket, _path))
        except S3Error as e:
            for properties in self.List(self._getUpperPath(_path)):
                if properties.GetFilePath() == self._makeFitObjectStoragePath(_path):
                    return properties

            raise FileNotFoundError("[ERROR] Folder Not Exist.")

    def List(self, _path):
        return self.Run(lambda: cMinioObjectContainer(self.storageType,
                                                      self.storageEndPointRep.list_objects(_bucket = self.bucket,
                                                                                           _prefix=self._makeFitObjectStoragePath(
                                                                                    _path),
                                                                                           _recursive=False)
                                                      ).GetStorageObjectProperties())

    def Walk(self, _path):
        return self.Run(lambda: cMinioObjectContainer(self.storageType,
                                     self.storageEndPointRep.list_objects(self.bucket,
                                                                          _prefix=self._makeFitObjectStoragePath(_path),
                                                                          _recursive=True)
                                     ).GetStorageObjectProperties())

    def Upload(self, _srcPath, _dstPath, _overwrite=True):
        self.Run(lambda: self.upload(_srcPath, self._makeUploadPath(_dstPath), _overwrite))

    def upload(self, _srcPath, _dstPath, _overwrite=True):
        for srcPath, dstPath in self.__makeUploadQueue(_srcPath, _dstPath).items():
            try:
                self.storageEndPointRep.getStorageEndPoint().stat_object(self.bucket, dstPath)  # if File Exist
                if _overwrite:
                    raise S3Error(None, None, None, None, None, None)

            except S3Error as e:
                self.storageEndPointRep.getStorageEndPoint().fput_object(bucket_name=self.bucket,
                                                    object_name=dstPath,
                                                    file_path=srcPath
                                                    )

    def UploadFile(self, _srcPath, _dstPath, _overwrite=True):
        self.Run(lambda: self.uploadFile(_srcPath, self._makeUploadPath(_dstPath), _overwrite))

    def uploadFile(self, _srcPath, _dstPath, _overwrite=True):
        try:
            self.storageEndPointRep.getStorageEndPoint().stat_object(self.bucket, _dstPath)  # if File Exist
            if _overwrite:
                raise S3Error(None, None, None, None, None, None)

        except S3Error as e:
            self.storageEndPointRep.getStorageEndPoint().fput_object(bucket_name=self.bucket,
                                                object_name=self._makeUploadPath(_dstPath),
                                                file_path=_srcPath
                                                )


    def UploadFolder(self, _srcPath, _dstPath, _overwrite=True):
        self.Run(lambda: self.uploadFolder(_srcPath, _dstPath, _overwrite))

    def uploadFolder(self, _srcPath, _dstPath, _overwrite=True):
        for srcPath, dstPath in self.__makeUploadQueue(_srcPath, self._makeUploadPath(_dstPath)).items():
            try:
                self.storageEndPointRep.getStorageEndPoint().stat_object(self.bucket, dstPath)  # if File Exist
                if _overwrite:
                    raise S3Error(None, None, None, None, None, None)

            except S3Error as e:
                self.storageEndPointRep.getStorageEndPoint().fput_object(bucket_name=self.bucket,
                                                    object_name=dstPath,
                                                    file_path=srcPath
                                                    )

    def __makeUploadQueue(self, _srcPath, _dstPath):
        uploadQueue = dict()

        if os.path.isdir(_srcPath):
            for _file in FileLists(_srcPath).getFiles():
                _path, _name = _file[0], _file[1]
                ## TODO 폴더 생성해주기
                uploadQueue[_path + _name] = self._makeFitObjectStoragePath(_dstPath) + \
                                             self._convertObjectStoragePath(_path.replace(_srcPath, "") + _name)
            return uploadQueue

        uploadQueue[_srcPath] = self._makeFitObjectStoragePath(_dstPath) + FileLists.extractFileName(_srcPath)
        return uploadQueue

    def Download(self, _srcPath, _dstPath, _overwrite=True):
        self.Run(lambda: self.download(_srcPath, _dstPath, _overwrite))

    def download(self, _srcPath, _dstPath, _overwrite=True):
        for srcPath, dstPath in self.__makeDownloadQueue(_srcPath, _dstPath).items():
            if not _overwrite:
                cLogger.instance().Print(E_LOG.INFO, dstPath + " File Already Exist -> Don't Download It")
                continue

            if os.path.exists(dstPath):
                os.remove(dstPath)

            self.storageEndPointRep.getStorageEndPoint().fget_object(bucket_name=self.bucket,
                                                object_name=srcPath,
                                                file_path=dstPath
                                                )

    def __makeDownloadQueue(self, _srcPath, _dstPath):
        downloadQueue = dict()
        if self.IsDir(_srcPath):
            try:
                for _property in self.Walk(_srcPath):
                    srcFile = self._makeFitObjectStoragePath(_property.GetFilePath()) + _property.GetFileName()

                    parentPath = self._getUpperPath(_srcPath)

                    dstFile = FileLists.makeCorrectFileRoute(_dstPath + srcFile)
                    if parentPath != "/":
                        dstFile = FileLists.makeCorrectFileRoute(_dstPath + srcFile.replace(parentPath, ""))

                    downloadQueue[srcFile] = dstFile
                return downloadQueue
            except Exception as e:
                raise Exception("[ERROR] IllegalArgumentException -> Invalid File Route ")

        downloadQueue[_srcPath] = FileLists.makeCorrectFolderRoute(_dstPath) + FileLists.extractFileName(_srcPath, "/")
        return downloadQueue

    def Delete(self, _path):
        self.Run(lambda: self.delete(_path))

    def delete(self, _path):
        try:
            for _p in self.__makeDeleteQueue(_path).keys():
                self.storageEndPointRep.getStorageEndPoint().remove_object(self.bucket, _p)
        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + FILE_REMOVE_ERROR)
            raise Exception()

    def __makeDeleteQueue(self, _path):
        deleteQueue = dict()
        if self.IsDir(_path):
            try:
                for _property in self.Walk(_path):
                    srcFile = self._makeFitObjectStoragePath(_property.GetFilePath()) + _property.GetFileName()
                    deleteQueue[srcFile] = ""

                return deleteQueue
            except Exception as e:
                raise Exception("[ERROR] IllegalArgumentException -> Invalid File Route ")

        deleteQueue[_path] = ""
        return deleteQueue

    def IsDir(self, _path):
        return self.Run(lambda: self.isDir(_path))


    def IsExist(self, _path):
        try:
            self.Stat(_path)
            return True
        except Exception as e:
            return False

    def isDir(self, _path):
        try:
            self.storageEndPointRep.getStorageEndPoint().stat_object(self.bucket, _path)

            return False
        except S3Error as e:
            for properties in self.List(self._getUpperPath(_path)):
                if properties.GetFilePath() == self._makeFitObjectStoragePath(_path):
                    return True

            raise FileNotFoundError("[ERROR] Folder or File Not Exist.")
