from ObjectStorage2.Minio.cMinioObjectProperty import cMinioObjectProperty
from ObjectStorage2.Properties.abStorageObjectContainer import abStorageObjectContainer


class cMinioObjectContainer(abStorageObjectContainer):

    def _parse(self, _storageType, _files):
        self.storageObjectProperties.clear()

        # properties = []

        for _file in _files:
            self.storageObjectProperties.append(cMinioObjectProperty(_file))

        # return properties
