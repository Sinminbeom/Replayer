from abc import abstractmethod

from ObjectStorage2.IContainer import IContainer
from ObjectStorage2.cFileObjectKeyDto import cFileObjectKeyDto


class abFileObjectContainer(IContainer):

    def __init__(self):
        self.fileObjects = dict()

    @abstractmethod
    def Append(self, _parent, _filepath, _size, _mode):
        pass

    def Get(self, _hash):
        if self.fileObjects[_hash] is not None:
            return self.fileObjects[_hash]

        raise TypeError("[ERROR] Please Insert Valid Value | Your : " + str(_hash))

    def Delete(self, _hash):
        if self.fileObjects[_hash] is not None:
            del self.fileObjects[_hash]

    def _getContainerSize(self):
        return len(self.fileObjects)

    def _makeFileObjectKeyDto(self, _filepath, _mode):
        return cFileObjectKeyDto(self._getContainerSize(), _filepath, _mode)

    def _checkFileAlreadyOpened(self, _key):
        if _key in self.fileObjects:
            raise TypeError("")
