from ObjectStorage2.IObjectStorageConnectInfoDto import IObjectStorageConnectInfoDto


class abObjectStorageConnectInfoDto(IObjectStorageConnectInfoDto):

    def __init__(self,
                 _address : str,
                 _port : int,
                 _access_key : str ,
                 _retryCount: int = 1,
                 _interval: float = 0.1):
        self.address = _address
        self.port = _port
        self.access_key = _access_key
        self.retryCount = _retryCount
        self.interval = _interval

    def Disconnect(self):
        return None

    # Getter
    def GetAddress(self):
        return self.address

    def GetPort(self):
        return self.port

    def GetAccess_id(self):
        return self.access_key

    def GetRetryCount(self):
        return self.retryCount

    def GetInterval(self):
        return self.interval

