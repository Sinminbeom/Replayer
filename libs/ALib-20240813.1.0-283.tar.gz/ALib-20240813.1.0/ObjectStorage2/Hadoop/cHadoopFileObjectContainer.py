from LibUtils.HashUtils import HashUtils
from Log.cLogger import cLogger, E_LOG
from ObjectStorage2.Hadoop.cHadoopFileObject import cHadoopFileObject
from ObjectStorage2.abFileObjectContainer import abFileObjectContainer


class cHadoopFileObjectContainer(abFileObjectContainer):

    def Append(self, _parent, _filepath, _size, _mode):
        hashPath = HashUtils.encode(_filepath, _mode)
        try:
            self._checkFileAlreadyOpened(hashPath)

            dto = self._makeFileObjectKeyDto(_filepath, _mode)
            self.fileObjects[dto.GetHash()] = cHadoopFileObject(_parent, _filepath, _size, _mode)
            return dto
        except TypeError as e:
            cLogger.instance().Print(E_LOG, "File Already Opened")
            # return self.fileObjects[hashPath]
            raise Exception()


