from ObjectStorage2.Hadoop.cHadoopObjectProperty import cHadoopObjectProperty
from ObjectStorage2.Properties.abStorageObjectContainer import abStorageObjectContainer


class cHadoopObjectContainer(abStorageObjectContainer):

    def _parse(self, _storageType, _files):

        self.storageObjectProperties.clear()

        properties = self.storageObjectProperties
        for _file in _files:
            search_dir = _file[0][0]

            for item in _file[1]:
                properties.append(cHadoopObjectProperty(search_dir, item))

            for item in _file[2]:
                properties.append(cHadoopObjectProperty(search_dir, item))

        # return properties
