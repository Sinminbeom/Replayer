from hdfs import InsecureClient

from ObjectStorage2.Hadoop.CustomInsecureClient import CustomInsecureClient
from ObjectStorage2.abObjectStorageConnectInfoDto import abObjectStorageConnectInfoDto


class cHadoopStorageConnectInfoDto(abObjectStorageConnectInfoDto):

    def __init__(self, _address, _port, _access_key, _retryCount: int = 1, _interval: float = 0.1):
        super().__init__(_address, _port, _access_key, _retryCount, _interval)

    def Connect(self):

        from ObjectStorage2.cObjectStorageEndPointRep import cHadoopObjectStorageEndPointRep
        return cHadoopObjectStorageEndPointRep(
            CustomInsecureClient(url="http://" + self.address + ":" + self.port,
                                 user=self.access_key)
        )


    def GetRoot(self):
        return "/"




