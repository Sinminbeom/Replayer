from enum import Enum

from ObjectStorage2.Properties.abStorageObjectProperty import abStorageObjectProperty


class HadoopFileContentType(Enum):
    NAME = 0
    INFO = 1


class HadoopFileInfoType(Enum):
    ACCESS_TIME = "accessTime"
    BLOCK_SIZE = "blockSize"
    CHILD_REN_NUM = "childrenNum"
    FILEID = "fileId"
    GROUP = "group"
    LENGTH = "length"
    MODIFICATION_TIME = "modificationTime"
    OWNER = "owner"
    PATH_SUFFIX = "pathSuffix"
    PERMISSION = "permission"
    REPLICATION = "replication"
    STORAGE_POLICY = "storagePolicy"
    TYPE = "type"


class cHadoopObjectProperty(abStorageObjectProperty):

    def __init__(self, _path, _fileObject):
        from ObjectStorage2.eStorageType import eStorageType
        super().__init__(eStorageType.HADOOP, _fileObject)
        self.filePath = _path

    def GetFileName(self):
        if self.IsDir():
            return ""

        return self.fileObject[HadoopFileContentType.NAME.value]

    def GetObjectName(self):
        return self.fileObject[HadoopFileContentType.NAME.value]

    def GetObjectPath(self):
        return self.GetFilePath()

    def GetFilePath(self):
        if self.IsDir():
            return self.filePath + "/" + self.fileObject[HadoopFileContentType.NAME.value]

        return self.filePath

    def GetSize(self):
        return self.__GetInfo()[HadoopFileInfoType.LENGTH.value]

    def GetLastModified(self):
        return self.__GetInfo()[HadoopFileInfoType.MODIFICATION_TIME.value]

    def GetOwner(self):
        return self.__GetInfo()[HadoopFileInfoType.OWNER.value]

    def IsDir(self):
        return self.__GetInfo()[HadoopFileInfoType.TYPE.value] == "DIRECTORY"

    def __GetInfo(self):
        return self.fileObject[HadoopFileContentType.NAME.INFO.value]
