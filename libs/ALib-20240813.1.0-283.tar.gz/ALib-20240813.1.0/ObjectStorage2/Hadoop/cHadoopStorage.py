from LibUtils.FileLists import FileLists
from ObjectStorage2.Hadoop.cHadoopFileObjectContainer import cHadoopFileObjectContainer
from ObjectStorage2.Hadoop.cHadoopObjectContainer import cHadoopObjectContainer
from ObjectStorage2.Hadoop.cHadoopObjectProperty import cHadoopObjectProperty
from ObjectStorage2.IObjectStorageConnectInfoDto import IObjectStorageConnectInfoDto
from ObjectStorage2.abObjectStorage import abObjectStorage
from ObjectStorage2.eStorageType import eStorageType


class cHadoopStorage(abObjectStorage):

    def __init__(self, _connectInfoDto: IObjectStorageConnectInfoDto):
        super().__init__(eStorageType.HADOOP, _connectInfoDto, cHadoopFileObjectContainer())

    def Disconnect(self):
        self.storageEndPointRep.close()
        self.storageEndPoint = self.connectInfoDto.Disconnect()

    def Stat(self, _path):
        return self.Run(lambda: cHadoopObjectProperty(
            self._getUpperPath(_path), (FileLists.extractFileName(_path, "/"), self.storageEndPoint.status(_path))))

    def List(self, _path):
        return self.Run(lambda: cHadoopObjectContainer(self.storageType,
                                                       self.storageEndPoint.List(_path=_path,
                                                                                 _depth=1,
                                                                                 _status=True))
                        .GetStorageObjectProperties())

    def Walk(self, _path):
        return self.Run(lambda: cHadoopObjectContainer(self.storageType,
                                                       self.storageEndPoint.List(_path=_path,
                                                                                 _depth=0,
                                                                                 _status=True))
                        .GetStorageObjectProperties())

    def Upload(self, _srcPath, _dstPath, _overwrite=True):
        if not self.storageEndPoint.status(_dstPath, strict=False):
            self.storageEndPoint.makedirs(_dstPath)

        self.Run(lambda: self.storageEndPoint.upload(self._makeUploadPath(_dstPath), _srcPath, overwrite=_overwrite))

    def UploadFile(self, _srcPath, _dstPath, _overwrite=True):
        self.Run(lambda: self.storageEndPoint.upload(_dstPath, _srcPath, overwrite=_overwrite))

    def UploadFolder(self, _srcPath, _dstPath, _overwrite=True):
        self.Run(lambda: self.storageEndPoint.upload(_dstPath, _srcPath, overwrite=_overwrite))


    def Download(self, _srcPath, _dstPath, _overwrite=True):
        self.Run(lambda: self.storageEndPoint.download(_srcPath, _dstPath, overwrite=_overwrite))


    def Delete(self, _path):
        self.Run(lambda: self.storageEndPoint.delete(_path, recursive=True))


    def IsDir(self, _path):
        from ObjectStorage2.Hadoop.cHadoopObjectProperty import HadoopFileInfoType
        return self.Run(lambda: self.storageEndPoint.status(_path)[HadoopFileInfoType.TYPE.value] == "DIRECTORY")

    def IsExist(self, _path):
        try:
            self.Stat(_path)
            return True
        except Exception as e:
            return False


