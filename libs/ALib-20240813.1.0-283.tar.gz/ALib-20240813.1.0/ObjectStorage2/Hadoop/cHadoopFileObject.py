from ObjectStorage2.IObjectStorage import E_FILE_MODE
from ObjectStorage2.abFileObject import abFileObject


class cHadoopFileObject(abFileObject):
    def __init__(self, _parent, _filePath, _size, _mode, _cursor=0):
        super().__init__(_parent, _filePath, _size, _mode, _cursor)

    def Read(self, _length=1):
        self._checkAccessMode(E_FILE_MODE.READ)
        self._checkOutBoundExcept(self.cursor.GetIndex() + _length)

        hadoopStorage = self.parent.GetStorageEndPoint()
        with hadoopStorage.read(self.filePath,
                                offset=self.cursor.GetIndex(),
                                length=_length) as data:
            self.cursor.Seek(_length)
            return data.read()

    def ReadAll(self):
        self._checkAccessMode(E_FILE_MODE.READ)
        hadoopStorage = self.parent.GetStorageEndPoint()
        with hadoopStorage.read(self.filePath) as data:
            return data.read()

    def Seek(self, _offset):
        self._checkAccessMode(E_FILE_MODE.READ)
        self._checkOutBoundExcept(self.cursor.GetIndex() + _offset)
        self.cursor.Seek(_offset)

    def Write(self, _data, _overwrite=True):
        self._checkAccessMode(E_FILE_MODE.WRITE)
        hadoopStorage = self.parent.GetStorageEndPoint()
        hadoopStorage.write(self.filePath, _data, _overwrite)
        self.size += len(_data)
