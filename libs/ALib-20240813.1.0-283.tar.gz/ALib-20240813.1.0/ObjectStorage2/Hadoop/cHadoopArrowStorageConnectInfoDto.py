# from pyarrow import fs
#
# from ObjectStorage2.abObjectStorageConnectInfoDto import abObjectStorageConnectInfoDto
#
#
# class cHadoopArrowStorageConnectInfoDto(abObjectStorageConnectInfoDto):
#
#     def __init__(self, _address, _port, _access_key):
#         super().__init__(_address, _port, _access_key)
#
#     def Connect(self):
#         # return pyarrow.fs.HadoopFileSystem(host=self.address,
#         #                                    port=int(self.port),
#         #                                    user=self.access_key)
#         # return hdfs.HadoopFileSystem(host=self.address,
#         #                              port=int(self.port),
#         #                              user=self.access_key)
#         return fs.HadoopFileSystem(host=self.address,
#                                    port=int(self.port),
#                                    user=self.access_key)
#         # return pyarrow.hdfs.HadoopFileSystem(host=self.address,
#         #                                    port=int(self.port),
#         #                                    user=self.access_key)
#
#     def GetRoot(self):
#         return "/"
