from hdfs import InsecureClient

from ObjectStorage2.IAutoClose import IAutoClose


class CustomInsecureClient(InsecureClient, IAutoClose):

    def __init__(self, url, user=None, **kwargs):
        super(InsecureClient, self).__init__(url, user, **kwargs)

    def close(self):
        self._session.close()
