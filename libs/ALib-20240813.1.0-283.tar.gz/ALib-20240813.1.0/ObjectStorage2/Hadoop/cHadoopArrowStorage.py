# import pyarrow.hdfs
#
# from LibUtils.FileLists import FileLists
# from ObjectStorage2.Hadoop.cHadoopFileObjectContainer import cHadoopFileObjectContainer
# from ObjectStorage2.Hadoop.cHadoopObjectContainer import cHadoopObjectContainer
# from ObjectStorage2.Hadoop.cHadoopObjectProperty import cHadoopObjectProperty
# from ObjectStorage2.IObjectStorageConnectInfoDto import IObjectStorageConnectInfoDto
# from ObjectStorage2.abObjectStorage import abObjectStorage
# from ObjectStorage2.eStorageType import eStorageType
#
#
# class cHadoopArrowStorage(abObjectStorage):
#     def __init__(self, _connectInfoDto: IObjectStorageConnectInfoDto):
#         super().__init__(eStorageType.HADOOP, _connectInfoDto, cHadoopFileObjectContainer())
#
#     def Stat(self, _path):
#         return self.storage.get_file_info(_path)
#         # `return cHadoopObjectProperty(self._getUpperPath(_path),
#         #                              (FileLists.extractFileName(_path, "/"), self.storage.status(_path)))`
#
#     def List(self, _path):
#
#         return cHadoopObjectContainer(self.storageType,
#                                       self.storage.walk(hdfs_path=_path,
#                                                         depth=1,
#                                                         status=True)
#                                       ).GetStorageObjectProperties()
#
#     # def Walk(self, _path):
#     #     # result = self.storage.walk(hdfs_path=_path,
#     #     #                   depth=0,
#     #     #                   status=True)
#     #     # o = 1
#     #     return cHadoopObjectContainer(self.storageType,
#     #                                   self.storage.walk(hdfs_path=_path,
#     #                                                     depth=0,
#     #                                                     status=True)
#     #                                   ).GetStorageObjectProperties()
#     #
#     # def Upload(self, _srcPath, _dstPath, _overwrite=True):
#     #     if not self.storage.status(_dstPath, strict=False):
#     #         self.storage.makedirs(_dstPath)
#     #
#     #     self.storage.upload(self._makeUploadPath(_dstPath), _srcPath, overwrite=_overwrite)
#     #
#     # def UploadFile(self, _srcPath, _dstPath, _overwrite=True):
#     #     self.storage.upload(_dstPath, _srcPath, overwrite=_overwrite)
#     #     pass
#     #
#     # def UploadFolder(self, _srcPath, _dstPath, _overwrite=True):
#     #     self.storage.upload(_dstPath, _srcPath, overwrite=_overwrite)
#     #
#     # def Download(self, _srcPath, _dstPath, _overwrite=True):
#     #     self.storage.download(_srcPath, _dstPath, overwrite=_overwrite)
#     #
#     # def Delete(self, _path):
#     #     self.storage.delete(_path, recursive=True)
#     #
#     # def IsDir(self, _path):
#     #     from ObjectStorage2.Hadoop.cHadoopObjectProperty import HadoopFileInfoType
#     #     return self.storage.status(_path)[HadoopFileInfoType.TYPE.value] == "DIRECTORY"
