from abc import abstractmethod
from enum import Enum


class E_FILE_MODE(Enum):
    READ = "r"
    WRITE = "w"

class IObjectStorage:

    @abstractmethod
    def Connect(self):
        pass

    @abstractmethod
    def Disconnect(self):
        pass

    @abstractmethod
    def Open(self, _filePath, _mode):
        pass

    @abstractmethod
    def Close(self, _filePath):
        pass

    @abstractmethod
    def GetFileObject(self, _path):
        pass

    @abstractmethod
    def Stat(self, _path):
        pass

    @abstractmethod
    def List(self, _path):
        pass

    @abstractmethod
    def Walk(self, _path):
        pass

    @abstractmethod
    def Upload(self, _srcPath, _dstPath, _overwrite=True):
        pass

    @abstractmethod
    def UploadFile(self, _srcPath, _dstPath, _overwrite=True):
        pass

    @abstractmethod
    def UploadFolder(self, _srcPath, _dstPath, _overwrite=True):
        pass

    @abstractmethod
    def Download(self, _srcPath, _dstPath, _overwrite=True):
        pass

    @abstractmethod
    def Delete(self, _path):
        pass

    @abstractmethod
    def IsDir(self, _path):
        pass

    @abstractmethod
    def IsExist(self, _path):
        pass

    @abstractmethod
    def GetStorageEndPoint(self):
        pass
