from abc import abstractmethod


class IFileObject:

    @abstractmethod
    def Read(self, _length=1):
        pass

    @abstractmethod
    def ReadAll(self):
        pass

    @abstractmethod
    def Seek(self, _offset):
        pass

    @abstractmethod
    def Write(self, _data, _overwrite=True):
        pass

    @abstractmethod
    def Close(self):
        pass
