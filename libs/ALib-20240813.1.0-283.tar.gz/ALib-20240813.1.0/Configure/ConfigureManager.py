import sys

from Configure.ConfigParser import ConfigParser
from LibUtils.SingletonInstane import SingletonInstane


class ConfigureManager(SingletonInstane):

    def __init__(self):
        self.configs = {}
        pass

    def appendConfig(self , alias , file_path):

        # if alias not in self.configs:
        self.configs[alias] = ConfigParser( alias,file_path )

        pass

    def getConfig(self , alias ):

        return self.configs[alias]

        pass

    def println(self):

        for alias , configParser in self.configs.items():

            configParser.println()

            pass

        pass


    pass






def main(argv):
    ConfigureManager.instance().appendConfig( "a" , "D:\\project\\project_swm\\apollo\\code_third\\infra-glue-traffic-information-collector\\config\\config.conf" )

    ConfigureManager.instance().println()

    print(ConfigureManager.instance().getConfig("a").get("Setting","collectmincycle"))


    pass

if __name__ == '__main__':
    main(sys.argv)


