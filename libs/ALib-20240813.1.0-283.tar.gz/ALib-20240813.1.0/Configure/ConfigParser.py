import configparser


class ConfigParser(object):

    def __init__(self , alias , file_path ):

        self.alias = alias
        self.file_path = file_path

        self.config = configparser.ConfigParser()

        self.config.read(file_path)

    def get(self,section,key):

        return self.config[section][key]

        pass

    def getConfig(self):
        return self.config


    def println(self):
        #
        # vv=self.config.sections()
        # print(self.config['Common']['BaseUrl'])

        for alias , config  in self.config.items():
            print( "section nm : " + alias)
            for k , v in  config.items():
                print(" K : " + k + " V : " + v )
                pass

            pass

        pass


    pass