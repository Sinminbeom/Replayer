import inspect
import logging
import logging.config
from configparser import ConfigParser
from enum import Enum

from LibUtils.SingletonInstane import SingletonInstane


class IENUM:
    pass


class E_CONFIG_META(Enum):
    MODE = 'mode'
    TYPE = 'type'


class E_LOG_LEVEL(Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    EXCEPTION = "EXCEPTION"
    CRITICAL = "CRITICAL"


class E_LOG_MODE(Enum):
    ROOT = "root"
    CONSOLE = "consoleLogger"
    FILE = "fileLogger"
    COMBO = "comboLogger"



class cLogger(SingletonInstane):

    def __init__(self, _name: E_LOG_MODE = "", _configFile="../config/logging-new.conf", _version=""):
        self.name = _name.value
        self.configFile = _configFile
        self.version = _version
        logging.config.fileConfig(_configFile)
        self.logger = logging.getLogger(self.name)

    def __getMode(self, _name, _configFile):
        if _name == "":
            config = ConfigParser()
            config.read(_configFile)

            return E_LOG_MODE.Get(config[E_CONFIG_META.MODE.value][E_CONFIG_META.TYPE.value])

        return _name

    def Debug(self, _message):
        self.logger.debug(self.__makeMessage(E_LOG_LEVEL.DEBUG, _message))

    def Info(self, _message):
        self.logger.info(self.__makeMessage(E_LOG_LEVEL.INFO, _message))

    def Warning(self, _message):
        self.logger.warning(self.__makeMessage(E_LOG_LEVEL.WARNING, _message))

    def Error(self, _message):
        self.logger.exception(self.__makeMessage(E_LOG_LEVEL.ERROR, _message))

    def Critical(self, _message):
        self.logger.critical(self.__makeMessage(E_LOG_LEVEL.CRITICAL, _message))

    def Exception(self, _message):
        self.logger.exception(self.__makeMessage(E_LOG_LEVEL.EXCEPTION, _message))

    def Print(self, _logType: E_LOG_LEVEL, _message: str):

        message = self.__makeMessage(_logType, _message)
        if _logType == E_LOG_LEVEL.DEBUG:
            self.logger.debug(message)
        elif _logType == E_LOG_LEVEL.INFO:
            self.logger.info(message)
        elif _logType == E_LOG_LEVEL.WARNING:
            self.logger.warning(message)
        elif _logType == E_LOG_LEVEL.ERROR:
            self.logger.exception(message)
        elif _logType == E_LOG_LEVEL.EXCEPTION:
            self.logger.exception(message)
        elif _logType == E_LOG_LEVEL.CRITICAL:
            self.logger.critical(message)
        else:
            self.logger.exception(message)

    def __makeMessage(self, _logType, message):
        stack = inspect.stack()
        caller_frame = stack[2]
        filename = caller_frame.filename
        lineno = caller_frame.lineno
        instance = caller_frame.frame.f_locals.get("self", None)
        if instance:
            class_name = instance.__class__.__name__
        else:
            class_name = '<no-class>'

        method_name = caller_frame.function

        if self.version != "":
            return f"[{self.version}] [{filename} {lineno} - {class_name}.{method_name}] [{_logType.value}] : {message}"

        return f"[{filename} {lineno} - {class_name}.{method_name}] [{_logType.value}] : {message}"

#
# class Test:
#     logger = cLogger.instance()
#
#     def test(self):
#         Test.logger.Info("Test123 --> Test")
#
#
# def main():
#     logger = cLogger.instance()
#     logger.Info("test123")
#
#
# class TT:
#     def main12345(self):
#         def main2():
#             def main3():
#                 def main4():
#                     def main5():
#                         raise Exception
#
#                     main5()
#
#                 main4()
#
#             main3()
#
#         try:
#             main2()
#         except Exception as e:
#             cLogger.instance().Exception(e)
#             # cLogger.instance().Info(e)
#
#
# if __name__ == '__main__':
#     main()
#
#     print("-------------------------------")
#     Test().test()
#     print("-------------------------------")
#     TT().main12345()
