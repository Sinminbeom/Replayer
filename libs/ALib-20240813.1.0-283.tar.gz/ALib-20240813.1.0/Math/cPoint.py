

class cPoint(object):

    def __init__(self , _x , _y):
        self.x = _x
        self.y = _y

    def getX(self):
        return self.x

    def getY(self):
        return self.y

    def setX(self,_x):
        self.x=_x

    def setY(self,_y):
        self.y=_y

    def getTuple(self):
        return (self.x,self.y)

    def toString(self):
        return f'x:{self.x} , y:{self.y}'


    @staticmethod
    def minus( p1 , p2 ):
        return cPoint ( p2.getX() - p1.getX() ,  p2.getY() - p1.getY()  )
