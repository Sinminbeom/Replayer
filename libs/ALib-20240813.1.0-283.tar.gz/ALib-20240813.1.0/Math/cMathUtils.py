import math



class cMathUtils( object ):

    def __init__(self):

        pass


    ## get angle cpoint p1 , p2 사이 각도
    @staticmethod
    def getAngle ( p1 , p2 ):
        # np = cPoint.minus( p1 , p2 )
        # return math.atan2( np.getX() , np.getY()  )  * 180 / math.pi

        return math.degrees(math.atan2( p2.getLat() - p1.getLat() , p2.getLon() - p1.getLon() ))
        # return math.degrees(math.atan2(p2.getLon() - p1.getLon(), p2.getLat() - p1.getLat()))

        # return math.atan2( p2.getLon() - p1.getLon(),  p2.getLat() - p1.getLat()) * 180 / math.pi
        # return math.atan2( p2.getLat() - p1.getLat(),  p2.getLon() - p1.getLon()) * 180 / math.pi



