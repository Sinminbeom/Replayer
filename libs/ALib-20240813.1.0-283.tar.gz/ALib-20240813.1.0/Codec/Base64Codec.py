import base64

class Base64Codec:

    def encode(self, message):
        return base64.b64encode(bytes(message, 'UTF-8')).decode()

    def decode(self, base64_message):
        return base64.b64decode(bytes(base64_message, 'UTF-8')).decode()

    def isBase64(self, sb):
        try:
            if isinstance(sb, str):
                sb_bytes = bytes(sb, 'UTF-8')
            elif isinstance(sb, bytes):
                sb_bytes = sb
            else:
                raise ValueError("Argument must be string or bytes")
            return base64.b64encode(base64.b64decode(sb_bytes)) == sb_bytes
        except Exception:
            return False

def main():
    str = """aa메시지!!@@##$$%%^^&&**메시지 TEST !!"""

    base64Codec = Base64Codec()

    encode = base64Codec.encode(str)

    isBase64 = base64Codec.isBase64(encode)
    isBase642 = base64Codec.isBase64(str)

    decode = base64Codec.decode(encode)

    print(f"isBase64 = {isBase64}")
    print(f"isBase642 = {isBase642}")
    print(f"encode = {encode}")
    print(f"decode = {decode}")

if __name__ == "__main__":
    main()

