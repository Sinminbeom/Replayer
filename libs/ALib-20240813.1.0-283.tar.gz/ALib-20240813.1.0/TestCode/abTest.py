
class aa:

    @staticmethod
    def aa():
        print("aa")
        pass

class bb (aa):

    @staticmethod
    def aa():
        print("bb")
        pass


def main():
    bb().aa()

if __name__ == '__main__':
    main()


