


import socket

def main():
    # UDP 클라이언트 설정
    server_ip = '127.0.0.1'
    server_port = 12345

    # 소켓 생성
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # 전송할 데이터
    data = "Hello, UDP Server!".encode('utf-8')

    # 1바이트씩 전송
    for byte in data:
        client_socket.sendto(byte.to_bytes(1, 'little'), (server_ip, server_port))

    client_socket.close()
    print("데이터 전송 완료")



    pass

if __name__ == '__main__':
    main()
