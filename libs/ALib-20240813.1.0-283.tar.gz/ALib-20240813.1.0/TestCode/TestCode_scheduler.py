import time

from apscheduler.schedulers.background import BackgroundScheduler

from Log.Log import Log, eLogType



def job1():

    print("1")

def job2():
    print("2")


def main():
    log = Log(_version="v1",_configFile="../../config/logging.conf")
    log.Print(eLogType.INFO, "test")



    sched=BackgroundScheduler()
    sched.start()

    sched.add_job(job1 , 'cron' , second='*/1')

    while True:
        print("-------------------")
        time.sleep(1)

if __name__ == "__main__":
    main()
