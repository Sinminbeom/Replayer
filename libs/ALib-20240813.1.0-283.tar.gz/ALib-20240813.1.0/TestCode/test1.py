
import time

def my_decorator(func):
    def wrapper(*args, **kwargs):
        # 추가할 기능의 코드
        func(*args, **kwargs)
        # 추가할 기능의 코드
    return wrapper
#
# @my_decorator
# def my_function(arg1, arg2):
#     print(f"인자: {arg1}, {arg2}")


def my_decorator_with_args(decorator_arg1):
    def my_decorator(func):
        def wrapper(*args, **kwargs):
            # decorator_arg1을 사용한 추가 기능의 코드
            print(f"데코레이터 인자: {decorator_arg1}")
            func(*args, **kwargs)
            # 추가 기능의 코드
        return wrapper
    return my_decorator

@my_decorator_with_args("특정 인자")
def my_function(arg1, arg2):
    print(f"함수 인자: {arg1}, {arg2}")

def main():
    my_function("안녕", "파이썬")


    #
    # start_time = time.time()
    #
    # end_time = time.time()
    #
    # execution_time = end_time - start_time
    #
    # print(f"run t {execution_time}")

    pass


if __name__ == '__main__':
    main()