import multiprocessing

def record_processer(shared_queue, value):
    # record process

    li=[]
    while(True):
        thread_parm = None
        with shared_queue.get_lock():
            if shared_queue.size() > 0:
                thread_parm =shared_queue.pop()
            pass
        pass

        #li.append() thread_parm -> processing
        #처리
    
        

def record_parser(shared_queue):
    # record read
    
    while(True):
        # record reading:
            # mes 

        thread_parm=100
        with shared_queue.get_lock():
            shared_queue.push(thread_parm)
            # shared_queue
        
        pass
    
    with shared_queue.get_lock():
        shared_list.append(value)



if __name__ == "__main__":
    manager = multiprocessing.Manager()

    q= manager.Queue()
    # shared_list = manager.list()
    # shared_value = manager.Value('i', 1)

    processes = []

    p1 = multiprocessing.Process(target=record_parser, args=(q))
    p1.start()
    

    for i in range(5):
        p2 = multiprocessing.Process(target=record_processer, args=(shared_queue))
        p2.start()
        
        

    for p in processes:
        p.join()

    # print(f"공유된 리스트: {shared_list}")
    # print(f"공유된 값: {shared_value.value}")