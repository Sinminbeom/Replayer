# from Core.Pcap.cPcapMessageBuffer import cPcapMessageBuffer
# from Core.Storage.eStorageInfo import eStorageInfo

# import psutil
import time
import gc

class TestClass:
    def __init__(self):
        self.name = "minbeom"
        self.age = 29
        self.gender = "male"





class testCode:

    def __init__(self):
        # from Core.utils.ICollection import CircularQueue
        # from memoryChecker import memoryChecker
        from Collections.ICollection import CircularQueue
        self._circularQueue = CircularQueue()
        from LibUtils.memoryChecker import memoryChecker
        self._memchecker = memoryChecker()

        self._init_()





    @staticmethod
    def pushSource( circular_queue  , string_head  , time_strinmg  , string_tail ):

        str=f"{string_head}{time_strinmg}{string_tail}"

        circular_queue.add( str )
        pass

    def _init_(self):

        from TimeUtils.cTimeStringFit import cTimeStringFit
        from TimeUtils.cTimeStringFit import cTimeStringInterVal
        from TimeUtils.cTimeStringFit import E_CALENDAR_TYPE

        "/normalized-data-storage/E100-1/lidar/at128_roof_left/20240819/10/10/at128_roof_left_20240819101040.pcap"
        cTimeStringFit().Coroutine("20240819101030", "20240819101059",
                                   cTimeStringInterVal(E_CALENDAR_TYPE.SEC, 1),
                                   lambda time_string_fit: testCode.pushSource(self._circularQueue ,
                                                                               "/normalized-data-storage/E100-1/lidar/at128_roof_left/20240819/10/10/at128_roof_left_" ,
                                                                               time_string_fit.Get() ,
                                                                                 ".pcap"),
                                   "<="
                                   )

        "/normalized-data-storage/E100-1/lidar/at128_roof_left/20240819/11/00/at128_roof_left_20240819110000.pcap"
        cTimeStringFit().Coroutine("20240819110000", "20240819110059",
                                   cTimeStringInterVal(E_CALENDAR_TYPE.SEC, 1),
                                   lambda time_string_fit: testCode.pushSource(self._circularQueue ,
                                                                               "/normalized-data-storage/E100-1/lidar/at128_roof_left/20240819/11/00/at128_roof_left_" ,
                                                                               time_string_fit.Get() ,
                                                                                 ".pcap"),
                                   "<="
                                   )





    def __readFile(self ,_storage, _srcPath, _filter=None):
        """ Reads 3 Seconds Pcap Files """
        messageBuffer = cPcapMessageBuffer(_storage, _srcPath, _filter)
        # messageBuffer.ReadPreviousFile()
        # messageBuffer.ReadNextFile()
        return messageBuffer


    def work( self ):

        while True:
            storage = eStorageInfo.Factory(eStorageInfo.HADOOP)

            filename= self._circularQueue.next()

            messageBuffer = self.__readFile(storage,filename)

            # messageBuffer = __readFile(storage,
            #                            "/normalized-data-storage/E100-1/lidar/at128_roof_left/20240819/10/10/at128_roof_left_20240819101040.pcap")
            # print(messageBuffer.GetBuffer().indexRecord.fileIndexes)


            messageBuffer.Clear()
            messageBuffer = None
            storage = None

            gc.collect()
            # memory_usage()


            self._memchecker.println()

            # memory_checker.println()
            # time.sleep(0.2)






def main():
    # memory_usage()

    # memory_usage()

    # 2024 08 19           10 10 30
    # 20240819101030

    tc = testCode()


    tc.work()



    # from TimeUtils.cTimeStringFit import cTimeStringFit
    # from TimeUtils.cTimeStringFit import cTimeStringInterVal
    # from TimeUtils.cTimeStringFit import E_CALENDAR_TYPE
    # cTimeStringFit().Coroutine("20240819101030", "20240819101059",
    #                            cTimeStringInterVal(E_CALENDAR_TYPE.SEC, 1),
    #                            lambda time_string_fit: print(time_string_fit.Get()),
    #                            "<="
    #                            )
    #
    # from memoryChecker import memoryChecker
    # mcr = memoryChecker()
    #
    # work(mcr)

    # while True:
    #     memory_usage()
    #     time.sleep(1)



if __name__ == '__main__':
    main()

