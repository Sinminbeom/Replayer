from Log.Log import Log, eLogType


def main():
    log = Log(_version="v1",_configFile="../config/logging.conf")
    log.Print(eLogType.INFO, "test")


if __name__ == "__main__":
    main()

