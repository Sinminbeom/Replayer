from PCap.Reader.PcapReader import FilterLamdaAct


#
#
# def memory_usage(message: str = 'debug'):
#     # current process RAM usage
#     import psutil
#
#     global top_memory_usage
#
#     p = psutil.Process()
#     rss = p.memory_info().rss / 2 ** 20 # Bytes to MB
#
#     if top_memory_usage < rss:
#         top_memory_usage = rss
#         print(f">>>>>>>>>>>>>>>>>>>>>>>>>>> TOP [{message}] memory usage: {rss: 10.5f} MB")
#
#
#
#
#     print(f"[{message}] memory usage: {rss: 10.5f} MB")
#


def main():
    # pcap_file = """D:\\dt\\t1010\\at128_roof.pcap"""
    # pcap_file = """D:\\dt\\at128_roof_front.pcap"""
    # pcap_file = """D:\\dt\\rtest\\am20_rear.pcap"""

    # pcap_file = """C:\\Users\\swmai\\Desktop\\gnss\\gnss.pcap"""  ## tcp, linux cooked v1
    # pcap_file = """C:\\Users\\swmai\\Desktop\\a20231018\\udp_dump_2023-09-18_15_43_18.pcap""" ## udp, linux cooked v1
    # pcap_file = """C:\\Users\\swmai\\Desktop\\p20230727\\video_1.pcap""" ## udp, linux cooked v2
    # pcap_file = """C:\\Users\\swmai\\Desktop\\a20231018\\ttt\\test.pcap"""
    pcap_file = """D:\\dt\gnss\\gnss_20240201135956.pcap"""

    pcap_file = """D:\\dt\\data_test\\at128_roof_rear_20231006165306.pcap"""

    import sys
    print(sys.byteorder)

    import gc

    from LibUtils.memoryChecker import memoryChecker
    mc = memoryChecker()


    from PCap.Reader.PcapReader import cPcapReader

    # pcapreader = cPcapReader(lambda _pcap_packet_header, _pcap_body: FilterLamdaAct(_pcap_packet_header, _pcap_body))
    while True:

        pcapreader = cPcapReader(lambda _pcap_packet_header, _pcap_body: FilterLamdaAct(_pcap_packet_header, _pcap_body))
        pcapreader.ReadPcap(pcap_file, None)

        pcapreader.Close()

        # mc.println()
        # memory_usage()
        gc.collect()
        mc.println()


    # pcapreader.Println()

    pass


if __name__ == '__main__':
    main()
