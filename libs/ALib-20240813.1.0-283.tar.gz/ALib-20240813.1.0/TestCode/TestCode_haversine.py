import math

from Configure.ConfigureManager import ConfigureManager
from Geo.cGeoPoint import cGeoPoint
from Geo.cGeoUtils import cGeoUtils

from Log.Log import Log, eLogType


def getangle( p1 , p2 ):
    # p1 = (37.3953790, 126.9398185)
    # p2 = (37.3931422, 126.9429075)

    return math.atan2( p2[1]-p1[1] , p2[0]-p1[0] ) * 180 / math.pi




    pass


def main():
    # log = Log(_version="v1",_configFile="../../config/logging.conf")
    # log.Print(eLogType.INFO, "test")

    # 2026651
    # LINESTRING(
    # 126.940023 , 37.395112
    # 126.94212  , 37.393525,
    # 126.943603 , 37.392369,
    # 126.943806 , 37.392218,
    # 126.944007 , 37.392071,
    # 126.944219 , 37.39191,
    # 126.944366 , 37.391802
    # )
    ConfigureManager.instance().appendConfig("a",
                                             "D:\\project\\project_swm\\apollo\\code_third\\infra-glue-traffic-information-collector\\config\\config.conf")

    ConfigureManager.instance().println()

    # point1 = cGeoPoint( 37.395112 , 126.940023  )
    # point2 = cGeoPoint( 37.393525 , 126.94212  )

    # point1 = cGeoPoint(37.395112, 126.940023)
    # point2 = cGeoPoint(37.393525, 126.94212)
    #
    point1 = cGeoPoint(37.396776, 126.952755)
    point2 = cGeoPoint(37.397866, 126.946231)

    point1 = cGeoPoint(38 + 0, 126 + 0)
    point2 = cGeoPoint(38 + 1, 126 + 1)


    # point2 = cGeoPoint( 0 + 10 , 0  )  ## 90
    # point2 = cGeoPoint( 0 + 10 , 0 + 10  )  ## 45
    # point2 = cGeoPoint( 0 , 0 + 10  )  ## 0
    # point2 = cGeoPoint( 0 - 10 , 0 + 10  )  ## -45
    # point2 = cGeoPoint( 0 - 10 , 0 )   ## -90
    # point2 = cGeoPoint( 0 - 10 , 0 - 10 )   ## -135
    # point2 = cGeoPoint( 0 , 0 - 10)    ## 180
    # point2 = cGeoPoint( 0 + 10 , 0 - 10)    ## 135

    a = cGeoUtils.getAngle( point1 , point2 )

    bb= cGeoUtils.calculate_bearing( point1.getLon() , point1.getLat() ,
                           point2.getLon() , point2.getLat() )

    print("a:" , a)
    print("b:", bb)

    dis= cGeoUtils.distance( point1 , point2 )

    print(dis)


    point3 = cGeoUtils.getInverseGeoPoint( point1 , a , 0.1 )

    print(point3.toString())

    #
    # paris = cGeoPoint(2.3508 , 48.8567 )    ## 135
    #
    # point = cGeoUtils.getInversePoint(paris, 0, 50, unit=Unit.MILES)
    #
    # print(f'p:{point}')

    # print( point1.getTuple() )
    # print( point2.getTuple() )

    # ang = cGeoUtils.getAngle( point1 , point2 )
    # dis = cGeoUtils.distance(point1 , point2 )
    # #
    # print(f' dis : {dis} , ang : {ang}')
    #
    # dis=10
    #
    # for i in range(0, 90 ):
    #
    #     x = math.cos( math.radians( i ) ) * dis
    #     y = math.sin( math.radians( i ) ) * dis
    #
    #     print( f'X: {x} , Y: {y} , deg: {i}')
    #     print( getangle( (0,0)  , ( x , y)  ) )
    #
    #



if __name__ == "__main__":
    main()



