import hashlib

from Security import  HashSecurity


def decryptMD5(testHash):
    s = []
    while True:
        m = hashlib.md5()
        for c in s:
            m.update(chr(c))
        hash = m.hexdigest()
        if hash == testHash:
            return ''.join([chr(c) for c in s])
        wrapped = True
        for i in range(0, len(s)):
            s[i] = (s[i] + 1) % 256
            if s[i] != 0:
                wrapped = False
                break
        if wrapped:
            s.append(0)

def main():
    # log = Log(_version="v1")
    # log.Print(eLogType.INFO, "test")

    print( HashSecurity.EncryptMD5("나는 긴 글을 좋아한다. 긴 글의 여백도 좋고 빡빡하게 다져진 호흡도 좋다. 긴 글을 쓰기에 나는 이미 플랫폼에 너무나 적응을 잘 한 상태이겠지만, 오랜만에 돌아오거나 플랫폼의 적응과 관계 없이 (긴) 글 스타일을 고수하는 사람들을 글을 읽을 때면 즐거워진다. 어떤 가치를 고수하는 건 그만큼 (누군가에는) 어렵고 매일을 다잡지 않으면 안되는 일이기 때문이다.") )
    #
    # decryptMD5('530c74396e1d2e0faf6f008916fce1a1')

if __name__ == "__main__":
    main()

