from shapely import Polygon, Point

from Log.Log import Log, eLogType






def main():
    log = Log(_version="v1",_configFile="../../config/logging.conf")
    log.Print(eLogType.INFO, "test")

    engineer = [(37.245452, 127.079964), (37.247041, 127.079842), (37.247912, 127.081486), (37.245588, 127.081612)]
    engineer_poly = Polygon(engineer)

    test_code1 = Point(37.245434, 127.078640)

    test_code2 = Point(37.246416, 127.080324)

    print(test_code1.within(engineer_poly) )
    print(test_code2.within(engineer_poly))

if __name__ == "__main__":
    main()

