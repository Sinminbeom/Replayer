import json
from RestCall.RestCall import RestCall

def main():
    RestCall().instance().Init(poolRetries=True, poolConn=0.1)
    res = RestCall().instance().appendRequest('GET', "https://apis.openapi.sk.com/tmap/traffic?version=1&minLat=37.377685546875&minLon=126.93961334228516&maxLat=37.40251159667969&maxLon=126.97709655761719&reqCoordType=WGS84GEO&resCoordType=WGS84GEO&zoomLevel=19&sort=index&callback=function", headers={'appKey': 'KEomRe4kRU7FiM9bpPF0k7GpQlZo2CvNJexHJSx0'})
    resJson = json.loads(res['result'].data)
    print(f"""성공여부 = {res['isSuccess']}, 결과 = {resJson}""")

if __name__ == "__main__":
    main()
