from DbMgr import IDB_Lists
from DbMgr import cDBManager
from DbMgr import cPostgreSqlDBOBJ
from DbMgr.cDBProperty import cMysqlProperty
from DbMgr.cDB_DEFINES import I_DB__ALIAS
from Log.Log import eLogType, Log


class E_DB_AS(I_DB__ALIAS):
    DB1 = 100




class cDB_Info_Test( IDB_Lists ):
    def __init__(self):
        IDB_Lists.__init__(self ,
                           {
                               E_DB_AS.DB1:cPostgreSqlDBOBJ(
                                   cMysqlProperty(host='192.168.1.92',
                                                  port=25434,
                                                  user='docker',
                                                  password='docker',
                                                  dbname='gis'))
                           })


def main():
    log = Log(_version="v1", _configFile="../../config/logging.conf")
    log.Print(eLogType.INFO, "test")


    DBM = cDBManager(cDB_Info_Test())

    DBObj = DBM.GetDbObject(E_DB_AS.DB1)
    DBObj.Connect()

    qry="""
    select 1 
    """

    results = DBObj.ExecuteQuery(qry)

    for row in results:
        print ( row[0])

    DBObj.Close()

    DBM.CloseAll()


if __name__ == "__main__":
    main()



