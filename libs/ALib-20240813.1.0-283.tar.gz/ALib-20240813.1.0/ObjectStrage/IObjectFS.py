class IObjectFS:

    def GetFile(self):
        pass

    def FileName(self):
        pass

    def Path(self):
        pass

    def Size(self):
        pass

    def LastModified(self):
        pass

    def IsDir(self):
        pass
