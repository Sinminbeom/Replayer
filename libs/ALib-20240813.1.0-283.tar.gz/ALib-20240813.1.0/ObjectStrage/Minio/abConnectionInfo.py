class ConnectionInfo:
    def __init__(self, _configPath):
        self.configPath = _configPath
        pass
