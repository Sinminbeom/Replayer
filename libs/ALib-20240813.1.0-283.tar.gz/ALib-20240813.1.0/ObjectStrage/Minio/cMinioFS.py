from ObjectStrage.cObjectType import ObjectType
from ObjectStrage.abObjectFS import abObjectFS


class cMinioFS(abObjectFS):

    def __init__(self, _minioFile):
        super(cMinioFS, self).__init__(ObjectType.MINIO, _minioFile)

    def fileName(self):
        obj_name = self.GetFile().object_name
        return obj_name.split("/")[-1]

    def path(self):
        obj_name = self.GetFile().object_name
        obj_path = obj_name.split("/")[:-1]
        return "/".join(obj_path) + "/"

    def size(self):
        return self.GetFile().size

    def lastModified(self):
        return self.GetFile().last_modified

    def isDir(self) -> bool:
        return self.GetFile().is_dir

    def bucket(self) -> str:
        return self.GetFile().bucket_name

    def owner(self) -> str:
        return self.GetFile().owner_name
