import os.path


class cTransferDto:

    def __init__(self, _minioPath, _localPath, _originalFilename, _targetFilename, _isProgress):
        self.minioPath = _minioPath
        self.localPath = _localPath
        self.originalFilename = _originalFilename
        self.targetFilename = _targetFilename
        self.isProgress = _isProgress


    def GetUploadInfo(self):
        if os.path.isdir(self.localPath):
            return str(self.localPath) + str(self.originalFilename), str(self.minioPath), str(self.targetFilename), str(self.isProgress)
        return str(self.localPath), str(self.minioPath), str(self.targetFilename), str(self.isProgress)


    def GetDownloadInfo(self):
        return str(self.minioPath) + str(self.originalFilename), str(self.localPath), str(self.targetFilename)

    def GetRemoveInfo(self):
        return str(self.minioPath) + str(self.originalFilename)