import time

from MultiProcess.cMultiProcessRunner import cMultiProcessRunner
from ObjectStrage.Minio.cMinioConnectionInfo import cMinioConnectionInfo
from ObjectStrage.Minio.cMinioStorage import cMinioStorage
from ObjectStrage.abObjectStorage import DEFAULT_PROCESS_SIZE
from ObjectStrage.abStorageManager import abObjectStorageManager

CONFIG_FILE = "../../config/config.conf"


class cMinioManager(abObjectStorageManager):

    def __init__(self, _configFile=CONFIG_FILE):
        self.objectStorage = cMinioStorage(cMinioConnectionInfo(_configFile))

    def ChangeBucket(self, bucket):
        self.objectStorage.ChangeBucket(bucket)

    def GetFileList(self, minioPath, isRecursive=False):
        return self.objectStorage.GetFileInfoList(minioPath, isRecursive)

    def Upload(self, minioPath, localPath, targetFilename=None, isProgress=False):
        self.objectStorage.Upload(minioPath, localPath, targetFilename, isProgress)

    def Download(self, minioPath, localPath, targetFilename=None):
        self.objectStorage.Download(minioPath, localPath, targetFilename)

    def Remove(self, minioPath):
        self.objectStorage.Remove(minioPath)

    def UploadAsync(self, minioPath, localPath, targetFilename=None, isProgress=False):
        return self.objectStorage.UploadAsync(minioPath, localPath, targetFilename, isProgress)

    def DownloadAsync(self, minioPath, localPath, targetFilename=None):
        return self.objectStorage.DownloadAsync(minioPath, localPath, targetFilename)

    def RemoveAsync(self, minioPath):
        return self.objectStorage.RemoveAsync(minioPath)

    pass


def main():
    client = cMinioManager()
    client.Connect()

    client.GetFileList("/E100-02", True)

    # cMultiProcessRunner.instance().Init(DEFAULT_PROCESS_SIZE)
    # cMultiProcessRunner.instance().Start()

    # client.UploadAsync(r"C:\Users\swmai\Desktop\swm\python\infra-glue-python-template\config\config.conf", "d1/uploadTest3")
    #
    # while True:
    #     if cMultiProcessRunner.instance().IsRunning():
    #         time.sleep(1)
    #         print("1sec")


    # client.Upload(r"C:\\Users\\swmai\\Desktop\\swm\\dummy\\20230628", "d1/uploadTest26")
    # client.Upload(r"C:\\Users\\swmai\\Desktop\\swm\\dummy\\20230628\\", "d1/uploadTest27")
    # client.Upload(r"C:\\Users\\swmai\\Desktop\\swm\\python\\lib\\infra-glue-python-template\\config\\config.conf", "d1/uploadTest25/")
    # client.Upload(r"C:\\Users\\swmai\\Desktop\\swm\\python\\lib\\infra-glue-python-template\\config\\config.conf", "d1/uploadTest25", "test.conf")
    # cMultiProcessRunner.instance().Stop()

    # client.UploadAsync(r"C:\\Users\\swmai\\Desktop\\swm\\dummy\\20230628", "d1/uploadTest23")
    # client.UploadAsync(r"C:\\Users\\swmai\\Desktop\\swm\\python\\lib\\infra-glue-python-template\\config\\", "d1/uploadTest24")
    # client.UploadAsync(r"C:\\Users\\swmai\\Desktop\\swm\\python\\lib\\infra-glue-python-template\\config\\config.conf", "d1/uploadTest26")
    # client.UploadAsync(r"C:\\Users\\swmai\\Desktop\\swm\\python\\lib\\infra-glue-python-template\\config\\config.conf", "d1/uploadTest26/", "test.conf")

    # client.Download("d1/uploadTest23/config.conf", "C:\\Users\\swmai\\Desktop\\swm\\minio5")
    # client.Download("d1/uploadTest23/config.conf", "C:\\Users\\swmai\\Desktop\\swm\\minio5", "asdf.conf")
    # client.Download("d1/uploadTest23/config.conf", "C:\\Users\\swmai\\Desktop\\swm\\minio3\\")
    # client.Download("d1/uploadTest23/config.conf", "C:\\Users\\swmai\\Desktop\\swm\\minio3\\", "asdf.conf")

    # client.Download("d1/uploadTest26/", "C:\\Users\\swmai\\Desktop\\swm\\minio5")
    # client.Download("d1/uploadTest26", "C:\\Users\\swmai\\Desktop\\swm\\minio4")
    # client.Download("d1/uploadTest26/", "C:\\Users\\swmai\\Desktop\\swm\\minio3\\")
    # client.Download("d1/uploadTest26", "C:\\Users\\swmai\\Desktop\\swm\\minio2\\")

    # client.DownloadAsync("d1/uploadTest26/config.conf", "C:\\Users\\swmai\\Desktop\\swm\\minio5")
    # client.DownloadAsync("d1/uploadTest26/config.conf", "C:\\Users\\swmai\\Desktop\\swm\\minio4", "asdf.conf")
    # client.DownloadAsync("d1/uploadTest26/config.conf", "C:\\Users\\swmai\\Desktop\\swm\\minio3\\")
    # client.DownloadAsync("d1/uploadTest26/config.conf", "C:\\Users\\swmai\\Desktop\\swm\\minio2\\", "asdf.conf")

    # client.DownloadAsync("d1/uploadTest27/", "C:\\Users\\swmai\\Desktop\\swm\\minio5")
    # client.DownloadAsync("d1/uploadTest27", "C:\\Users\\swmai\\Desktop\\swm\\minio4")
    # client.DownloadAsync("d1/uploadTest27/", "C:\\Users\\swmai\\Desktop\\swm\\minio3\\")
    # client.DownloadAsync("d1/uploadTest27", "C:\\Users\\swmai\\Desktop\\swm\\minio2\\")
    # while True:
    #     print("running check")
    #     if mp1.IsRunning() and mp2.IsRunning():
    #         break

    # client.Remove("d1/uploadTest1/")
    # client.Remove("d1/uploadTest2")
    # client.Remove("d1/uploadTest23/config.conf")
    # client.Remove("d1/uploadTest23/")
    # client.RemoveAsync("d1/uploadTest26/config.conf")
    # client.RemoveAsync("d1/uploadTest26")
    # client.RemoveAsync("d1/uploadTest26/test.conf")
    # client.RemoveAsync("d1/uploadTest24/")
    # client.RemoveAsync("d1/uploadTest25")
    # while True:
    #     print("running check")
    #     if mp1.IsRunning() and mp2.IsRunning():
    #         break

    # client.Remove("d1/uploadTest21")

    client.Disconnect()


if __name__ == '__main__':
    main()
