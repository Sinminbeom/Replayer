import os

from minio import Minio

from LibUtils.FileLists import FileLists
from Log.cLogger import cLogger, E_LOG
from MultiProcess.ObjectStorageProCallable import minioUploader, minioProcess, minioDownloader, minioRemover
from MultiProcess.cMultiProcessRunner import cMultiProcessRunner
from ObjectStrage.Minio.api.progress import Progress
from ObjectStrage.Minio.cMinioException import *
from ObjectStrage.Minio.cMinioFS import cMinioFS
from ObjectStrage.Minio.cTransferDto import cTransferDto
from ObjectStrage.abObjectStorage import abObjectStorage, DEFAULT_PROCESS_SIZE
from ObjectStrage.cObjectType import ObjectType

DEFAULT_MP_SIZE = 5


class cMinioStorage(abObjectStorage):

    def __init__(self, _connectionInfoDto):
        super().__init__(ObjectType.MINIO)
        self.connectionInfoDto = _connectionInfoDto

    def Connect(self):
        addr = self.connectionInfoDto.addr
        port = self.connectionInfoDto.port
        access_key = self.connectionInfoDto.access_key
        secret_key = self.connectionInfoDto.secret_key
        self.bucket = self.connectionInfoDto.bucket

        self.objStorage = Minio(str(addr) + ':' + str(port), access_key=access_key, secret_key=secret_key, secure=False)
        return self.objStorage

    def Disconnect(self):
        super().Disconnect()

    def Upload(self, localPath, objectPath, targetFilename=None, isProgress=False):
        if os.path.isdir(localPath):
            self.UploadFolder(localPath, objectPath, isProgress)
            return

        self.UploadFile(localPath, objectPath, targetFilename, isProgress)

    def UploadAsync(self, localPath, objectPath, targetFilename=None, isProgress=False):
        if os.path.isdir(localPath):
            return self.UploadFolderAsync(localPath, objectPath, isProgress)

        return self.UploadFileAsync(localPath, objectPath, targetFilename, isProgress)

    def Download(self, objectPath, localPath, targetFilename=None):
        if self.IsDir(objectPath) == abObjectStorage.E_FILE_TYPE.NONE:
            raise Exception("cMinioStorage :: Download  ", abObjectStorage.E_FILE_TYPE.NONE)
        elif self.IsDir(objectPath) == abObjectStorage.E_FILE_TYPE.DIR:
            self.DownloadFolder(objectPath, localPath)
            return

        self.DownloadFile(objectPath, localPath, targetFilename)

    def DownloadAsync(self, objectPath, localPath, targetFilename=None):
        if self.IsDir(objectPath) == abObjectStorage.E_FILE_TYPE.NONE:
            raise Exception("cMinioStorage :: Download  ", abObjectStorage.E_FILE_TYPE.NONE)
        elif self.IsDir(objectPath) == abObjectStorage.E_FILE_TYPE.DIR:
            return self.DownloadFolderAsync(objectPath, localPath)

        return self.DownloadFileAsync(objectPath, localPath, targetFilename)

    def Remove(self, objectPath):
        if self.IsDir(objectPath) == abObjectStorage.E_FILE_TYPE.NONE:
            raise Exception("cMinioStorage :: Remove  ", abObjectStorage.E_FILE_TYPE.NONE)
        elif self.IsDir(objectPath) == abObjectStorage.E_FILE_TYPE.DIR:
            self.RemoveFolder(objectPath)
            return

        self.RemoveFile(objectPath)

    def RemoveAsync(self, objectPath):
        if self.IsDir(objectPath) == abObjectStorage.E_FILE_TYPE.NONE:
            raise Exception("cMinioStorage :: Remove  ", abObjectStorage.E_FILE_TYPE.NONE)
        elif self.IsDir(objectPath) == abObjectStorage.E_FILE_TYPE.DIR:
            return self.RemoveFolderAsync(objectPath)

        return self.RemoveFileAsync(objectPath)

    def SetTransferDto(self, _transferDto):
        self.transferDto = _transferDto

    def GetTransferDto(self):
        return self.transferDto

    def ChangeBucket(self, newBucket):
        if not self.ExistBucket(newBucket):
            raise Exception(COMMON + BUCKET_NOT_EXIST_ERROR)
        self.bucket = str(newBucket)

    def GetBucket(self):
        return self.bucket

    def GetBucketList(self):
        return self.objStorage.list_buckets()

    def ExistBucket(self, bucket):
        return self.objStorage.bucket_exists(bucket)

    def MakeBucket(self, bucket, region=None, object_lock=False):
        if self.ExistBucket(bucket):
            return

        self.objStorage.make_bucket(bucket, region, object_lock)

    def RemoveBucket(self, bucket):
        if not self.ExistBucket(bucket):
            raise Exception(COMMON + BUCKET_NOT_EXIST_ERROR)

        self.objStorage.remove_bucket(bucket)

    def GetFileInfo(self, objectPath):
        minioFiles = self.objStorage.list_objects(self.bucket, objectPath)

        for minioFile in minioFiles:
            if objectPath == minioFile.object_name:
                return cMinioFS(minioFile)

        raise FileInfoException(COMMON + INVALID_FILE_PATH_ERROR)

    def GetFileInfoList(self, objectPath=None, isRecursive=False):
        try:
            minioFiles = []
            files = self.objStorage.list_objects(self.bucket,
                                                 prefix=self.checkObjectPath(objectPath),
                                                 recursive=isRecursive)

            o = 10

            for minioFile in files:
                print(minioFile.object_name, minioFile.size)
                minioFiles.append(cMinioFS(minioFile))

            return minioFiles

        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON, INVALID_FILE_PATH_ERROR)
            raise Exception()

    def UploadFile(self, localPath, objectPath, targetFilename=None, isProgress=False):
        try:
            localFilePath = FileLists.makeCorrectFileRoute(localPath)
            objectPath = self.checkObjectPath(objectPath)

            originalFilename = self.getFileName(localFilePath)
            if targetFilename is None:
                targetFilename = originalFilename

            if isProgress:
                self.objStorage.fput_object(self.bucket,
                                            self.checkObjectPath(objectPath) + targetFilename,
                                            localFilePath,
                                            progress=Progress())
                return

            self.objStorage.fput_object(self.bucket,
                                        self.checkObjectPath(objectPath) + targetFilename,
                                        localFilePath)
            # cLogger.instance().Print(E_LOG.INFO, "Upload Complete >> " + originalFilename)
        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FILE_UPLOAD_ERROR)
            raise Exception()

    def UploadFileAsync(self, localPath, objectPath, targetFilename=None, isProgress=False):
        try:
            originalFilename = self.getFileName(FileLists.makeCorrectFileRoute(localPath))
            if targetFilename is None:
                targetFilename = originalFilename

            transferDto = [
                cTransferDto(self.checkObjectPath(objectPath), localPath, originalFilename, targetFilename, isProgress)]
            mp = cMultiProcessRunner(1)

            mp.Append(
                minioUploader(
                    "FileUploader", True, cMinioStorage(self.connectionInfoDto), transferDto, minioProcess.CallBack
                )
            )

        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FILE_UPLOAD_ERROR)
            raise Exception()

    def __SetUploadFolder(self, localPath, objectPath, isProgress=False):
        originalFilePath = FileLists.makeCorrectFolderRoute(localPath)

        transferFileList = []
        for file in FileLists(originalFilePath).getFiles():
            targetObjectPath = self.checkObjectPath(objectPath) + file[0].replace(originalFilePath, "").replace("\\",
                                                                                                                "/")
            transferFileList.append(cTransferDto(targetObjectPath, file[0], file[1], file[1], isProgress))

        if len(transferFileList) < DEFAULT_PROCESS_SIZE: return [transferFileList]

        jumpSize = len(transferFileList) // DEFAULT_PROCESS_SIZE
        return [transferFileList[i:i + jumpSize]
                for i in range(0, len(transferFileList), jumpSize)]

    def UploadFolder(self, localPath, objectPath, isProgress=False):
        try:
            for transferFile in self.__SetUploadFolder(localPath, objectPath, isProgress):
                for file in transferFile:
                    self.UploadFile(*file.GetUploadInfo())
        except Exception as e:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FOLDER_UPLOAD_ERROR)
            raise Exception()

    def UploadFolderAsync(self, localPath, objectPath, isProgress=False):
        try:
            for transferFile in self.__SetUploadFolder(localPath, objectPath, isProgress):
                mp = cMultiProcessRunner(DEFAULT_PROCESS_SIZE)
                mp.Append(
                    minioUploader(
                        "FiilUploader", True, cMinioStorage(self.connectionInfoDto), transferFile, minioProcess.CallBack
                    )
                )

        except Exception as e:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FOLDER_UPLOAD_ERROR)
            raise Exception()

    def DownloadFile(self, objectPath, localPath, targetFilename=None, ):
        try:
            minioFile = self.GetFileInfo(objectPath)

            if targetFilename is None:
                targetFilename = minioFile.fileName()
            self.objStorage.fget_object()
            self.objStorage.fget_object(minioFile.bucket(),
                                        self.checkObjectPath(minioFile.path()) + minioFile.fileName(),
                                        FileLists.makeCorrectFolderRoute(localPath) + targetFilename)

            # cLogger.instance().Print("Download Complete >> " + minioFile.fileName())
        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON, MINIO_FOLDER_DOWNLOAD_ERROR)
            raise Exception()

    def DownloadFileAsync(self, objectPath, localPath, targetFilename=None, ):
        try:
            minioFile = self.GetFileInfo(objectPath)

            if targetFilename is None:
                targetFilename = minioFile.fileName()

            transferDto = [cTransferDto(minioFile.path(), localPath, minioFile.fileName(), targetFilename, None)]
            mp = cMultiProcessRunner(1)
            mp.Append(
                minioDownloader(
                    "FileDownloader", True, cMinioStorage(self.connectionInfoDto), transferDto, minioProcess.CallBack
                )
            )

        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FOLDER_DOWNLOAD_ERROR)
            raise Exception()

    def __SetDownloadFolder(self, objectPath, localPath):
        transferFileList = []
        for file in self.GetFileInfoList(objectPath, True):
            targetLocalPath = \
                FileLists.makeCorrectFolderRoute(
                    FileLists.makeCorrectFolderRoute(localPath) + file.path().replace(objectPath, ""))
            transferFileList.append(cTransferDto(file.path(), targetLocalPath, file.fileName(), file.fileName(), False))

        if len(transferFileList) < DEFAULT_PROCESS_SIZE: return [transferFileList]

        jumpSize = len(transferFileList) // DEFAULT_PROCESS_SIZE
        return [transferFileList[i:i + jumpSize]
                for i in range(0, len(transferFileList), jumpSize)]

    def DownloadFolder(self, objectPath, localPath):
        try:
            for transferFile in self.__SetDownloadFolder(objectPath, localPath):
                for file in transferFile:
                    self.DownloadFile(*file.GetDownloadInfo())

        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FOLDER_DOWNLOAD_ERROR)
            raise Exception()

    def DownloadFolderAsync(self, objectPath, localPath):
        try:
            for transferFile in self.__SetDownloadFolder(objectPath, localPath):
                mp = cMultiProcessRunner(DEFAULT_PROCESS_SIZE)
                mp.Append(
                    minioDownloader(
                        "FiilDownloader", True, cMinioStorage(self.connectionInfoDto), transferFile,
                        minioProcess.CallBack
                    )
                )

        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FOLDER_DOWNLOAD_ERROR)
            raise Exception()

    def RemoveFile(self, objectPath):
        try:
            self.objStorage.remove_object(self.bucket, objectPath)
            cLogger.instance().Print("Download Complete >> " + objectPath)

        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FILE_REMOVE_ERROR)
            raise Exception()

    def RemoveFileAsync(self, objectPath):
        try:
            self.objStorage.remove_object(self.bucket, objectPath)

            transferDto = [cTransferDto(objectPath, None, None, None, None)]
            mp = cMultiProcessRunner(1)
            mp.Append(
                minioRemover(
                    "FileRemover", True, cMinioStorage(self.connectionInfoDto), transferDto, minioProcess.CallBack
                )
            )

        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FILE_REMOVE_ERROR)
            raise Exception()

    def __SetRemoveFolder(self, objectPath):
        removeFileList = []
        for file in self.GetFileInfoList(self.checkObjectPath(self.checkObjectPath(objectPath)), True):
            removeFileList.append(cTransferDto(file.path(), None, file.fileName(), None, None))

        if len(removeFileList) < DEFAULT_PROCESS_SIZE: return [removeFileList]

        jumpSize = len(removeFileList) // DEFAULT_PROCESS_SIZE
        return [removeFileList[i:i + jumpSize]
                for i in range(0, len(removeFileList), jumpSize)]

    def RemoveFolder(self, objectPath):
        try:
            for removeFile in self.__SetRemoveFolder(objectPath):
                for file in removeFile:
                    self.RemoveFile(file.GetRemoveInfo())
            cLogger.instance().Print("Remove Complete")
        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON, MINIO_FILE_REMOVE_ERROR)
            raise Exception()

    def RemoveFolderAsync(self, objectPath):
        try:
            for removeFile in self.__SetRemoveFolder(objectPath):
                mp = cMultiProcessRunner(DEFAULT_PROCESS_SIZE)
                mp.Append(
                    minioRemover(
                        "FiilRemover", True, cMinioStorage(self.connectionInfoDto), removeFile, minioProcess.CallBack
                    )
                )

        except Exception:
            cLogger.instance().Print(E_LOG.EXCEPTION, COMMON + MINIO_FILE_REMOVE_ERROR)
            raise Exception()

    def IsDir(self, objectPath):
        minioFiles = self.objStorage.list_objects(self.bucket, objectPath)

        for minioFile in minioFiles:
            if not minioFile.object_name.startswith(objectPath) or abs(
                    len(minioFile.object_name) - len(objectPath)) > 1:
                if objectPath[-1] == "/":
                    return abObjectStorage.E_FILE_TYPE.DIR
                continue

            if minioFile.is_dir:
                return abObjectStorage.E_FILE_TYPE.DIR
            else:
                return abObjectStorage.E_FILE_TYPE.FILE

        return abObjectStorage.E_FILE_TYPE.NONE


def main2():
    cm = cMinioStorage(r"C:\D\project\swm\infra-glue-python-template\config\config.conf")
    cm.Connect()
    a = cm.IsDir("d1/uploadTest26")
    b = cm.IsDir("d1/uploadTest26/")

    pass


# def main():
#     cm = cMinioStorage(r"C:\D\project\swm\infra-glue-python-template\config\config.conf")
#     cm.Connect()
#     # print(FileLists.makeCorrectRoute(r"C:/D/project/swm/infra-glue-python-template/config"))
#     # cm.UploadFolder(r"C:\Users\swmai\Desktop\swm\minio", "d1/uploadTest16")
#     # cm.UploadFile(r"C:\Users\swmai\Desktop\swm\minio\config.conf", "d1/uploadTest15")
#     # cm.DownloadFile("d1/uploadTest15/config.conf", "C:\\Users\\swmai\\Desktop\\swm\\minio\\")
#     # cm.DownloadFolder("d1/uploadTest16/", "C:\\Users\\swmai\\Desktop\\swm\\minio2\\")
#     # cm.RemoveFolder("d1/uploadTest16")
#     cm.Disconnect()

def main3():
    a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    print([a[i:i + 4] for i in range(0, len(a), 4)])


if __name__ == "__main__":
    main3()
