from enum import Enum

from ObjectStrage.Minio.abConnectionInfo import ConnectionInfo
from LibUtils.ConfigUtils import ConfigUtils


class cMinioConnectionInfo(ConnectionInfo):
    class ConfigType(Enum):
        SECTION = "minio"
        ADDR = "address"
        PORT = "port"
        AKEY = 'accesskey'
        SKEY = 'secretkey'
        BUCKET = "bucket"

    def __init__(self, _configPath):
        super(cMinioConnectionInfo, self).__init__(_configPath)
        self.options = ConfigUtils.configParser(configFile=_configPath)
        self.addr = self.options.get(
            (cMinioConnectionInfo.ConfigType.SECTION.value, cMinioConnectionInfo.ConfigType.ADDR.value))
        self.port = self.options.get(
            (cMinioConnectionInfo.ConfigType.SECTION.value, cMinioConnectionInfo.ConfigType.PORT.value))
        self.access_key = self.options.get(
            (cMinioConnectionInfo.ConfigType.SECTION.value, cMinioConnectionInfo.ConfigType.AKEY.value))
        self.secret_key = self.options.get(
            (cMinioConnectionInfo.ConfigType.SECTION.value, cMinioConnectionInfo.ConfigType.SKEY.value))
        self.bucket = self.options.get(
            (cMinioConnectionInfo.ConfigType.SECTION.value, cMinioConnectionInfo.ConfigType.BUCKET.value))
