class IObjectStorage:

    def SetConnectionInfo(self, _connectionInfo):
        pass

    def Connect(self):
        pass

    def Disconnect(self):
        pass

    def GetObject(self):
        pass

    def GetFileInfo(self, filePath):
        pass

    def GetFileInfoList(self, objectPath, isRecursive=False):
        pass

    def Upload(self, localPath, objectPath, targetFilename=None, isProgress=False):
        pass

    def UploadAsync(self, localPath, objectPath, targetFilename=None, isProgress=False):
        pass

    def Download(self, objectPath, localPath, targetFilename=None):
        pass

    def DownloadAsync(self, objectPath, localPath, targetFilename=None):
        pass

    def Remove(self, objectPath):
        pass

    def RemoveAsync(self, objectPath):
        pass

    def UploadFile(self, localPath, objectPath, targetFilename=None, isProgress=False):
        pass

    def UploadFileAsync(self, localPath, objectPath, targetFilename=None, isProgress=False):
        pass

    def UploadFolder(self, localPath, objectPath, isProgress=False):
        pass

    def UploadFolderAsync(self, localPath, objectPath, isProgress=False):
        pass

    def DownloadFile(self, objectPath, localPath, targetFilename=None):
        pass

    def DownloadFileAsync(self, objectPath, localPath, targetFilename=None):
        pass

    def DownloadFolder(self, objectPath, localPath):
        pass

    def DownloadFolderAsync(self, objectPath, localPath):
        pass

    def RemoveFile(self, objectPath):
        pass

    def RemoveFileAsync(self, objectPath):
        pass

    def RemoveFolder(self, objectPath):
        pass

    def RemoveFolderAsync(self, objectPath):
        pass

    def IsDir(self, objectPath):
        pass
