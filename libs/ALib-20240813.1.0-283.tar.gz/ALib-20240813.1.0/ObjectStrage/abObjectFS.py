from ObjectStrage.IObjectFS import IObjectFS


class abObjectFS(IObjectFS):
    def __init__(self, _objectType, _objectStorageFile):
        self.objectType = _objectType
        self.objectStorageFile = _objectStorageFile

    def GetFile(self):
        return self.objectStorageFile

    def FileName(self):
        pass

    def Path(self):
        pass

    def Size(self):
        pass

    def LastModified(self):
        pass

    def IsDir(self):
        pass
