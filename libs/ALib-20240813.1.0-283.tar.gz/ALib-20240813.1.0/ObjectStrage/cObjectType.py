from enum import Enum


class ObjectType(Enum):
    MINIO = "minio"
    HADOOP = "hadoop"
