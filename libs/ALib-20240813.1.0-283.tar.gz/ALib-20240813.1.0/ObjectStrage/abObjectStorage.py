import os
import platform
from enum import Enum
from pathlib import Path

from MultiProcess.cMultiProcessRunner import cMultiProcessRunner
from ObjectStrage.iObjectStorage import IObjectStorage

WINDOWS_PATH = "\\"
LINUX_PATH = "/"
DEFAULT_PROCESS_SIZE = 8

class OS(Enum):
    WINDOWS = "Windows"
    LINUX = "Linux"
    MACOS = "Darwin"


class abObjectStorage(IObjectStorage):

    class E_FILE_TYPE(Enum):
        NONE = 0
        FILE = 1
        DIR = 2

    def __init__(self, _objectType):
        self.objectType = _objectType
        self.objStorage = None

    def Connect(self):
        pass

    def Disconnect(self):
        self.objStorage = None
        pass

    def getObject(self):
        return self.objStorage

    def GetFileInfo(self, filePath):
        pass

    def GetFileInfoList(self, objectPath, isRecursive=False):
        pass

    def Upload(self, localPath, objectPath, targetFilename=None, isProgress=False):
        pass

    def UploadAsync(self, localPath, objectPath, targetFilename=None, isProgress=False):
        pass

    def Download(self, objectPath, localPath, targetFilename=None):
        pass

    def DownloadAsync(self, objectPath, localPath, targetFilename=None):
        pass

    def Remove(self, objectPath):
        pass

    def RemoveAsync(self, objectPath):
        pass

    def UploadFile(self, localPath, objectPath, targetFilename=None, isProgress=False):
        pass

    def UploadFileAsync(self, localPath, objectPath, targetFilename=None, isProgress=False):
        pass

    def UploadFolder(self, localPath, objectPath, isProgress=False):
        pass

    def UploadFolderAsync(self, localPath, objectPath, isProgress=False):
        pass

    def DownloadFile(self, objectPath, localPath, targetFilename=None):
        pass

    def DownloadFileAsync(self, objectPath, localPath, targetFilename=None):
        pass

    def DownloadFolder(self, objectPath, localPath):
        pass

    def DownloadFolderAsync(self, objectPath, localPath):
        pass

    def RemoveFile(self, objectPath):
        pass

    def RemoveFileAsync(self, objectPath):
        pass

    def RemoveFolder(self, objectPath):
        pass

    def RemoveFolderAsync(self, objectPath):
        pass

    def IsDir(self, objectPath):
        pass


    def checkObjectPath(self, path):
        if path is None: return None
        li = list(path)
        path_file = path
        if li[-1] != "/":
            path_file = path + '/'
        return path_file

    def makeLocalPath (self, path):
        return os.path.join(os.path.normpath(path), "")

    def getFileName(self, path):
        if platform.system() == OS.WINDOWS.value:
            return path.split(WINDOWS_PATH)[-1]
        return path.split(LINUX_PATH)[-1]
