from ObjectStrage.Minio.cMinioStorage import cMinioStorage


class abObjectStorageManager:

    def __init__(self, _configFile):
        pass

    def GetObject(self):
        return self.objectStorage

    def Connect(self):
        self.objectStorage.Connect()

    def Disconnect(self):
        self.objectStorage.Disconnect()

    def GetFileList(self, objectPath):
        pass

    def Upload(self, objectPath, localPath, isProgress=False):
        pass

    def Download(self, objectPath, localPath):
        pass

    def Remove(self, objectPath):
        pass

    def UploadAsync(self, minioPath, localPath, isProgress=False):
        pass

    def DownloadAsync(self, minioPath, localPath):
        pass

    def RemoveAsync(self, minioPath):
        pass
    pass
