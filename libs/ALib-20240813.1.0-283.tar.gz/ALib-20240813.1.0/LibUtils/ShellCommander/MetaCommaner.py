from enum import Enum

from PCap.Reader.IENUM import IENUM
from Propertys.IProperty import IProperty


class ShellTypeProperty(IProperty):

    def __init__(self , shell_type , shell_option):
        self._shellType = shell_type
        self._shellOption = shell_option
        pass
    def GetShellType(self):
        return self._shellType

    def GetShellOption(self):
        return self._shellOption

    def toString(self):
        return f"""{self._shellType} : {self._shellOption}"""





class E_SHELL_TYPE(IENUM):
    BASH = "bash"
    CMD = "cmd.exe"

    metaTb = {
        BASH : ShellTypeProperty(BASH , "-e") ,
        CMD : ShellTypeProperty(CMD , "/e")
         }

    @staticmethod
    def GetShellType(shell_type):
        return E_SHELL_TYPE.metaTb[shell_type]


    @staticmethod
    def GetShellTypeWithOS():
        import platform
        os_type = platform.system()
        shell_type = E_SHELL_TYPE.BASH

        if os_type == 'Windows':
            shell_type = E_SHELL_TYPE.CMD

        return E_SHELL_TYPE.metaTb[shell_type]


    # metaTb[BASH.value] = ShellTypeProperty(BASH , "-c")
    # metaTb[CMD.value] = ShellTypeProperty(CMD , "/c")



class E_MACRO_TYPE(Enum):
    COMMAND_END = "|^^| COMMAND END |^^|"
    PROCESS_SHUTDOWN = "|^^| PROCESS_SHUTDOWN |^^|"
    #
    # COMMAND_END = "## COMMAND END ##"
    # PROCESS_SHUTDOWN = "## PROCESS_SHUTDOWN ##"

    def GetMacroType(macro_str):  # type: (str) -> E_MACRO_TYPE_VALUE
        for macro_type in E_MACRO_TYPE:
            if macro_type.value == macro_str:
                return macro_type
        return None

    def IsCommandEnd(macro_str):

        nm = macro_str.replace("\"", "").replace("\n", "")

        if E_MACRO_TYPE.COMMAND_END.value == nm:
            # print(f" TRUE IsCommandEnd : {nm} == {E_MACRO_TYPE.COMMAND_END.value}")
            return True

        # print(f" FAL IsCommandEnd : {nm} <> {E_MACRO_TYPE.COMMAND_END.value}")
        return False

    def IsShutdown(macro_str):

        nm = macro_str.replace("\"", "").replace("\n", "")

        if E_MACRO_TYPE.PROCESS_SHUTDOWN.value == nm:
            # print(f" TRUE IsShutdown : {nm} == {E_MACRO_TYPE.PROCESS_SHUTDOWN.value}")
            return True

        # print(f" FAL IsShutdown : {nm} <> {E_MACRO_TYPE.PROCESS_SHUTDOWN.value}")
        return False

    def CommandToMacroCommand(command):

        # import platform
        # os_type = platform.system()
        # if os_type == 'Windows':
        #     return f"""{command}\necho {E_MACRO_TYPE.COMMAND_END.value}\n"""

        return f"""{command}\necho "{E_MACRO_TYPE.COMMAND_END.value}"\n"""


    @staticmethod
    def ShutdownToMacroCommand():

        # import platform
        # os_type = platform.system()
        # if os_type == 'Windows':
        #     return f"""echo {E_MACRO_TYPE.PROCESS_SHUTDOWN.value}\n"""

        return f"""echo "{E_MACRO_TYPE.PROCESS_SHUTDOWN.value}"\n"""





def main():

    p = E_SHELL_TYPE.GetShellType(E_SHELL_TYPE.BASH)
    print(p.toString())

    pro = E_SHELL_TYPE.metaTb[E_SHELL_TYPE.BASH]
    # pro = metaTb[E_SHELL_TYPE.BASH]
    print(pro.toString())  # 올바르게 "-c" 출력을 기대

    # print( E_SHELL_TYPE.metaTb[E_SHELL_TYPE.BASH] )

    # d1=E_MACRO_TYPE.GetMacroType("## PROCESS_SHUTDOWN ##")
    # d2=E_MACRO_TYPE.GetMacroType("## COMMAND END ##")
    #
    #
    # print(E_SHELL_TYPE.BASH)
    # print(E_SHELL_TYPE.BASH.value)
    #
    #
    # print(d1)
    # print(d2)


    pass

#
#
# if __name__ == '__main__':
#     main()
#
