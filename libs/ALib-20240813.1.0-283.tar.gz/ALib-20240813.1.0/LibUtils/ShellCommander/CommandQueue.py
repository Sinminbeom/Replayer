

class CommandQueue:
    def __init__(self):
        import queue
        self._queue = queue.Queue()
        import threading
        self._lock = threading.Lock()

    def AddCommand(self , command):
        with self._lock:
            self._queue.put(command)

    def Pop(self):
        return self._queue.get()

    def SafePop(self):
        with self._lock:
            if self.IsEmpty():
                # print("SafePop Enpty")
                return None

            print(f"SafePop get() : {self.peek()}")
            return self._queue.get()

    def IsEmpty(self):
        return self._queue.empty()

    def Clear(self):
        import queue
        with self._lock:
            self._queue = queue.Queue()

    def peek(self):
        return self._queue.queue[0]

    def __len__(self):
        return len(self._queue.queue)

    def __del__(self):
        self.Clear()



    pass

#
#
# def main():
#
#     q=CommandQueue()
#
#     q.AddCommand("command1")
#     q.AddCommand("command2")
#
#     print(q.SafePop())
#     print(q.SafePop())
#     print(q.IsEmpty())
#
#     pass
#
# if __name__ == '__main__':
#     main()