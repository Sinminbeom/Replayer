
from ThreadUtils.abThread import abThread


class ShellCommanderReceiver(abThread):
    def __init__(self , shell_commander , call_back):
        abThread.__init__(self)

        self._shell_commander = shell_commander
        self._call_back = call_back
    def Action(self):
        from LibUtils.ShellCommander.MetaCommaner import E_MACRO_TYPE

        process = self._shell_commander.GetProcess()

        ## 인젝션 있을때 까지 대기 하자...................

        self._shell_commander.NextCommandInjectionWait()

        while True:

            output = process.stdout.readline()

            if E_MACRO_TYPE.IsCommandEnd( output.strip() ):
                ## 여도 인젝션 있을때 까지 대기 하자...................
                print("Next Command Injection wait begin  ========= ")
                self._call_back(output)
                self._shell_commander.NextCommandInjectionWait()
                print("Next Command Injection wait end ")
            elif E_MACRO_TYPE.IsShutdown( output ):
                print("Shutdown ShellCommander Process")
                self.Stop()
                return
            else:
                self._call_back(output)

class ShellCommander:


    def __init__(self , receive_callback ):
        from LibUtils.ShellCommander.CommandQueue import CommandQueue

        self._process = None
        self._receive_callback = receive_callback
        self._command_queue = CommandQueue()
        self._receiver = ShellCommanderReceiver(self , self._receive_callback)


        self.__Init()


    def Run(self):
        self.__start()
        return self


    def __Init(self):
        import subprocess
        from LibUtils.ShellCommander.MetaCommaner import E_SHELL_TYPE


        shellProperty = E_SHELL_TYPE.GetShellTypeWithOS()


        self._process = subprocess.Popen([shellProperty.GetShellType() , shellProperty.GetShellOption() ],
                                         stdin=subprocess.PIPE,
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE,
                                   text=True)


        pass
    def __start(self):
        self._receiver.Start()

    def GetProcess(self):
        return self._process

    def GetCommandQueue(self):
        return self._command_queue

    def GetNextCommand(self):
        return self._command_queue.SafePop()


    def _CommandToMacroCommand(self , command):

        from LibUtils.ShellCommander.MetaCommaner import E_MACRO_TYPE


        mc = E_MACRO_TYPE.CommandToMacroCommand(command)

        return mc

    def NextCommandInjectionWait(self):
        import time

        command = None
        while command is None:
            command = self.GetNextCommand()
            if command is None:
                time.sleep(0.01)
                continue
            else:
                break

        self._process.stdin.write( self._CommandToMacroCommand(command) )
        self._process.stdin.flush()

        pass

    def AddCommand(self , command):
        self._command_queue.AddCommand(command)

    def AddShutdownCommand(self):
        from LibUtils.ShellCommander.MetaCommaner import E_MACRO_TYPE
        self._command_queue.AddCommand(E_MACRO_TYPE.ShutdownToMacroCommand())


def receiveHandler(output_message):

    print(f"OutMes : {output_message}")

    pass

def main():
    from LibUtils.ShellCommander.MetaCommaner import E_SHELL_TYPE
    import time
    print(E_SHELL_TYPE.BASH)

    shellCommander = ShellCommander(receiveHandler).Run()

    time.sleep(1)
    shellCommander.AddCommand("echo Hello, World!")

    time.sleep(1)
    shellCommander.AddCommand("dir/w")

    time.sleep(3)
    shellCommander.AddCommand("dir/w")

    time.sleep(1)
    shellCommander.AddCommand("dir/w")


    shellCommander.AddShutdownCommand()

    # shellCommander.Run()



    while True:
        time.sleep(1)
        pass





    # print( str( ShellCommander.E_SHELL_TYPE.BASH.value ))
    # print(ShellCommander.E_SHELL_TYPE.BASH.value  )
    pass


def main2():
    command = 'echo Hello, World!'
    shell_type = 'cmd.exe'
    command_option = '/c'  # 명령 실행 옵션

    import subprocess
    # 명령 배열이 올바르게 구성되었습니다: 'cmd.exe', '/c', '실제 명령'
    p = subprocess.Popen([shell_type, command_option, command],
                         stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE,
                         text=True)

    # 결과를 한 줄 읽어 출력
    output = p.stdout.readline()
    print(output)


    pass
#
# if __name__ == '__main__':
#     main()
#     # main2()
#
#
#

