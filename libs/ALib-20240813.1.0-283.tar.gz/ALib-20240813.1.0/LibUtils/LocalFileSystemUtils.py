import os
from typing import List

from Log.cLogger import cLogger, E_LOG


class LocalFileSystemUtils:

    @staticmethod
    def mkdir(_dst_path):
        ## Local File System : Make Directory Method

        try:
            os.mkdir(_dst_path)
        except FileExistsError:
            raise FileExistsError(f"'{_dst_path}' Is Already Exist")

    @staticmethod
    def isDir(_dst_path) -> bool:
        if not os.path.exists(_dst_path):
            raise FileNotFoundError(f"'{_dst_path}' Is Not Exist")

        return os.path.isdir(_dst_path)


    @staticmethod
    def getContent(_dst_path) -> List:
        ## Local File System : Get Directory Info

        try:
            contents = []
            for item in os.listdir(_dst_path):
                contents.append(os.path.join(_dst_path, item))
            return contents

        except FileNotFoundError:
            raise FileNotFoundError(f"'{_dst_path}' Is Not Exist")
        except PermissionError:
            raise PermissionError("You do not have access.")


    @staticmethod
    def getFileContent(_dst_path) -> List:
        ## Local File System : Get Directory Info
        try:
            contents = []
            for item in os.listdir(_dst_path):
                itemPath = os.path.join(_dst_path, item)
                if not LocalFileSystemUtils.isDir(itemPath):
                    contents.append(itemPath)
            return contents

        except FileNotFoundError:
            raise FileNotFoundError(f"'{_dst_path}' Is Not Exist")
        except PermissionError:
            raise PermissionError("You do not have access.")


if __name__ == '__main__':
    contents = LocalFileSystemUtils.getContent("C:\\Users\\swmai\\Desktop\\a20231018")
    print(contents)

    fileContents = LocalFileSystemUtils.getFileContent("C:\\Users\\swmai\\Desktop\\a20231018")
    print(fileContents)