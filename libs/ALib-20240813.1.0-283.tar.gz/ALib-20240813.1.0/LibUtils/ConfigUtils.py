import configparser

class ConfigUtils:

    @staticmethod
    def configParser(configFile):
        config = configparser.ConfigParser()
        config.read(configFile)

        options = {}
        for section in config.sections():
            for option in config.options(section):
                value = config.get(section, option)
                options[(section, option)] = value

        return options



def main():
    CONFIG_FILE = "D:\\project\\project_swm\\apollo\\code_third\\infra-glue-python-template\\config\\config.conf"

    options = ConfigUtils.configParser(CONFIG_FILE)





    print(options)

    pass

if __name__ == '__main__':
    main()