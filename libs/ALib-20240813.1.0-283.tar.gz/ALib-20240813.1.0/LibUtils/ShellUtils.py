import subprocess
from typing import Callable, Any


class ShellUtils:

    """
    shell=True
    시스템의 기본 쉘을 사용하여 명령어가 해석되고 실행됨.
    보안에 더 취약할 수 있다 -> 셸 인젝션 공격에 노출될 수 있음

    shell=False(기본값):
    셸을 거치지 않고, 명령어와 인자들이 배열 형태로 전달됨
    """

    def __init__(self, _commandStr, _shell=False):
        self.command = _commandStr if _shell else _commandStr.split(" ")
        self.shell = _shell
        self.process = None

    def __start(self):
        if self.process is None:
            self.process = subprocess.Popen(self.command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                            shell=self.shell, text=True)
        return self

    def __enter__(self):
        return self.__start()

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.process:
            self.process.terminate()
            self.process.wait()

    def Run(self):
        if self.process is None:
            self.__start()

        stdout_data, stderr_data = self.process.communicate()

        self.process.terminate()
        self.process.wait()
        self.process = None

        return stdout_data, stderr_data

    def RunReadLine(self):
        stdout_data, stderr_data = self.Run()

        return stdout_data.splitlines(), stderr_data.splitlines()


    def RunLive(self, _print=False, callback: Callable[[str], Any] = None):
        if self.process is None:
            self.__start()

        stdout_result = []
        stderr_result = []
        while True:
            output = self.process.stdout.readline()
            if output:
                if _print:
                    print("STDOUT:", output.strip())
                if callback:
                    callback(output)

                stdout_result.append(output)

            error = self.process.stderr.readline()
            if error:
                if _print and error.strip() != "":
                    print("STDERR:", error.strip())
                if callback:
                    callback(error)

                stderr_result.append(error)

            if output == '' and error == '' and self.process.poll() is not None:
                break

        self.process.terminate()
        self.process.wait()
        self.process = None

        return stdout_result, stderr_result




##################################################################################################
######################################### E X A M P L E ##########################################
##################################################################################################

def my_callback(msg):
    print("====================>", msg.strip())


if __name__ == '__main__':
    # with ShellUtils("apt update", _shell=True) as proc:
    #     stdout, stderr = proc.run()
    #     print(stdout, stderr)

    # stdout, stderr = ShellUtils("apt update", _shell=True).run()
    # print(stdout, stderr)

    # stdout, stderr = ShellUtils("apt update", _shell=True).runLive(_print=True)
    # stdout, stderr = ShellUtils("apt update", _shell=True).runLive(callback=my_callback)
    # stdout, stderr = ShellUtils("apt update").runLive(callback=my_callback)

    # stdout, stderr = ShellUtils("apt update").runLive(callback=lambda msg: my_callback(msg + "line" + "\n"))

    pass
