import hashlib
from enum import Enum


class HashAlgorithm(Enum):
    MD5 = 'MD5'
    SHA1 = 'SHA1'
    SHA224 = 'SHA224'
    SHA256 = 'SHA256'
    SHA384 = 'SHA384'
    SHA512 = 'SHA512'
    BLAKE2B = 'BLAKE2B'
    BLAKE2S = 'BLAKE2S'
    SHA3_224 = 'SHA3_224'
    SHA3_256 = 'SHA3_256'
    SHA3_384 = 'SHA3_384'
    SHA3_512 = 'SHA3_512'


class HashUtils:

    @staticmethod
    def encode(*targets, _algorithm: HashAlgorithm = HashAlgorithm.MD5):
        return HashUtils.__hash("".join([str(arg) for arg in targets]), _algorithm.value)

    @staticmethod
    def isEqual(hashValue, *targets, _algorithm: HashAlgorithm = HashAlgorithm.MD5):
        return hashValue == HashUtils.encode(*targets, _algorithm=_algorithm)

    @staticmethod
    def __hash(target_str, algorithm):
        # print(algorithm, HashAlgorithm.__members__)
        if algorithm in HashAlgorithm.__members__:
            hash_function = getattr(hashlib, algorithm.lower())
            return hash_function(target_str.encode()).hexdigest()
        else:
            raise ValueError("Unsupported hash algorithm")
