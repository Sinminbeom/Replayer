


class memoryChecker:



    def __init__(self):
        import psutil
        self._processUtil = psutil.Process()

        self._max_used_memory = 0

        pass


    def checkMemory(self) :
        p=self._processUtil
        rss = p.memory_info().rss / 2 ** 20  # Bytes to MB
        return rss

        pass

    def toString(self):
        rss = self.checkMemory()

        if self._max_used_memory < rss:
            self._max_used_memory = rss
            return f">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> TOP [ memory usage: {rss: 10.5f} MB"
        else:
            return f"[memory usage: {rss: 10.5f} MB"


    def println(self):
        print(self.toString())
        pass

    pass