from shapely import Polygon


class cGeoPolygon:

    def __init__(self, _polygon):
        self.polygon = _polygon

    def IsContain(self, _geopoint):
        return _geopoint.getShapelyPoint().within(self.polygon)


