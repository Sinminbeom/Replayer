import math

from shapely import Point

from Math.cPoint import cPoint


class cGeoPoint( cPoint ):

    # lat 위도 (  37.xxxxx )
    # lon 경도 ( 128.xxxxx )

    def __init__(self , _lat , _lon ):
        cPoint.__init__(self, _lon  ,  _lat )



    def getLat(self):
        return self.getY()

    def getLon(self):
        return self.getX()

    def getTuple(self):
        return (self.getLat() , self.getLon() )


    def getShapelyPoint(self):
        return Point( self.getLat() , self.getLon() )

    def toString(self):
        return f'_lat:{self.y} , _lon:{self.x}'








