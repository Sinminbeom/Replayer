import math

from haversine import haversine, Unit, inverse_haversine

from Geo.cGeoPoint import cGeoPoint
from Math.cMathUtils import cMathUtils


class cGeoUtils (object):


    def __init__(self):


        pass


    # @staticmethod
    # def haversine( point1 , point2 , unit=Unit.KILOMETERS, normalize=False):
    #     return haversine( point1 , point2 , unit , normalize )
    #     pass


    @staticmethod
    def getInversePoint( point1 , degree , distance ,unit=Unit.KILOMETERS ):
        return inverse_haversine(point1.getTuple() , distance ,  math.radians( degree )  , unit )
        pass

    @staticmethod
    def getInverseGeoPoint(point1, degree, distance, unit=Unit.KILOMETERS):
        point = inverse_haversine(point1.getTuple(), distance, math.radians(degree), unit)
        return cGeoPoint( point[0] , point[1] )
        pass

    @staticmethod
    def distance( point1 , point2 , unit=Unit.KILOMETERS):
        return haversine( point1.getTuple() , point2.getTuple() , unit , False )
        pass

    @staticmethod
    def calculate_bearing(lat1, lon1, lat2, lon2):
        # 위도와 경도를 라디안 단위로 변환
        lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])

        # 경도 차이
        dlon = lon2 - lon1

        # 베어링 계산
        y = math.sin(dlon) * math.cos(lat2)
        x = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(dlon)
        bearing = math.atan2(y, x)

        # 라디안을 도(degree) 단위로 변환
        bearing = math.degrees(bearing)

        # 결과를 0과 360 사이의 값으로 반환
        return (bearing + 360) % 360
    #
    # # 예제 위경도
    # lat1, lon1 = 37.5665, 126.9780  # 서울, 대한민국
    # lat2, lon2 = 35.6895, 139.6917  # 도쿄, 일본
    #
    # bearing = calculate_bearing(lat1, lon1, lat2, lon2)
    # print(f"두 위경도 사이의 방위각: {bearing} 도")

    @staticmethod
    def getAngle( geopoint1 , geopoint2 ):
        # return cGeoUtils.calculate_bearing( geopoint1.getLat() ,geopoint1.getLon() ,
        #                                     geopoint2.getLat() ,geopoint2.getLon() )
        return cGeoUtils.calculate_bearing(geopoint1.getLon(), geopoint1.getLat(),
                                    geopoint2.getLon(), geopoint2.getLat())

        # return cMathUtils.getAngle(geopoint1 , geopoint2)
        # pass





    pass



