import multiprocessing

from Exception.ExceptionType import ExceptionType


class ShardQueueContainer:
    def __init__(self, _queue_count: int = 10):
        self.container = [ShardQueue(queue_number) for queue_number in range(_queue_count)]

    def getContainer(self):
        return self.container

    def getContainerLength(self):
        return len(self.container)

    def getShardQueue(self, _queue_number):
        if _queue_number >= len(self.container):
            raise Exception(ExceptionType.LIST_OUT_OF_RANGE.value)
        return self.container[_queue_number]

    def push(self, _queue_number, data):
        self.container[_queue_number].push(data)

    def pop(self, _queue_number):
        return self.container[_queue_number].pop()


class ShardQueue:
    def __init__(self, _queue_number):
        manager = multiprocessing.Manager()
        self.qNum = _queue_number
        self.lock = manager.Lock()
        self.message_queue = manager.Queue()

    def push(self, data):
        with self.lock:
            self.message_queue.put(data)

    def pop(self):
        with self.lock:
            if not self.message_queue.empty():
                return self.message_queue.get(timeout=1)
            return None
