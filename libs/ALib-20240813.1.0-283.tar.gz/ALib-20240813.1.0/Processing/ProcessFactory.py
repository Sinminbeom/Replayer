import multiprocessing, math
from multiprocessing import Pool
from typing import List, Callable

from Exception.ExceptionType import ExceptionType
from ObjectStrage.Minio.cMinioStorage import cMinioStorage


class ProcessFactory:
    @staticmethod
    def MultiProcess(func: Callable, process_cnt: int, args: List):
        return MultiProcessContainer(func, process_cnt, args)

    @staticmethod
    def SingleProcess(func: Callable, *args):
        return ProcessContainer(func, *args)


class abMultiProcessor:
    def run(self, func=None, arg=None):
        pass

    def join(self):
        pass


class MultiProcessContainer(abMultiProcessor):
    def __init__(self, func, process_cnt, args):
        if not callable(func):
            raise Exception(ExceptionType.INVALID_ARGS.value, func)
        self.func = func
        self.pool = Pool(processes=self.pNumChecker(process_cnt))
        self.args = args

    def pNumChecker(self, process_cnt):
        if process_cnt <= 0 or not str(process_cnt).isdigit():
            raise Exception(ExceptionType.MULTI_PROCESSING_POOL_CREATE.value)

        cpu = math.ceil(multiprocessing.cpu_count() * 0.8)
        return min(cpu, process_cnt)

    def getPool(self):
        return self.pool

    def run(self, func=None):
        with self.pool as p:
            p.map(self.func, self.args)

    def join(self):
        self.pool.join()

class ProcessContainer(abMultiProcessor):
    def __init__(self, func, *args):
        if not callable(func):
            raise Exception(ExceptionType.INVALID_ARGS.value, func)
        self.process = multiprocessing.Process(target=func, args=(*args,))

    def run(self, func=None, arg=None):
        self.process.start()

    def join(self):
        self.process.join()
def main():
    pass

if __name__ == "__main__":
    main()

    # minio=cMinioStorage("../config/config.conf")
    #
    # minio.Connect()
    #
    # li=[][]
    #
    # @static
    # DownloadFile(minio, [ ] ){
    #     minio.Connect()
    #     minio.Download
    # }
    #
    # @static
    # DownloadFile(minio, [])
    # {
    #     minio.Connect()
    #     100개
    # }
    #
    # MultiProcessContainer(minio.DownloadFile ,li)
    # # ProcessFactory.MultiProcess(staticmethod , 8 ,  [ m1 , m2 , m3 ]  )




