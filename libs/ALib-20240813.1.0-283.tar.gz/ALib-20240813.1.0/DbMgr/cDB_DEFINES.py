
#
# if DEFINE.DEBUG_MODE == 1:
#     VERSION = "V_DEBUG_0.0.3"
# else:
#     VERSION = "V_0.0.3"
#

class E_DB:
    ORACLE = 0
    MYSQL = 1
    POSTGRESQL = 2
    IGNITE = 3

class I_DB__ALIAS:
    MY_TEST = 0
    ORA_TEST = 1
    POST_TEST = 2
    IGN_TEST = 3

    def __init__(self):
        pass
#
# class E_DB_ALIAS(I_DB__ALIAS):
#     MY_ = 0
#     ORA_TEST = 1


