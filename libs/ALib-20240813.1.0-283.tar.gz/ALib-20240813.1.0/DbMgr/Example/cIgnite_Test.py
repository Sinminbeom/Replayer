from pyignite.datatypes import MapObject, String, IntObject, prop_codes
from pyignite import Client, GenericObjectMeta
from pyignite.datatypes.cache_config import CacheAtomicityMode

from DbMgr.Example.cDB_MysqlTest import cDB_Info_Test
from DbMgr.Example.cDB_Test import E_DB_ALIAS
from DbMgr.cDBManager import cDBManager
from DbMgr.cDBProperty import cIgniteProperty
from DbMgr.cIgniteDBOBJ import cIgniteOBOBJ, eCacheOBJType
from TimeUtils.cStopWatch import cStopWatch


class Person(metaclass=GenericObjectMeta, schema={
    'first_name': String,
    'last_name': String,
    'age': IntObject
}):
    pass



def main5():
    sw = cStopWatch()
    sw.Start()


    DBM = cDBManager(cDB_Info_Test())

    DBObj = DBM.GetDbObject(E_DB_ALIAS.IGN_TEST)
    DBObj.Connect()
    sw.Append("connnect")


    results = DBObj.ExecuteQuery("select 'kim' as nm , 30 as age ")
    sw.Append("select")

    while results.next():
        print(results.getRow())
        print(results.getValue(0), results.getValue(1))
        print(results.getValueByName("nm"), results.getValueByName("age"))
        pass
    sw.Append("select result print")

    for kk in range( 2001 , 3000 ):
        insqry = f""" INSERT INTO PUBLIC.MYTABLE (ID, NAME)  VALUES ('{kk}', 'kor200')  """
        DBObj.ExecuteUpdate(insqry)

    sw.Append("insert 1000")

    print(sw.Summary())

    # tx = DBObj.BeginTranjection()
    # tx.commit()
    # tx.rollback()

    # DBObj.ExecuteUpdate(insqry)

    # DBObj.ExecuteUpdate(insqry)

    # with DBObj.BeginTranjection() :
    #     DBObj.ExecuteUpdate( insqry )

    # DBObj.RollBack()


    pass


def main22():
    client = Client()
    client.connect("192.168.1.79", 11211)

    # cache_config = {
    #     'atomicity_mode': CacheAtomicityMode.TRANSACTIONAL_SNAPSHOT  # Set of  TRANSACTIONAL_SNAPSHOT
    # }
    # cache = client.get_or_create_cache('my_cache', cache_config)

    # cache_name = 'my_cache'
    # cache_config_dict = {
    #     prop_codes.PROP_NAME : 'm3' ,
    #     prop_codes.PROP_CACHE_ATOMICITY_MODE: CacheAtomicityMode.ATOMIC
    #
    # }
    # cache = client.create_cache(settings=cache_config_dict)


    insqry = """ INSERT INTO PUBLIC.MYTABLE (ID, NAME)  VALUES ('115', 'kor200')  """
    client.sql(insqry)

    # with client.tx_start():
    #     client.sql( insqry )



def main2():
    client = Client()
    client.connect("192.168.1.79", 11211)

    cache = client.get_cache("SQL_ZXCV6_QWERTY")

    cache.put( "nm" , "kim" )
    cache.put( 1 , "kim" )

    cache.put(1 , [1,2,3,4])
    cache.put(2 , Person())

    p= cache.get(2)


    print()
    print(cache.get_size())
    for k, v in cache.scan():
        print(k, v)
    print()
    print(cache.get(3))


    print(cache.get("nm") )

    print(cache.get("2"))
    print(cache.get(2))

    print(cache.get(1))

def main4():


    pass


def main3():

    ignite = cIgniteOBOBJ(cIgniteProperty("192.168.1.79", 11211, _schema="PUBLIC"))
    ignite.Connect()

    sql="""SELECT * FROM MYTABLE"""

    results = ignite.ExecuteQuery(sql)

    # print( len(resilts.datas) )

    for row in results.datas:
        print(row[0])
        print(row[results.getFieldID("id")])

    while results.next():
        print(results.getRow())
        print(results.getValue(0), results.getValue(1))
        print(results.getValueByName("id"), results.getValueByName("name"))

def main():
    ignite = cIgniteOBOBJ(cIgniteProperty("192.168.1.79", 11211, _schema="PUBLIC"))
    ignite.Connect()

    sql="""SELECT * FROM MYTABLE"""

    print(ignite.ExecuteQuery(sql))


    cursor = ignite.ExecuteQuery(sql)

    field_names  = next(cursor)

    print(field_names)

    print(cursor)


    for row in cursor:
        print(row[0])
        print(row[1])

    # field = list(*cursor)
    # for field_name, field_value in zip(field_names  * len(field), field):
    #     print(f'{field_name}: {field_value}')

    #
    # column_names = result.response_header.field_name_alias
    # print(column_names)
    #
    #
    # for row in result:
    #     print(row)
    #     print( row[0] )
    #     print( row[1] )

    # print(ignite.ExecuteUpdate(sql))

    # print(ignite.GetCaches())

    # value = {1: 'test', 'key': 2.0}
    # type_id = eCacheOBJType.LINKED_HASH_MAP
    # t1, name = ignite.GetCache("T1")
    # print(t1, name)

    # t1.put(name, (type_id, value))
    #
    # print(t1.get(name))


if __name__ == '__main__':
    # main3()
    main5()
    # main22()



