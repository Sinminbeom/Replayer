
class cDBResults:

    def __init__(self , _field_nm , _datas):
        # self.fieldnm={index: value for index, value in enumerate(_field_nm)}
        self.fieldnm={value.strip().lower(): index for index, value in enumerate(_field_nm)}
        self.datas=_datas

        # self.datacount= len(self.datas)
        self.cursor_cur=-1
        self.cursor_max= len(self.datas)

    def getFieldID(self,_field_nm):
        return self.fieldnm[_field_nm]

    def getRow(self):
        return self.datas[ self.cursor_cur ]

    def getValue(self , _index ):
        return self.getRow()[_index]
    def getValueByName(self,_column_name):
        return self.getRow()[ self.getFieldID(_column_name.lower()) ]
    def next(self):

        if self.cursor_cur + 1 >= self.cursor_max:
            return False

        self.cursor_cur = self.cursor_cur+1
        return True



