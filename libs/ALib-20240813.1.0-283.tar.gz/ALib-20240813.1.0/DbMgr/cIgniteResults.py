from DbMgr.cDBResults import cDBResults


class cIgniteResult(cDBResults):

    def __init__(self, _field_nm, _datas):
        self.fieldnm = {value.strip().lower(): index for index, value in enumerate(_field_nm)}
        self.datas = list(_datas)

        self.cursor_cur = -1
        self.cursor_max = len(self.datas)
