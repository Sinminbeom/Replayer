
from enum import Enum
from pyignite.datatypes import *

from DbMgr.cDBResults import cDBResults
from DbMgr.cDBOBJ import cDBOBJ

from pyignite import Client
import logging

from DbMgr.cIgniteResults import cIgniteResult


class eCacheOBJType(Enum):
    BYTE = ByteObject
    SHORT = ShortObject
    INTEGER = IntObject
    LONG = LongObject
    FLOAT = FloatObject
    DOUBLE = DoubleObject
    STRING = CharObject
    BOOL = BoolObject
    ARR_LIST = CollectionObject.ARR_LIST
    LINKED_LIST = CollectionObject.LINKED_LIST
    HASH_SET = CollectionObject.HASH_SET
    LINKED_HASH_SET = CollectionObject.LINKED_HASH_SET
    SINGLETON_LIST = CollectionObject.SINGLETON_LIST
    LINKED_HASH_MAP = MapObject.LINKED_HASH_MAP
    HASH_MAP = MapObject.HASH_MAP
    OBJECT = ObjectArrayObject.OBJECT

class cIgniteOBOBJ(cDBOBJ):

    def __init__(self, cDBProperty):
        cDBOBJ.__init__(self, cDBProperty)

    def Connect(self):
        if self.mConn != None:
            raise Exception("cIgniteDBOBJ :: Connect  ", self.mConn)

        print("DLIB >> cIgniteDBOBJ..Connect ", self.GetProperty().ConnectInfo())
        client = Client()
        client.connect(*self.mProperty.GetArgs())
        self.mConn = client

        # self.mConn = Client().connect(*self.mProperty.GetArgs())
        # self.mCursor = self.mConn.cursor()
        self.mCursor=None

        self.schema = self.mProperty.GetKwargs()


        return self

    def Commit(self ):
        # self.mConn.tx_commit(tx)
        pass

    def RollBack(self):
        # self.mConn.tx_start()
        pass

    # def BeginTranjection(self):
    #     return self.mConn.tx_start()

        pass

    def EndTranjection(self):

        pass

    def ExecuteMany(self, qry, param):
        # self.mCursor.executemany(qry, param)
        logging.info("not Support ExecuteMany!!")

        pass

    def ExecuteQuery(self, qry):
        results = self.mConn.sql(query_str=qry, schema=self.schema, include_field_names=True)
        field_names = next(results)
        return cIgniteResult(field_names, results)


    # def ExecuteQuery(self,qry):
    #     return self.mConn.sql(query_str=qry, schema=self.schema, include_field_names=True)
    #     self.mCursor.execute(qry)
    #     return self.mCursor.fetchall()

    def ExecuteUpdate(self,qry):
        # self.mCursor.execute(qry)
        try:
            self.mConn.sql(query_str=qry, schema=self.schema)
            # self.mCursor.execute(qry)
        except Exception as ex:
            # print ("error ExecuteUpdate" , str(ex) , qry )
            logging.error("[Exception] ExecuteUpdate > "  + str(ex) + qry)
            raise  ex

    def ExecBulkInsert(self , qry, data_list):
        logging.info("not Support ExecBulkInsert!!")
        # self.mCursor.executemany( qry , data_list )

        pass



    def Close(self):

        if self.mConn == None:
            return

        # self.mCursor.close()
        self.mConn.close()
        self.mConn = None
    def getCursor(self):
        return None
    def CreateCache(self, cache: str):
        self.mConn.create_cache(cache)

    def GetCache(self, cache: str):
        caches = set(self.GetCaches())
        std_len_caches = len(caches)
        caches.add(cache)

        if len(caches) != std_len_caches:
            raise Exception("cIgniteDBOBJ :: Not Exist Cache", cache)
        cache = self.mConn.get_cache(cache)
        return cache, cache.name

    def GetCaches(self):
        return self.mConn.get_cache_names()

    def GetCacheCursor(self, cache:str, page_size: int = 1, partitions: int = -1, local: bool = False):
        _cache = self.mConn.get_cache(cache)
        return _cache.scan(page_size, partitions, local)

    def DeleteCache(self, schema):
        destroy_schema = self.GetCache(schema)
        destroy_schema.destroy()

    def Close(self):
        if self.mConn == None:
            return

        self.mConn.close()
        self.mConn = None

    #
    #
    # @property
    # def Commit(self):
    #     pass
    #
    # @property
    # def RollBack(self):
    #     pass
    #
    # @property
    # def ExecuteUpdate(self, qry):
    #     pass
