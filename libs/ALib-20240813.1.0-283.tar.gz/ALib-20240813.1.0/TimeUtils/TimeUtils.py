import pytz, datetime

from enum import Enum
from datetime import timedelta, datetime


class TimeFormat(Enum):
    FULL_DATE = "%Y-%m-%d"
    FULL_TIME = "%H:%M:%S"
    SHORT_DATETIME = "%Y%m%d%H%M%S"
    FULL_DATETIME = "%Y-%m-%d %H:%M:%S"
    DAY_MONTH_YEAR = "%d-%m-%Y"
    MONTH_DAY_YEAR = "%m-%d-%Y"
    TWELVE_HOUR_TIME = "%I:%M:%S %p"
    DATE_TIME_MILLISEC = "%Y-%m-%d %H:%M:%S.%f"
    WEEKDAY = "%A"
    MONTH_NAME = "%B"
    SHORT_DATE = "%Y%m%d"
    SHORT_TIME = "%H%M%S"


class TimeStamp(Enum):
    SECOND = 1
    MILLI = 1000
    MICRO = 1000000
    NANO = 1000000000


class TimeUtils:

    @staticmethod
    def getCurrentUTC():
        return datetime.now(pytz.utc)

    @staticmethod
    def convertUnixTimeToLocalTime(_time: int, _time_format=TimeFormat.FULL_DATETIME) -> str:
        timestamp = TimeUtils.__decideTimeStamp(_time)
        datetime_obj = datetime.utcfromtimestamp(_time / timestamp.value)
        local_datetime_obj = datetime_obj + timedelta(hours=TimeUtils.getCurrentTimeZoneOffset())

        return local_datetime_obj.strftime(_time_format.value)

    @staticmethod
    def getCurrentLocalTime(_time_format=TimeFormat.FULL_DATETIME):
        local_now = TimeUtils.getCurrentUTC() + timedelta(hours=TimeUtils.getCurrentTimeZoneOffset())
        return local_now.strftime(_time_format.value)

    @staticmethod
    def getCurrentTimeZoneOffset():
        utc_now = datetime.now(pytz.utc)
        local_now = utc_now.astimezone()
        utc_offset = local_now.utcoffset().total_seconds() / 3600
        return utc_offset

    @staticmethod
    def __decideTimeStamp(_time: int):
        time_str = str(_time)
        if len(time_str) >= 19:
            return TimeStamp.NANO
        if len(time_str) >= 16:
            return TimeStamp.MILLI
        if len(time_str) >= 13:
            return TimeStamp.NANO
        if len(time_str) >= 10:
            return TimeStamp.SECOND
        raise Exception("Expected a more recent date? You are missing", 10 - len(time_str),  "digit.")


def main():
    print( TimeUtils.getCurrentLocalTime() )

    pass




if __name__ == "__main__":
    main()
