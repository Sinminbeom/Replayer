import time
from io import StringIO

class cStopWatch:

    def __init__(self):
        self.Init()
        # self.startTime=0
    def Init(self):
        self.lists = {}
        # self.startTime = 0

    def Start(self):
        self._append("start")
        pass

    def Append(self , k):
        self._append(k)
        pass
    def _append(self , k ):
        # k = len(self.lists) + 1
        self.lists[k]=time.time()

    def Summary(self):

        string_builder=StringIO()

        loopCount=0

        for k , v in self.lists.items():
            if loopCount == 0:
                start_time=v
                before_time=v
                string_builder.write("start time : ")
                string_builder.write(str(v))
                string_builder.write("\n")

            string_builder.write(f"flow time({k}) : ")
            string_builder.write( str( v - before_time) )
            string_builder.write("\n")
            before_time = v
            loopCount = loopCount+1

        return string_builder.getvalue()

def main():
    sw = cStopWatch()

    sw.Start()

    time.sleep(1)
    sw.Append("1")
    time.sleep(2)
    sw.Append("2")

    print( sw.Summary() )



    pass

if __name__ == '__main__':
    main()
