from datetime import datetime
from enum import Enum
from dateutil.relativedelta import relativedelta

class E_TIMEFORMAT(Enum):
    YYYYMMDDHH24MISS = "yyyyMMddHHmmss"
    YYYYMMDDHH24MI  = "yyyyMMddHHmm"
    YYYYMMDDHH24 = "yyyyMMddHH"
    YYYYMMDD = "yyyyMMdd"
    YYYYMM = "yyyyMM"
    YYYY = "yyyy"

    MM="MM"
    DD="dd"
    HH24="HH"
    MI="mm"
    SS="ss"

    @staticmethod
    def Get( time_format ):
        return time_format.value

class E_CALENDAR_TYPE(Enum):
    YEAR = 1
    MONTH = 2
    DAY = 3
    HOUR = 4
    MIN = 5
    SEC = 6

    @staticmethod
    def Get( calendar_type ):
        return calendar_type.value



class cTimeStringInterVal:

    def __init__(self , e_calendar_type , inter_val ):
        self.calendar_type=e_calendar_type
        self.inter_val=inter_val
        pass

    def GetInterVal(self):
        return self.inter_val

    def GetCalendarType(self):
        return self.calendar_type




class cTimeStringFit:
    def __init__( self ):

        self.SetCurrent()

        pass

    def Set ( self, time_string  ):

        if len(time_string) < len( E_TIMEFORMAT.Get(E_TIMEFORMAT.YYYY) ) or len(time_string) > len( E_TIMEFORMAT.Get(E_TIMEFORMAT.YYYYMMDDHH24MISS) ) :
            raise Exception("cTimeStringFit : SetTimeString not enaught  to time string length ")

        self.mvalue = self._fillZero(time_string)

    def _fillZero(self, _time_string):

        # E_TIMEFORMAT.Get( E_TIMEFORMAT.YYYYMMDDHH24MISS )
        time_string = self._fillYYYMMDD(_time_string)

        rlen = len(E_TIMEFORMAT.Get(E_TIMEFORMAT.YYYYMMDDHH24MISS)) - len(time_string)

        if rlen == 0:
            return time_string

        time_string += '0' * rlen

        return time_string

    def _fillYYYMMDD(self, time_string):
        if len(time_string) < len(E_TIMEFORMAT.Get(E_TIMEFORMAT.YYYY)):
            raise Exception

        if len(time_string) < len(E_TIMEFORMAT.Get(E_TIMEFORMAT.YYYYMM)):
            return time_string[:len(E_TIMEFORMAT.Get(E_TIMEFORMAT.YYYY))] + "0101"

        if len(time_string) < len(E_TIMEFORMAT.Get(E_TIMEFORMAT.YYYYMMDD)):
            return time_string[:len(E_TIMEFORMAT.Get(E_TIMEFORMAT.YYYYMM))] + "01"
        return time_string

    # def _fillZero(self , time_string ):
    #
    #     # E_TIMEFORMAT.Get( E_TIMEFORMAT.YYYYMMDDHH24MISS )
    #
    #     rlen = len( E_TIMEFORMAT.Get( E_TIMEFORMAT.YYYYMMDDHH24MISS ) ) - len(time_string )
    #
    #     if rlen == 0 :
    #         return time_string
    #
    #     time_string += '0' * rlen
    #
    #     if time_string[ 5:2 ] == '00':
    #         time_string = time_string.replace([ 5:2 ] , '01')
    #
    #
    #
    #     return time_string

    def SetCurrent(self):
        now = datetime.now()
        self.Set( now.strftime("%Y%m%d%H%M%S") )
        pass

    def Get(self,e_timeformat=E_TIMEFORMAT.YYYYMMDDHH24MISS ):

        begin=0
        last=0
        if e_timeformat.value == E_TIMEFORMAT.MM.value:
            begin=len(E_TIMEFORMAT.YYYY.value)
            last=len(E_TIMEFORMAT.YYYYMM.value)
        elif e_timeformat.value == E_TIMEFORMAT.DD.value:
            begin=len(E_TIMEFORMAT.YYYYMM.value)
            last=len(E_TIMEFORMAT.YYYYMMDD.value)
        elif e_timeformat.value == E_TIMEFORMAT.HH24.value:
            begin=len(E_TIMEFORMAT.YYYYMMDD.value)
            last=len(E_TIMEFORMAT.YYYYMMDDHH24.value)
        elif e_timeformat.value == E_TIMEFORMAT.MI.value:
            begin=len(E_TIMEFORMAT.YYYYMMDDHH24.value)
            last=len(E_TIMEFORMAT.YYYYMMDDHH24MI.value)
        elif e_timeformat.value == E_TIMEFORMAT.SS.value:
            begin=len(E_TIMEFORMAT.YYYYMMDDHH24MI.value)
            last=len(E_TIMEFORMAT.YYYYMMDDHH24MISS.value)
        else:
            last=len(e_timeformat.value)
        # last=len(e_timeformat.value)
        return self.mvalue[begin:last]



    def _getRelativedelta(self , calendar_type , calc_vaule ):
        if  calendar_type ==  E_CALENDAR_TYPE.YEAR :
            return relativedelta( years=calc_vaule )
        elif calendar_type ==  E_CALENDAR_TYPE.MONTH :
            return relativedelta( months= calc_vaule)
        elif calendar_type ==  E_CALENDAR_TYPE.DAY :
            return relativedelta( days= calc_vaule)
        elif calendar_type ==  E_CALENDAR_TYPE.HOUR :
            return relativedelta( hours= calc_vaule)
        elif calendar_type ==  E_CALENDAR_TYPE.MIN :
            return relativedelta( minutes= calc_vaule)
        elif calendar_type ==  E_CALENDAR_TYPE.SEC :
            return relativedelta( seconds= calc_vaule)

        raise Exception("_getRelativedelta Not Found  calendar_type ")


    def CalcDateTime(self ,calendar_type , calc_vaule  ):

        time = datetime.strptime(self.Get() , "%Y%m%d%H%M%S" )

        time_calc = (time + self._getRelativedelta( calendar_type , calc_vaule )).strftime("%Y%m%d%H%M%S")

        ntime = cTimeStringFit()
        ntime.Set(time_calc)
        return ntime

    def Next(self , calendar_type , calc_vaule  ):

        time = datetime.strptime(self.Get(), "%Y%m%d%H%M%S")
        time_calc = (time + self._getRelativedelta(calendar_type, calc_vaule)).strftime("%Y%m%d%H%M%S")
        self.Set( time_calc )

    def Eq(self , time_string_fit ):

        if self.Get() == time_string_fit.Get() :
            return True

        return False

    @staticmethod
    def DiffSec( time_string1 , time_string2 ):

        startTime = cTimeStringFit()
        startTime.Set( time_string1)

        targetTime = cTimeStringFit()
        targetTime.Set(time_string2 )

        time1= datetime.strptime( startTime.Get() , "%Y%m%d%H%M%S")
        time2= datetime.strptime( targetTime.Get() , "%Y%m%d%H%M%S")
        diff=time2-time1
        return int(diff.total_seconds())

    @staticmethod
    def DiffMin(time_string1, time_string2):
        return cTimeStringFit.DiffSec(  time_string1, time_string2  ) / 60

    ##    Useage ..
    ##    cTimeStringFit().CoRoution( "202306231010" , "20230623101110" ,
    ##                             cTimeStringInterVal( E_CALENDAR_TYPE.SEC , 4 ) ,
    ##                             lambda time_string_fit :  print( time_string_fit.Get() )
    ##

    @staticmethod
    def Coroutine( start_time , target_time , time_string_interval , action1 , comparator="<"):

        import operator
        ops = {
            "<": operator.lt,
            "<=": operator.le,
            "==": operator.eq,
            "!=": operator.ne,
            ">": operator.gt,
            ">=": operator.ge
        }

        if comparator not in ops:
            raise ValueError(f"Invalid comparator: {comparator}")

        st = cTimeStringFit()
        st.Set(start_time)

        tg = cTimeStringFit()
        tg.Set(target_time)


        while ops[comparator](st.Get(), tg.Get()):
        # while st.Get() < tg.Get() :
            action1(st)
            st.Next( time_string_interval.GetCalendarType() , time_string_interval.GetInterVal()  )

def main():



    cTimeStringFit().Coroutine("202310", "202312",
                               cTimeStringInterVal(E_CALENDAR_TYPE.MONTH, 1),
                               lambda time_string_fit: print(time_string_fit.Get()) ,
                               "<="
                               )

    cTimeStringFit().Coroutine("2023", "2025",
                               cTimeStringInterVal(E_CALENDAR_TYPE.YEAR, 1),
                               lambda time_string_fit: print(time_string_fit.Get()) ,
                               "<="
                               )






    #
    # # print(  E_TIMEFORMAT.Get( E_TIMEFORMAT.YYYYMMDDHH24MISS ))
    #
    # print( cTimeStringFit.DiffSec("202306231335" ,"20230623133710" ) )
    # print( cTimeStringFit.DiffMin("202306231335" ,"20230623133710" ) )
    #
    # print(cTimeStringFit.DiffSec("202306231339", "20230623133710"))
    #
    #
    # cm = cTimeStringFit()
    # print(cm.Get())
    #
    # print("===================================")
    # print(cm.Get(E_TIMEFORMAT.YYYYMMDDHH24MISS))
    # print(cm.Get(E_TIMEFORMAT.YYYYMMDDHH24MI))
    # print(cm.Get(E_TIMEFORMAT.YYYYMMDDHH24))
    # print(cm.Get(E_TIMEFORMAT.YYYYMMDD))
    # print(cm.Get(E_TIMEFORMAT.YYYYMM))
    # print(cm.Get(E_TIMEFORMAT.YYYY))
    #
    # print("----------------------------------------")
    #
    # print(cm.Get(E_TIMEFORMAT.MM))
    # print(cm.Get(E_TIMEFORMAT.DD))
    # print(cm.Get(E_TIMEFORMAT.HH24))
    # print(cm.Get(E_TIMEFORMAT.MI))
    # print(cm.Get(E_TIMEFORMAT.SS))
    #
    # print("****************************************")
    #
    # cm.Set("20230405011011")
    #
    # print(cm.Get())
    #
    #
    # ncm = cm.CalcDateTime(  E_CALENDAR_TYPE.MIN , 10 )
    #
    # print(ncm.Get() )
    #
    # print("===================")
    #
    # cTimeStringFit().Coroutine( "202306231010" , "20230623101110" ,
    #                             cTimeStringInterVal( E_CALENDAR_TYPE.SEC , 4 ) ,
    #                             lambda time_string_fit :  print( time_string_fit.Get() )
    #                             )
    #
    # print("====##################################################################################===============")
    #
    # cTimeStringFit().Coroutine( "202306231010" , "20230623101110" ,
    #                             cTimeStringInterVal( E_CALENDAR_TYPE.SEC , 1 ) ,
    #                             lambda time_string_fit :  print( time_string_fit.Get() )
    #                             )
    #
    # print("====ww################################################wwww##################################===============")
    #
    # cTimeStringFit().Coroutine( "202306231010" , "20230623101110" ,
    #                             cTimeStringInterVal( E_CALENDAR_TYPE.SEC , 1 ) ,
    #                             lambda time_string_fit :  print( time_string_fit.Get() ) ,
    #                             "<="
    #                             )



    pass




if __name__ == "__main__":
    main()


