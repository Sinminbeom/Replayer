



class IProperty:
    """Property interface"""

    pass