from enum import Enum

import hashlib


class eHashType(Enum):
    NONE=0
    MD5=1
    SHA1=2
    SHA256=3
    SHA512=4
    pass



class HashSecurity(object):

    @staticmethod
    def EncryptMD5(buf):
        return hashlib.md5(buf.encode()).hexdigest()
        pass

    #
    # @staticmethod
    # def DecryptMD5(buf):
    #     return hashlib.md5(buf.encode()).hexdigest()
    #     pass
    #
    # @staticmethod
    # def Decrypt(hash , hash_type ):
    #     return hashlib.md5(hash.encode()).hexdigest()
    #
    #     pass
    #
    #
    @staticmethod
    def Encrypt( buf , hash_type ):
        if hash_type == eHashType.MD5:
            return hashlib.md5(buf.encode()).hexdigest()
        elif hash_type == eHashType.SHA1:
            return hashlib.sha1(buf.encode()).hexdigest()
        elif hash_type == eHashType.SHA256:
            return hashlib.sha256(buf.encode()).hexdigest()
        elif hash_type == eHashType.SHA512:
            return hashlib.sha512(buf.encode()).hexdigest()

        raise Exception('type error')



    pass