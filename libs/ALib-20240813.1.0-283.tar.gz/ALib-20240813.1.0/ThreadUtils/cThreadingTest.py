from ThreadUtils.abThreading import abThreading


class cThreadingTest(abThreading):

    def __init__(self):
        abThreading.__init__(self)

    def Action(self):
        print("cThreadingTest ")
        pass


def main():
    th = cThreadingTest()

    th.Start()



    pass


if __name__ == '__main__':
    main()


