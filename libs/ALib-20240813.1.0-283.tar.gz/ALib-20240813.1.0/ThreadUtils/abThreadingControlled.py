from ThreadUtils.abThreading import abThreading


class abThreadingControlled ( abThreading ):

    def __init__(self,_thread_controller , _name):
        abThreading.__init__(self)
        self.thread_controler = _thread_controller
        self.name = _name
    def run(self):

        try:
            while not self.IsStop():
                self.Action()
        except Exception as e:
            print(f"error:{e}")
            self.setException(e)

    def getName(self):
        return self.name
    def setException(self , e ):

        self.thread_controler.setException(e , self)

        pass


    def Action(self):
        print("abThreading ")
        pass
