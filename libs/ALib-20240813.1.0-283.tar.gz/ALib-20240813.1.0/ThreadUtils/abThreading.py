from ThreadUtils.abThread import abThread


class abThreading ( abThread ):

    def __init__(self):
        abThread.__init__(self)

    def run(self):
        while not self.IsStop():
            self.Action()

    def Action(self):
        print("abThreading ")
        pass



