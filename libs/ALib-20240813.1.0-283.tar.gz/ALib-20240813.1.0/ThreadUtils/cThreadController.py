from ThreadUtils.abThreading import abThreading
from ThreadUtils.abThreadingControlled import abThreadingControlled


class cth1(abThreadingControlled):

    def __init__(self , _thread_controller , _name ):
        abThreadingControlled.__init__(self , _thread_controller , _name)

        pass

    def Action(self):
        print( self.getName())
        pass

    pass

class cThreadController:
    def __init__(self):
        self.lists={}
        pass

    def append(self,_abThreadingControlled):
        k =_abThreadingControlled.getName()
        self.lists[k]=_abThreadingControlled

    def Start(self):
        for th in self.lists.values():
            th.Start()
            pass
        pass

    def Stop(self):
        for th in self.lists.values():
            th.Stop()
        pass

    def StopByName(self,_thread_name):

        v=self.lists.get(_thread_name)
        v.Stop()

        # for th in self.lists.values():
        #     th.Stop()
        pass

    def setException(self ,_e , _abThreadingControlled ):
        e=_e

        print(e)

def main():
    tc = cThreadController()

    tc.append( cth1(tc , "ch1") )
    tc.append( cth1(tc , "ch2") )
    tc.append( cth1(tc , "ch3") )
    tc.append( cth1(tc , "ch4") )

    tc.Start()

    loopCount=0


    while True:

        loopCount=loopCount+1

        if loopCount > 1000:
            tc.Stop()
            loopCount=0

            break

        pass


    pass


if __name__ == '__main__':
    main()