import time

from ThreadUtils.abThread import abThread
class cThreadTest(abThread):
    def __init__(self):
        abThread.__init__(self)


    def Action(self):
        print("cThreadTest ")
        pass




def main():

    th=cThreadTest()

    print("-- start  --")
    th.Start()

    for i in range(2):
        time.sleep(1)

    th.Stop()

    print("-- stop --")

    for i in range(5):
        time.sleep(1)

    pass


if __name__ == '__main__':
    main()