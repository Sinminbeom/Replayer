import jsonpickle as jsonpickle


class Gson:

    @staticmethod
    def toJson(obj):
        try :
            return jsonpickle.encode(obj, unpicklable=True)
        except Exception as e:
            raise e

    @staticmethod
    def toJsonSkipMeta(obj):
        try :
            return jsonpickle.encode(obj, unpicklable=False)
        except Exception as e:
            raise e

    @staticmethod
    def fromJsonWithCls(*clss,json_str):
        try:
            return jsonpickle.decode(json_str)
        except Exception as e:
            raise e

    @staticmethod
    def fromJson(json_str):
        try:
            return jsonpickle.decode(json_str)
        except Exception as e:
            raise e



class human:
    def __init__(self):
        self.name="kim"
        self.age=19

class patHuman(human):

    def __init__(self):
        human.__init__(self)
        self.patLists=[]

    def appendPat(self,_pat):
        self.patLists.append(_pat)


class pat:
    def __init__(self,_human):
        self.name="pat1"
        self.age=10
        self.owner=_human


def main():
    # str= Gson.toJson(human())
    # print(str)

    pHuman=patHuman()
    pHuman.appendPat(pat(pHuman))
    pHuman.appendPat(pat(pHuman))
    pHuman.appendPat(pat(pHuman))
    pHuman.appendPat(pat(pHuman))

    str=Gson.toJson(pHuman)
    str_skip_meta=Gson.toJsonSkipMeta(pHuman)

    print(str)
    print(str_skip_meta)

    h2= Gson.fromJson(str)

    i=10
    i=100

    h3 = Gson.fromJsonWithCls(patHuman,pat,json_str=str)

    i=10
    i=100

    h3str=Gson.toJson(h3)
    print(h3str)


if __name__ == '__main__':
    main()