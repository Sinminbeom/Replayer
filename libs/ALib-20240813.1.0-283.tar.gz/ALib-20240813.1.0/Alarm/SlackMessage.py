from Codec.Base64Codec import Base64Codec
from Log.cLogger import cLogger, E_LOG
from LibUtils.StringBuilder import StringBuilder
import json
from RestCall.RestCall import RestCall

class SlackMessage:
    def __init__(self, MessageServerUri):
        self.MessageServerUri = MessageServerUri

    def getUri(self, subject, message):
        base64Codec = Base64Codec()
        enSubject = base64Codec.encode(subject)
        enMessage = base64Codec.encode(message)

        sb = StringBuilder()
        sb.Append(self.MessageServerUri)
        sb.Append("/")
        sb.Append(enSubject)
        sb.Append("/")
        sb.Append(enMessage)

        return sb.ToString()
