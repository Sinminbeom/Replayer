from LibUtils.SingletonInstane import SingletonInstane
from urllib3 import PoolManager, Timeout, exceptions, Retry
from Log.cLogger import cLogger, E_LOG

class RestCall(SingletonInstane):

    def Init(self, poolRetries=False, poolConn=None, poolRead=None):
        self.PoolMgr = PoolManager(retries=poolRetries, timeout=Timeout(connect=poolConn, read=poolRead))

    def appendRequest(self, method, url, headers=None, **body):
        try:
            if method == 'GET':
                result = self.PoolMgr.request(method, url, headers=headers)
            else:
                result = self.PoolMgr.request(method, url, headers=headers, **body)
        except exceptions.HTTPError as httpErr:
            isComplete = False
            result = httpErr
            cLogger.instance().Print(E_LOG.EXCEPTION, f"HTTPError = {httpErr}")
        else:
            isComplete = True

        return { "isSuccess": isComplete, "result": result }