import setuptools

setuptools.setup(
	name='ALib',
	version='20240813.1.0',
	description='ALib',
	author='swm',
	author_email='None',
	url='None',
	packages=['Alarm', 'Codec', 'Collections', 'Configure', 'DbMgr', 'deleGate', 'Exception', 'Geo', 'JSon', 'LibUtils', 'Log', 'Math', 'MultiProcess', 'ObjectStorage2', 'ObjectStrage', 'PCap', 'Processing', 'Propertys', 'RestCall', 'Security', 'TestCode', 'ThreadUtils', 'TimeUtils', 'DbMgr.Example', 'LibUtils.ShellCommander', 'ObjectStorage2.Hadoop', 'ObjectStorage2.Minio', 'ObjectStorage2.Properties', 'ObjectStorage2.Test', 'ObjectStrage.Minio', 'ObjectStrage.Minio.api', 'PCap.Reader'],
	install_requires=['APScheduler==3.10.0', 'async-timeout==4.0.3', 'attrs==23.1.0', 'certifi==2023.5.7', 'charset-normalizer==3.3.2', 'docopt==0.6.2', 'haversine==2.7.0', 'hdfs==2.7.3', 'idna==3.6', 'jsonpickle==3.0.2', 'minio==7.1.15', 'multipledispatch==1.0.0', 'numpy==1.24.2', 'psycopg2==2.9.5', 'psycopg2-binary==2.9.7', 'py4j==0.10.9.7', 'pyarrow==15.0.0', 'pyignite==0.6.1', 'PyMySQL==1.0.2', 'pyspark==3.5.0', 'python-dateutil==2.8.2', 'pytz==2022.7.1', 'pytz-deprecation-shim==0.1.0.post0', 'redis==5.0.1', 'requests==2.31.0', 'scapy==2.5.0', 'shapely==2.0.1', 'singleton==0.1.0', 'six==1.16.0', 'tzdata==2022.7', 'tzlocal==4.2', 'urllib3==1.26.14']
)