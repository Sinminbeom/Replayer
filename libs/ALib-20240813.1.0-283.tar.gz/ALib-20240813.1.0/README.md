# Infra Glue Python  Template

0.python 의 기본 구성
- 3.9.10 버전을 사용 한다.


Part.1 개발 환경 Setting

1.가상 환경 구축
```
CMD or BashShell

python -m venv venv

```

2.가상환경 Active
```
Window
venv\Scripts\activate

linux
source activate
```

3.lib 설치
```
pip install -r requirements.txt
```

4.윈도우 환경 PyCharm 이용시 python Interpreter 변경
```
현재 사용중인 가상 환경의 python.exe 파일을 지정
```


Part.2 배포

1.라이브러리 목록 갱신
```
pip freeze > .\requirements.txt
```

[//]: # (2.setup.py 버전 갱신)

[//]: # (```)

[//]: # (날짜만 수정함)

[//]: # (version='20230808.3.0',  )

[//]: # (```)

2.5 SetupGenerator.py 수정 
```
해당 빌드일 에[ 몇번째 빌드인지만 기입함.
V_BUILD_NUM = 5
```

3.라이브러리 빌드
```

[//]: # (python setup.py sdist)

python .\SetupGenerator.py

```

4.배포
```
Jenkins를 통한 배포
```